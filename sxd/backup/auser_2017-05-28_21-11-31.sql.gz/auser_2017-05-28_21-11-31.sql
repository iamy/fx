#SXD20|20011|50552|50630|2017.05.28 21:11:31|auser|0|218|928|
#TA accounts`2`16384|accounts_audit`2`16384|accounts_bugs`0`16384|accounts_cases`0`16384|accounts_contacts`1`16384|accounts_cstm`2`16384|accounts_opportunities`0`16384|acl_actions`461`147456|acl_roles`0`16384|acl_roles_actions`0`16384|acl_roles_users`0`16384|address_book`0`16384|alerts`0`16384|am_projecttemplates`0`16384|am_projecttemplates_audit`0`16384|am_projecttemplates_contacts_1_c`0`16384|am_projecttemplates_project_1_c`0`16384|am_projecttemplates_users_1_c`0`16384|am_tasktemplates`0`16384|am_tasktemplates_am_projecttemplates_c`0`16384|am_tasktemplates_audit`0`16384|aobh_businesshours`0`16384|aod_index`1`16384|aod_index_audit`0`16384|aod_indexevent`5`16384|aod_indexevent_audit`0`16384|aok_knowledge_base_categories`0`16384|aok_knowledge_base_categories_audit`0`16384|aok_knowledgebase`0`16384|aok_knowledgebase_audit`0`16384|aok_knowledgebase_categories`0`16384|aop_case_events`0`16384|aop_case_events_audit`0`16384|aop_case_updates`0`16384|aop_case_updates_audit`0`16384|aor_charts`0`16384|aor_conditions`0`16384|aor_fields`0`16384|aor_reports`0`16384|aor_reports_audit`0`16384|aor_scheduled_reports`0`16384|aos_contracts`0`16384|aos_contracts_audit`0`16384|aos_contracts_documents`0`16384|aos_invoices`0`16384|aos_invoices_audit`0`16384|aos_line_item_groups`0`16384|aos_line_item_groups_audit`0`16384|aos_pdf_templates`0`16384|aos_pdf_templates_audit`0`16384|aos_product_categories`0`16384|aos_product_categories_audit`0`16384|aos_products`0`16384|aos_products_audit`0`16384|aos_products_quotes`0`16384|aos_products_quotes_audit`0`16384|aos_quotes`0`16384|aos_quotes_aos_invoices_c`0`16384|aos_quotes_audit`0`16384|aos_quotes_os_contracts_c`0`16384|aos_quotes_project_c`0`16384|aow_actions`0`16384|aow_conditions`0`16384|aow_processed`0`16384|aow_processed_aow_actions`0`16384|aow_workflow`0`16384|aow_workflow_audit`0`16384|bugs`0`16384|bugs_audit`0`16384|calls`0`16384|calls_contacts`0`16384|calls_leads`0`16384|calls_reschedule`0`16384|calls_reschedule_audit`0`16384|calls_users`0`16384|campaign_log`0`16384|campaign_trkrs`0`16384|campaigns`0`16384|campaigns_audit`0`16384|cases`0`16384|cases_audit`0`16384|cases_bugs`0`16384|cases_cstm`0`16384|config`20`16384|contacts`1`16384|contacts_audit`0`16384|contacts_bugs`0`16384|contacts_cases`0`16384|contacts_cstm`1`16384|contacts_users`0`16384|cron_remove_documents`0`16384|currencies`0`16384|custom_fields`0`16384|document_revisions`0`16384|documents`0`16384|documents_accounts`0`16384|documents_bugs`0`16384|documents_cases`0`16384|documents_contacts`0`16384|documents_opportunities`0`16384|dp_bkrv`1`16384|dp_bkrv_accounts_c`1`16384|dp_bkrv_audit`0`16384|dp_license`0`16384|dp_license_audit`0`16384|dp_license_cstm`0`16384|dp_realty`1`16384|dp_realty_accounts_c`1`16384|dp_realty_audit`0`16384|eapm`0`16384|email_addr_bean_rel`3`16384|email_addresses`2`16384|email_cache`0`16384|email_marketing`0`16384|email_marketing_prospect_lists`0`16384|email_templates`8`16384|emailman`0`16384|emails`0`16384|emails_beans`0`16384|emails_email_addr_rel`0`16384|emails_text`0`0|favorites`0`16384|fields_meta_data`45`16384|folders`0`16384|folders_rel`0`16384|folders_subscriptions`0`16384|fp_event_locations`0`16384|fp_event_locations_audit`0`16384|fp_event_locations_fp_events_1_c`0`16384|fp_events`0`16384|fp_events_audit`0`16384|fp_events_contacts_c`0`16384|fp_events_fp_event_delegates_1_c`0`16384|fp_events_fp_event_locations_1_c`0`16384|fp_events_leads_1_c`0`16384|fp_events_prospects_1_c`0`16384|import_maps`0`16384|inbound_email`0`16384|inbound_email_autoreply`0`16384|inbound_email_cache_ts`0`16384|jjwg_address_cache`0`16384|jjwg_address_cache_audit`0`16384|jjwg_areas`0`16384|jjwg_areas_audit`0`16384|jjwg_maps`0`16384|jjwg_maps_audit`0`16384|jjwg_maps_jjwg_areas_c`0`16384|jjwg_maps_jjwg_markers_c`0`16384|jjwg_markers`0`16384|jjwg_markers_audit`0`16384|job_queue`0`16384|leads`0`16384|leads_audit`0`16384|leads_cstm`0`16384|linked_documents`0`16384|meetings`0`16384|meetings_contacts`0`16384|meetings_cstm`0`16384|meetings_leads`0`16384|meetings_users`0`16384|notes`0`16384|oauth_consumer`0`16384|oauth_nonce`0`16384|oauth_tokens`0`16384|opportunities`0`16384|opportunities_audit`0`16384|opportunities_contacts`0`16384|opportunities_cstm`0`16384|outbound_email`1`16384|outbound_email_audit`0`16384|project`0`16384|project_contacts_1_c`0`16384|project_cstm`0`16384|project_task`0`16384|project_task_audit`0`16384|project_users_1_c`0`16384|projects_accounts`0`16384|projects_bugs`0`16384|projects_cases`0`16384|projects_contacts`0`16384|projects_opportunities`0`16384|projects_products`0`16384|prospect_list_campaigns`0`16384|prospect_lists`0`16384|prospect_lists_prospects`0`16384|prospects`0`16384|prospects_cstm`0`16384|relationships`323`163840|releases`0`16384|reminders`0`16384|reminders_invitees`0`16384|roles`0`16384|roles_modules`0`16384|roles_users`0`16384|saved_search`0`16384|schedulers`13`16384|securitygroups`0`16384|securitygroups_acl_roles`0`16384|securitygroups_audit`0`16384|securitygroups_default`0`16384|securitygroups_records`0`16384|securitygroups_users`0`16384|spots`0`16384|sro_svid_sro`0`16384|sro_svid_sro_audit`0`16384|sro_svid_sro_cstm`0`16384|sugarfeed`1`16384|tasks`0`16384|templatesectionline`0`16384|tracker`5`16384|upgrade_history`4`16384|user_preferences`22`16384|users`1`16384|users_feeds`0`16384|users_last_import`0`16384|users_password_link`0`16384|users_signatures`0`16384|vcals`0`16384
#EOH

#	TC`accounts`utf8_general_ci	;
CREATE TABLE `accounts` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `industry` varchar(50) DEFAULT NULL,
  `annual_revenue` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `rating` varchar(100) DEFAULT NULL,
  `phone_office` varchar(100) DEFAULT NULL,
  `phone_alternate` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `ownership` varchar(100) DEFAULT NULL,
  `employees` varchar(10) DEFAULT NULL,
  `ticker_symbol` varchar(10) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `sic_code` varchar(255) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `shname` varchar(255) DEFAULT NULL,
  `inn` varchar(12) DEFAULT NULL,
  `kpp` varchar(9) DEFAULT NULL,
  `resident` varchar(255) DEFAULT 'Да',
  `okpo` varchar(8) DEFAULT NULL,
  `ogrn` varchar(15) DEFAULT NULL,
  `okopf` varchar(10) DEFAULT NULL,
  `okogu` varchar(7) DEFAULT NULL,
  `okfs` varchar(20) DEFAULT NULL,
  `date_ifns` date DEFAULT NULL,
  `nm_regorgan` varchar(150) DEFAULT NULL,
  `date_gosreg` date DEFAULT NULL,
  `nm_gosreg` varchar(150) DEFAULT NULL,
  `ur_locality` varchar(150) DEFAULT NULL,
  `ur_area` varchar(150) DEFAULT NULL,
  `ur_house` varchar(10) DEFAULT NULL,
  `ur_structure` varchar(10) DEFAULT NULL,
  `ur_apartment` varchar(10) DEFAULT NULL,
  `ur_area_fact` varchar(150) DEFAULT NULL,
  `ur_locality_fact` varchar(150) DEFAULT NULL,
  `ur_house_fact` varchar(10) DEFAULT NULL,
  `ur_structure_fact` varchar(10) DEFAULT NULL,
  `ur_apartment_fact` varchar(10) DEFAULT NULL,
  `oktmo_fact` varchar(11) DEFAULT NULL,
  `oktmo_ur` varchar(11) DEFAULT NULL,
  `date_reg_ustav` date DEFAULT NULL,
  `authorized_share_capital` varchar(10) DEFAULT NULL,
  `paid_share_capital` varchar(10) DEFAULT NULL,
  `region_activity` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accnt_id_del` (`id`,`deleted`),
  KEY `idx_accnt_name_del` (`name`,`deleted`),
  KEY `idx_accnt_assigned_del` (`deleted`,`assigned_user_id`),
  KEY `idx_accnt_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts`utf8_general_ci	;
INSERT INTO `accounts` VALUES 
('b9f49b4f-21dc-4a20-5646-592571b11c40','Общество с ограниченной ответственностью «Солнечная долина»','2017-05-24 11:42:01','2017-05-26 07:51:40','1','1',\N,0,'1',\N,\N,\N,\N,'Студеный овраг, просека 10','Самара',\N,'443031','Российская Федерация',\N,\N,\N,'http://',\N,'30',\N,'Ново-Садовая','Самара',\N,'443068','Российская Федерация','','47.64 Торговля розничная спортивным оборудованием и спортивными товарами в специализированных магазинах','','ООО «Солнечная долина»','6318123326','631201001','Да','21121044','1026301511708','12300','4210014','16','2011-11-10','Инспекция Федеральной налоговой службы по Кировскому району г. Самары','2002-01-16','Инспекция Федеральной налоговой службы по Кировскому району г. Самары',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
('f1c17d43-b29f-16ef-5774-5927e6b4501a','Общество с ограниченной ответственностью «Эффективные технологии»','2017-05-26 08:26:48','2017-05-28 17:37:21','1','1',\N,0,'1',\N,\N,\N,\N,'Ташкентская, 171Г','Самара','Самарская область','443122','Россия',\N,\N,\N,'https://fksrf.pro',\N,\N,\N,'Ташкентская, 171Г','Самара','Самарская область','443122','Россия','',\N,'','ООО «Эффективные технологии»','6324003370','631201001','Да','62450630','1096324003093',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N)	;
#	TC`accounts_audit`utf8_general_ci	;
CREATE TABLE `accounts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts_audit`utf8_general_ci	;
INSERT INTO `accounts_audit` VALUES 
('a27e54d1-6ca6-f793-5fa1-5926b3cec92d','b9f49b4f-21dc-4a20-5646-592571b11c40','2017-05-25 10:35:28','1','inn','varchar',\N,'6318123326',\N,\N),
('a3a1a28d-fc51-f6b2-2f2e-5926b3573a3d','b9f49b4f-21dc-4a20-5646-592571b11c40','2017-05-25 10:35:28','1','kpp','varchar',\N,'631201001',\N,\N)	;
#	TC`accounts_bugs`utf8_general_ci	;
CREATE TABLE `accounts_bugs` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acc_bug_acc` (`account_id`),
  KEY `idx_acc_bug_bug` (`bug_id`),
  KEY `idx_account_bug` (`account_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`accounts_cases`utf8_general_ci	;
CREATE TABLE `accounts_cases` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acc_case_acc` (`account_id`),
  KEY `idx_acc_acc_case` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`accounts_contacts`utf8_general_ci	;
CREATE TABLE `accounts_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_account_contact` (`account_id`,`contact_id`),
  KEY `idx_contid_del_accid` (`contact_id`,`deleted`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts_contacts`utf8_general_ci	;
INSERT INTO `accounts_contacts` VALUES 
('c813f409-47e8-0d6c-dac8-5927e651e1ab','e41e39af-5bdc-0b83-c659-5927e5a9adf7','b9f49b4f-21dc-4a20-5646-592571b11c40','2017-05-26 08:25:16',0)	;
#	TC`accounts_cstm`utf8_general_ci	;
CREATE TABLE `accounts_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts_cstm`utf8_general_ci	;
INSERT INTO `accounts_cstm` VALUES 
('b9f49b4f-21dc-4a20-5646-592571b11c40',0.00000000,0.00000000,'',''),
('f1c17d43-b29f-16ef-5774-5927e6b4501a',0.00000000,0.00000000,'','')	;
#	TC`accounts_opportunities`utf8_general_ci	;
CREATE TABLE `accounts_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_account_opportunity` (`account_id`,`opportunity_id`),
  KEY `idx_oppid_del_accid` (`opportunity_id`,`deleted`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`acl_actions`utf8_general_ci	;
CREATE TABLE `acl_actions` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `acltype` varchar(100) DEFAULT NULL,
  `aclaccess` int(3) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aclaction_id_del` (`id`,`deleted`),
  KEY `idx_category_name` (`category`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`acl_actions`utf8_general_ci	;
INSERT INTO `acl_actions` VALUES 
('10a80e96-b098-6601-8379-59256453825f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOK_KnowledgeBase','module',90,0),
('1136eacd-c082-6b79-6b1f-59256429d460','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Alerts','module',90,0),
('11d9e0c1-fcf1-816e-1e18-592564720589','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOW_Processed','module',90,0),
('11f625c9-e3e2-e001-4b25-592564854749','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOK_KnowledgeBase','module',90,0),
('126232fb-5c60-0894-c06d-5925647f355f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Contracts','module',90,0),
('129a67f8-cb5e-f63f-be52-5925643b6da1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','TemplateSectionLine','module',89,0),
('129ce679-2ebd-47a8-1484-592564b68dab','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Alerts','module',90,0),
('13681532-b7e0-2ca3-e4a5-59256443d40a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOK_KnowledgeBase','module',90,0),
('13ed1d0b-3245-032e-a4fc-592564c56a26','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOW_Processed','module',90,0),
('13fc03ef-e460-576b-61b4-59256446a200','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Contracts','module',90,0),
('144aaa60-c9ff-1431-1285-592564b9b4dc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','TemplateSectionLine','module',90,0),
('14d325f7-8913-0a80-9927-592564d1fa37','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOK_KnowledgeBase','module',90,0),
('1559f2e0-63fe-2f49-6d82-5925640b597d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Contracts','module',90,0),
('15c0aaec-03e8-2455-e599-592564e6156f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','TemplateSectionLine','module',90,0),
('15c908f8-567c-ed28-ecad-5925640d9e0e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Contacts','module',90,0),
('1611060c-a47a-f918-36da-592564c35afa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOK_Knowledge_Base_Categories','module',90,0),
('1618c853-de1c-ce4b-6a2b-592564298f2d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOK_KnowledgeBase','module',90,0),
('16771a55-95aa-2c2c-fb2d-592564be78f5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOW_Processed','module',90,0),
('1736716a-e954-4f01-f2de-5925645a97ac','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Contracts','module',90,0),
('176379f9-8df8-6d6b-044c-59256442115a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','TemplateSectionLine','module',90,0),
('18824dba-8e7c-8d21-7307-5925647e907a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Contracts','module',90,0),
('18e0f408-9f5c-e6fc-2cf3-592564cfbefd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','TemplateSectionLine','module',90,0),
('1a7bf93b-edd7-da92-947b-592564891071','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','TemplateSectionLine','module',90,0),
('1b117f2c-54f5-e6fa-3d00-59256459734e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOW_Processed','module',90,0),
('1bf08da0-6b79-3773-718b-592564c71ef1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','TemplateSectionLine','module',90,0),
('1c3e0c8e-5cbb-694c-b944-592564e076f2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Bugs','module',90,0),
('1da35dfc-eec1-4dc6-6de7-59256432df12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','TemplateSectionLine','module',90,0),
('1f5948d6-45c9-50cd-d57c-592564677870','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Accounts','module',89,0),
('1fd004e6-6935-f325-9332-592564750cd3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOW_Processed','module',90,0),
('203c7ae6-e17a-7e32-42fd-592564afdd3d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Documents','module',89,0),
('207272ae-76df-407a-db68-59256477fffb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Accounts','module',90,0),
('216f99a0-6cf1-4a49-7d6c-592564a63805','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Documents','module',90,0),
('21d7b2f0-7636-7380-64bc-59256442bc74','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Accounts','module',90,0),
('228eee29-bef8-0bb3-deac-592564cef734','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOW_Processed','module',90,0),
('22995699-b1fb-fd93-d2a6-592564786c07','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Documents','module',90,0),
('22e0512b-c62c-8c52-02e5-592564cc7b91','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Accounts','module',90,0),
('23c08dcf-87be-6380-406f-592564729cde','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Documents','module',90,0),
('23e54dbb-328c-fa24-a215-592564a30cc1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Accounts','module',90,0),
('24b91c9d-58f1-fd40-2abc-5925643f8726','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Documents','module',90,0),
('24fc9692-a40b-6cb9-c037-5925648bb3ad','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Accounts','module',90,0),
('25e191a7-2fa9-0db7-cc00-592564f2f1b1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Documents','module',90,0),
('26449795-ba99-ff69-5a1d-5925644f0327','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Accounts','module',90,0),
('26e50096-7504-3457-fc87-5925645c8379','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Contacts','module',90,0),
('26fcfaf3-e0de-3075-70cf-592564ec9f8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Documents','module',90,0),
('278d051e-1ec7-f16f-3301-592564cb15a3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Accounts','module',90,0),
('27dd07ed-cd1f-5838-900a-5925646843f5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOK_Knowledge_Base_Categories','module',90,0),
('283690bc-5685-c915-c572-59256424f6ba','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Documents','module',90,0),
('28ea09d6-bf9f-c334-7063-592564771a82','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','OutboundEmailAccounts','module',90,0),
('2bebba28-0624-5160-3f2f-5925641af4e2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Users','module',89,0),
('2d544540-199e-1e66-72fb-592564fce02c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Users','module',90,0),
('2e7663a1-0cf0-80c1-24b7-592564b5bcf4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Users','module',90,0),
('2fcdd39a-2ea7-f27c-bba8-59256406b53a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Users','module',90,0),
('2feb8d86-1135-82df-32e3-5925640e5732','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Invoices','module',89,0),
('30dd4943-3a0d-aefc-e1ee-5925640d66f9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Users','module',90,0),
('3138d219-df01-3589-97d5-5925646af5f3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Invoices','module',90,0),
('3148b73c-3663-09d4-71d2-592564ae7c82','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','FP_events','module',89,0),
('31efe988-94a9-1fda-63e3-592564b0d6df','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Users','module',90,0),
('3290e8d9-82c1-1701-61dd-592564de30a4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','FP_events','module',90,0),
('32b52270-a828-0aab-71a3-5925644acba7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Invoices','module',90,0),
('33c32bee-5adb-b72d-bf7f-5925642084fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','FP_events','module',90,0),
('33fb84aa-0c4a-5298-eb81-59256450ca78','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Users','module',90,0),
('34073948-24b6-28c0-bc63-592564cc987c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Invoices','module',90,0),
('351335c3-0ddb-0e87-21f5-59256428ecaa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','FP_events','module',90,0),
('3529cdd6-2d00-8878-0fa5-5925646587d9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Users','module',90,0),
('3569d016-56e4-f64e-ffdb-592564774947','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Invoices','module',90,0),
('3651fb1f-effc-94b1-dd55-59256479a5fd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','FP_events','module',90,0),
('370d1cbb-fd14-f408-ebab-592564a1d676','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Invoices','module',90,0),
('3798bfef-339d-1062-60ed-59256449e812','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','FP_events','module',90,0),
('38090d87-acc7-397d-4c63-59256407e023','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Contacts','module',90,0),
('39718a70-206a-89ca-22aa-592564ecf20d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','FP_events','module',90,0),
('3abd5ba2-e9d7-2499-a551-59256444cb70','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','FP_events','module',90,0),
('3ac034b5-2355-f0c2-e454-5925648456fe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Invoices','module',90,0),
('3ca02bfb-bacb-2944-fe88-592564a9ff9c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Invoices','module',90,0),
('3e902a5b-9702-150f-4cfd-5926d2aef56a','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','access','dp_bkrv','module',89,0),
('3f4bf13d-b119-cabe-b775-59256410df39','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Opportunities','module',89,0),
('4090aa9b-a492-9f62-4ff9-5925643b5152','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Opportunities','module',90,0),
('419033f6-7326-7ade-7646-5925648779be','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Maps','module',89,0),
('41b8e304-7e50-c095-e2cf-5925643c4d33','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Opportunities','module',90,0),
('42d95587-a278-289c-eb94-592564e075da','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Opportunities','module',90,0),
('44505817-5003-4aa2-b6cb-592564feeb1c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Maps','module',90,0),
('44720a37-a225-70d7-d33c-59256458ae0c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Opportunities','module',90,0),
('4578ec44-70b3-fa55-1cb9-5925648295b0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Opportunities','module',90,0),
('461ac14c-4a85-c045-86fa-5925640acc8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','FP_Event_Locations','module',89,0),
('4673f515-c8b3-fa4f-75a1-592564951def','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Project','module',89,0),
('4677a4e7-4f8d-39fc-8d21-59256431d9e0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Opportunities','module',90,0),
('4718eeb3-c4fb-614f-71ad-5925649ae43b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Maps','module',90,0),
('4786456b-0a15-6689-904e-5926d2b50cb1','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','view','dp_bkrv','module',90,0),
('478ed2f3-ff64-cf3e-7320-5925647c590d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','FP_Event_Locations','module',90,0),
('4803e562-2f2e-3871-489d-592564d25fec','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Project','module',90,0),
('48f02fb2-371d-dc51-33e8-59256426b897','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Maps','module',90,0),
('4911f675-7f10-ace8-9e62-5925649220b6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','FP_Event_Locations','module',90,0),
('498359df-ebb0-3b45-6ccd-5925643089fd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Project','module',90,0),
('49e4b481-b6bd-2b9d-61ca-5926d2b206df','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','list','dp_bkrv','module',90,0),
('4a678ea5-9b38-2bd7-fda5-5925644303af','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Opportunities','module',90,0),
('4a99b4c6-878b-d3fe-63d6-5925644eb0b5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','FP_Event_Locations','module',90,0),
('4ab7f61f-d638-5a4e-1177-5925643d151e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Maps','module',90,0),
('4abfa988-e469-35b5-f38e-59256434204e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Project','module',90,0),
('4bccc8ad-39e8-e9e6-c825-5926d2302b62','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','edit','dp_bkrv','module',90,0),
('4bf6dac8-fd03-c55c-ff6c-592564d17570','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','FP_Event_Locations','module',90,0),
('4c125b13-a179-0105-9c01-592564c12cde','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Project','module',90,0),
('4c4b9363-1c28-9982-4bbe-592564363399','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Maps','module',90,0),
('4d433b8a-2f4a-da18-0129-59256458329b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','FP_Event_Locations','module',90,0),
('4dd371b6-acd5-b07e-5a31-5926d2cdc50c','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','delete','dp_bkrv','module',90,0),
('4dfac029-9049-408d-2df4-592564a964be','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Project','module',90,0),
('4e051c7b-5060-d5e4-d988-592564778b88','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Maps','module',90,0),
('4ed693c1-d8af-17f2-2c8b-592564690fd5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','FP_Event_Locations','module',90,0),
('4f7774cc-cfe4-8c8d-b4a9-5925640c89cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Maps','module',90,0),
('4f99def4-72c1-f478-77a9-59256451b225','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Project','module',90,0),
('4f9b51e1-5a4b-dde2-23e7-59272d8b429a','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','access','dp_realty','module',89,0),
('4ff61581-2104-a4ed-fe44-5926d28a9f0f','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','import','dp_bkrv','module',90,0),
('4ff6dc67-2f3a-abf6-cc32-592564985ca4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','FP_Event_Locations','module',90,0),
('50675523-bbed-598e-d52d-592564554740','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Spots','module',89,0),
('50b85d74-3ef0-4d3a-e135-5925649cf51d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_PDF_Templates','module',89,0),
('50f3217a-b574-39ff-bf1e-592564d41ea3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Project','module',90,0),
('518d99c4-558b-351b-ec1b-592564b8e454','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Spots','module',90,0),
('520d7287-1b9d-5829-a93f-5926d220fa6f','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','export','dp_bkrv','module',90,0),
('52318172-cebb-4f78-7b54-592564813de3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_PDF_Templates','module',90,0),
('52c2e837-e4e9-b981-212f-592564bd6f1d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Spots','module',90,0),
('539f0a19-2e9f-00f4-4050-592564ce262d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','OutboundEmailAccounts','module',90,0),
('53c0c5ce-cd4e-eb95-33b9-5925644aecf5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_PDF_Templates','module',90,0),
('54087b0d-f496-c657-71ce-592564e2b168','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Spots','module',90,0),
('545a409e-6a2a-558d-af21-5926d26e8ac4','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','massupdate','dp_bkrv','module',90,0),
('552ba5f1-642d-7626-679e-59256471f0b2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_PDF_Templates','module',90,0),
('5587eb44-6152-9f3e-dbc8-5925647bde8f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Spots','module',90,0),
('568c15d0-5418-63c4-6f83-592564490323','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_PDF_Templates','module',90,0),
('56fa86f6-2a0d-8e91-c084-592564d07a81','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Spots','module',90,0),
('5800fe63-193a-7aa9-0a00-592564804c36','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_PDF_Templates','module',90,0),
('58446609-de3c-5851-a042-59272df93715','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','view','dp_realty','module',90,0),
('584fc1ef-4481-5017-8b01-592564552c42','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Spots','module',90,0),
('594005aa-2299-99d2-3ba1-5925643a7e4f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Contacts','module',90,0),
('59739056-8eb7-34d5-a28e-59256456f9b0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Spots','module',90,0),
('5991f5de-6979-f127-9099-592564f0a3f7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_PDF_Templates','module',90,0),
('5a6cb8f7-7a64-2561-7941-59272dcbd0fb','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','list','dp_realty','module',90,0),
('5d8889c9-6f9a-f091-be0b-592564b4403f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_PDF_Templates','module',90,0),
('5d9fe3df-96e1-45fc-171d-5925647f70fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOD_IndexEvent','module',89,0),
('5de47ae3-d6ee-012d-c786-59272d6b68f6','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','edit','dp_realty','module',90,0),
('5edff6d6-735a-a946-92d0-59256434c86f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOD_IndexEvent','module',90,0),
('5f2fde6b-f5d5-300e-3aac-5925641bb69c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','EmailTemplates','module',89,0),
('60086668-8a2b-0191-e750-59256463b988','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOD_IndexEvent','module',90,0),
('608cc0a5-a7f3-cfa2-44af-59272d36f1cd','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','delete','dp_realty','module',90,0),
('6091cb62-3981-f1c1-fa33-592564003b02','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','ProjectTask','module',89,0),
('60f6edde-afd7-e6df-71b6-5925642910a9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','EmailTemplates','module',90,0),
('610f9834-e450-d9d3-028e-592b0831978a','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','access','sro_svid_sro','module',89,0),
('6132421a-cbed-4500-8e64-592564dd0c93','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOD_IndexEvent','module',90,0),
('61c22bbe-611b-6673-1a18-59256403af7e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','ProjectTask','module',90,0),
('6242c377-b887-86dc-604e-592564cb8584','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOD_IndexEvent','module',90,0),
('624c6d7e-853c-9332-605d-592564f7f6d6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Markers','module',89,0),
('62739f95-df3e-6bf6-ae85-59256468c10f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','EmailTemplates','module',90,0),
('62c2f9e9-c3a2-94b1-94e1-59272d7eab87','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','import','dp_realty','module',90,0),
('62efa492-aa46-da6d-3545-59256453dbe6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','ProjectTask','module',90,0),
('63622169-091c-bff5-8096-592564f65d1d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOD_IndexEvent','module',90,0),
('6402f0ba-2c1d-fd22-a5f5-592564ed85bb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','ProjectTask','module',90,0),
('642439c1-b715-4471-27b5-5925648353a2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Markers','module',90,0),
('6432d85d-75b1-c298-6020-592564020d99','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','EmailTemplates','module',90,0),
('6481270c-1724-7422-8c07-59256477caf5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOD_IndexEvent','module',90,0),
('6531ca27-0669-56d6-f989-592564d84294','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','ProjectTask','module',90,0),
('655c8a63-2411-bc65-daba-59272dfa2ba9','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','export','dp_realty','module',90,0),
('659fb557-481f-7e9f-e8cf-592564ba8443','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Markers','module',90,0),
('65cc28c6-6bf3-2370-f957-592564bf312c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOD_IndexEvent','module',90,0),
('660dba79-8158-d326-0ccb-5925648fb74d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','EmailTemplates','module',90,0),
('664bc999-523b-a960-2689-592564a460d2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','ProjectTask','module',90,0),
('674e687d-1e4a-469e-5ed3-5925649f4ee9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','ProjectTask','module',90,0),
('6770ad0a-4a60-5e12-685e-592564d1fcc4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Markers','module',90,0),
('6792b1f9-7b21-dcae-147b-592b084b626c','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','view','sro_svid_sro','module',90,0),
('67ab466a-9366-27b7-a290-592564f11b19','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','EmailTemplates','module',90,0),
('6846f05d-3263-41a8-6406-592564f18f89','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','ProjectTask','module',90,0),
('686df4ba-5306-e303-1e2d-59272d957776','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','massupdate','dp_realty','module',90,0),
('68eaff61-686f-76b9-9d8f-592564b2b34b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Markers','module',90,0),
('6903eb61-be7c-e77a-3157-5925642fb47b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','EmailTemplates','module',90,0),
('6906cc52-71ba-1061-2ed0-592b086dee51','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','list','sro_svid_sro','module',90,0),
('69ac0e7f-e756-6db1-22f3-5925646df4a7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Bugs','module',90,0),
('6a5576b0-58d4-758d-58aa-592b085b0363','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','edit','sro_svid_sro','module',90,0),
('6a692618-ab50-f579-b565-59256412f910','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Markers','module',90,0),
('6a9f9837-5b1c-ff51-bb90-59256496105a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','EmailTemplates','module',90,0),
('6bb7e990-1a78-3f9f-5830-592564028086','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Markers','module',90,0),
('6bbe5e76-ddb8-17f7-c3cf-592b089ee0bd','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','delete','sro_svid_sro','module',90,0),
('6cf6b475-7a06-0985-ec43-592564128da5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Markers','module',90,0),
('6dab649e-4e0c-fca8-5242-592564fed239','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Product_Categories','module',89,0),
('6f18ede4-8148-63d2-c7c1-592564bdb0c1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Product_Categories','module',90,0),
('7028bee7-3248-fc92-78dc-592564fc9b11','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOD_Index','module',89,0),
('706cb269-fa43-50dd-0f6a-592b082455e2','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','import','sro_svid_sro','module',90,0),
('7074eac8-e178-1b90-e6b4-592564b79cdc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Product_Categories','module',90,0),
('711e5a2c-8abd-ffb9-266c-59256488bbae','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Notes','module',89,0),
('718a9cd4-880a-7da4-9f93-592564c5f57b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOD_Index','module',90,0),
('71af4945-a6d5-c8db-2622-592564c39397','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Product_Categories','module',90,0),
('724033ab-b4a7-b31c-0ad7-592b085e903b','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','export','sro_svid_sro','module',90,0),
('72617cc7-d088-32ed-9975-5925649e763e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Notes','module',90,0),
('72dbf649-7d1f-26f6-3337-592564007a74','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOD_Index','module',90,0),
('73338552-523e-a422-7ed6-5925644be58a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Product_Categories','module',90,0),
('739856ff-8f8f-3477-17e0-5925644ed1cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Notes','module',90,0),
('7430d855-a4ed-f680-52e4-5925643a6de4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOD_Index','module',90,0),
('74998f8a-19ae-187e-9e19-592564dac258','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Product_Categories','module',90,0),
('750b1fc9-e895-b03b-8951-592564afb3c2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Notes','module',90,0),
('75bbaaad-7827-6454-0595-5925649d732c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOD_Index','module',90,0),
('75f71ed0-5ae0-d152-c517-5925640f3fc2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Product_Categories','module',90,0),
('762074c9-7bb0-f3f1-a812-59256494357b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Notes','module',90,0),
('76a9d2ae-0e73-c4dc-c72e-592b083b760e','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','massupdate','sro_svid_sro','module',90,0),
('772630ec-8fb5-f9d2-2d12-5925648dc9cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOD_Index','module',90,0),
('773bec7c-9403-3ee0-839c-59256452d1af','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Notes','module',90,0),
('7755f8df-baec-3f94-11c8-592564cab0a4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','EAPM','module',89,0),
('77b2e06d-6a5b-7e18-3c38-5925642dbb19','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Product_Categories','module',90,0),
('7857cdc1-7615-7c24-0488-5925646f00e3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOD_Index','module',90,0),
('786e0443-0a04-19f4-fb59-5925642c15f9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Notes','module',90,0),
('791fdddd-0141-c6cc-def0-59256496af30','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','EAPM','module',90,0),
('798cc1cf-8565-a8c2-a258-59256454a1f4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Notes','module',90,0),
('799e87fc-93fd-0e29-6499-59256498b297','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOD_Index','module',90,0),
('7a7125f6-0b75-5019-da7b-592564eed389','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Areas','module',89,0),
('7a7aba15-8f2a-59b8-f69a-59256470a572','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','EAPM','module',90,0),
('7bca0e8d-9cf5-84e3-dabf-592564156643','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','EAPM','module',90,0),
('7c4b7014-5aa4-38a1-235f-592564f7358e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Campaigns','module',89,0),
('7c99b69b-1427-cbd6-5899-5925648529cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Areas','module',90,0),
('7d24bb26-88cf-556f-ddf1-59256448abc3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','EAPM','module',90,0),
('7d837f8d-3c93-7305-333f-592564a5b864','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Campaigns','module',90,0),
('7e5bb1e9-2251-aa52-53a6-592564bd0b2b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','EAPM','module',90,0),
('7e7c554d-c663-70f7-c369-592564badad4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Areas','module',90,0),
('7f89a846-56e8-d3ea-f5d3-592564c4e88c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Campaigns','module',90,0),
('7fc5a6fe-1514-4da6-9485-592564a3659c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','EAPM','module',90,0),
('80d0a7af-1d88-98f4-df95-592564047141','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Areas','module',90,0),
('80e001f9-97bb-ca7d-4e84-5925642a96cc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Bugs','module',90,0),
('80f61337-deb7-c246-daee-592564609465','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','EAPM','module',90,0),
('819b446e-f296-4043-6346-5925644b7b3f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Campaigns','module',90,0),
('8330d8ec-9dd2-7034-f9fd-59256439fb29','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Campaigns','module',90,0),
('836bcd67-9fb8-72eb-702f-592564ee157a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Products','module',89,0),
('83b6e320-891b-314f-6788-592564c32dfe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Areas','module',90,0),
('846b7bfe-39a5-d1f0-0584-592564a35f98','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Campaigns','module',90,0),
('8488260f-4b79-9ca5-b445-592564c2cf31','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Calls','module',89,0),
('84b4b2fc-7dea-e223-640b-592564ae97bd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Products','module',90,0),
('857dbad0-7b76-b8a9-1a54-592564f43c8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Areas','module',90,0),
('858abe37-2952-a449-fdb1-5925647bb1bc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Campaigns','module',90,0),
('85c16938-6029-c620-e135-59256438a294','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Calls','module',90,0),
('85c9b074-3b6a-e033-d244-592564c466a1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Products','module',90,0),
('86c1b182-51b9-ac54-c64c-592564f99600','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOP_Case_Events','module',89,0),
('86ca3522-c826-18ab-9799-592564b03dfe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Campaigns','module',90,0),
('86f48c68-cb76-090b-1b6d-59256445be37','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Products','module',90,0),
('880412ca-c9e0-e88a-7fa7-5925643130e1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Calls','module',90,0),
('882d4255-3e6c-0270-eeb2-5925645c718e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Products','module',90,0),
('8833d87a-9bbf-2796-f98b-592564359ac9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOP_Case_Events','module',90,0),
('8897957c-2d5c-5fb4-7f30-59256456bb76','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Areas','module',90,0),
('894cb07a-667c-f89e-2d4e-592564395de7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Products','module',90,0),
('89c40de8-033c-c9c9-40b7-592564aed98d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Calls','module',90,0),
('89cb6560-dda5-3c2b-97af-5925644f817e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOP_Case_Events','module',90,0),
('8a274117-2c0f-328a-40c3-592564335c06','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Areas','module',90,0),
('8ad11ed4-6e92-27f9-2e81-592564817cc6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Products','module',90,0),
('8b5b6647-b8db-86ba-34c6-592564ac2aad','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Calls','module',90,0),
('8bdbcb74-f52c-8301-a74c-5925646b2e69','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOP_Case_Events','module',90,0),
('8c1ad23c-e66f-5300-c512-5925646e0eeb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Products','module',90,0),
('8cc57d35-4834-0079-ce2f-59256449ae59','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Calls','module',90,0),
('8e2c3825-ceef-5157-b639-592564212449','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Calls','module',90,0),
('8e9b63f4-dcad-fd85-c262-5925647f397a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOP_Case_Events','module',90,0),
('8f7fa86b-9be1-8398-e78c-592564234b9d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Calls','module',90,0),
('9035e82e-8c79-9576-60ce-59256498ee24','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOP_Case_Events','module',90,0),
('9273f407-98c3-86b4-75f3-592564fa6e78','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOP_Case_Events','module',90,0),
('92e3dc1b-dac6-c165-0834-5925643ebb85','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AM_ProjectTemplates','module',89,0),
('93fd6338-ebdb-c244-f360-59256473717e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOP_Case_Events','module',90,0),
('9442d13a-4cdb-2885-b927-5925641594fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AM_ProjectTemplates','module',90,0),
('95310256-0fa2-8b0c-48b7-592564a6f140','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Alerts','module',89,0),
('95641d65-a0a1-e7ea-c551-59256462edab','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AM_ProjectTemplates','module',90,0),
('96afbf57-6024-4d17-49a1-592564058860','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AM_ProjectTemplates','module',90,0),
('97de90d3-ee52-62e3-0aee-592564ccc78c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AM_ProjectTemplates','module',90,0),
('98900fa1-069a-2cf6-4045-5925640fde45','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','OutboundEmailAccounts','module',90,0),
('98ff6059-4b15-7ca5-72f4-592564e5aa56','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AM_ProjectTemplates','module',90,0),
('997d6ba6-3c16-b40c-da22-5925646d3e81','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Address_Cache','module',89,0),
('9a43ae71-e6e0-bd53-800d-59256408667c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AM_ProjectTemplates','module',90,0),
('9aeb33c6-aa31-82f4-3515-59256419e20b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Address_Cache','module',90,0),
('9b6dab5a-dba0-f32b-c7cd-59256481b998','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AM_ProjectTemplates','module',90,0),
('9c8e15ac-e95f-94a8-3a1b-59256427e6cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Address_Cache','module',90,0),
('9e02c754-e6e4-24f4-dbf1-592564607787','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','ProspectLists','module',89,0),
('9e6a31f8-1dbc-637f-42ed-5925646bcb8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Emails','module',89,0),
('9f366d67-8cf5-a7dc-d646-592564bf0017','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','ProspectLists','module',90,0),
('9f7fe16d-9921-2140-9d95-5925641009f4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOP_Case_Updates','module',89,0),
('a0095f6f-cc35-cbf9-155e-592564c6a49f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Emails','module',90,0),
('a071b98a-e813-5a5e-c546-592564056454','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','ProspectLists','module',90,0),
('a09d6109-005a-b7c1-4300-5925642f0330','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOP_Case_Updates','module',90,0),
('a18ef381-b9e0-e600-9230-592564ffeafd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','ProspectLists','module',90,0),
('a1b95047-1e71-9594-d6fc-5925641cef1f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOP_Case_Updates','module',90,0),
('a2655c4a-9abe-9d12-7845-5925643fa5da','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Emails','module',90,0),
('a2b6ae39-de64-0e4c-789e-5925640db8cc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','ProspectLists','module',90,0),
('a2d730cb-5018-919d-58f1-5925644eb25b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Address_Cache','module',90,0),
('a2df7bce-230e-f51f-efda-592564ffb0cc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOP_Case_Updates','module',90,0),
('a3b1049b-9170-ea78-09f5-59256432ffb1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Emails','module',90,0),
('a41861a2-5c5f-dd56-8346-5925641efb0b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOP_Case_Updates','module',90,0),
('a41c170c-cb90-e272-0ce5-592564db6f12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','ProspectLists','module',90,0),
('a4706533-e8ea-05c7-3836-5925649caa49','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Address_Cache','module',90,0),
('a4fd8eec-d5c0-306c-c68e-592564a73563','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Emails','module',90,0),
('a525197d-c8c7-11af-be34-592564331c33','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','ProspectLists','module',90,0),
('a579e34e-7b3c-a141-7c7f-592564deba53','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOP_Case_Updates','module',90,0),
('a61fe7b2-8b5b-0d26-f2f8-5925644b0aa5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Address_Cache','module',90,0),
('a626a4a5-22fb-7102-eeed-592564f29851','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','ProspectLists','module',90,0),
('a65da3d1-7bdb-7095-dfd2-5925645eb267','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Emails','module',90,0),
('a6b0bc39-90e3-5fe9-fbdc-592564e8aebf','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOP_Case_Updates','module',90,0),
('a761f461-99d3-2dc2-7803-5925643de90e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Emails','module',90,0),
('a7e82439-bd9b-b0ee-d60b-592564ded457','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Address_Cache','module',90,0),
('a7f773d9-2f38-5b94-170c-5925646f2724','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOP_Case_Updates','module',90,0),
('a815047a-a25d-6a67-ed5d-592564299580','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Alerts','module',90,0),
('a8e70f2c-c33e-55e2-9c2a-5925647f06ff','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Contracts','module',89,0),
('a8fa4880-38b1-d883-26d2-592564a81a92','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Emails','module',90,0),
('a937a342-208b-dd93-1afa-592564e1cd4c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Leads','module',89,0),
('a98bbdf5-93ae-4e76-4b59-5925647c38c6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Address_Cache','module',90,0),
('acdee2ef-da71-e239-b6ed-5925641ba071','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Leads','module',90,0),
('aef7bb67-e81b-7b38-8e21-5925647f77ef','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Leads','module',90,0),
('b04b51e9-217f-bf61-d2a2-59256436f552','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Leads','module',90,0),
('b182988b-6c00-7040-8e98-592564804e92','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Prospects','module',89,0),
('b22c13ef-95a3-e88e-c3ea-592564d06495','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Quotes','module',89,0),
('b35d50c9-9573-ed56-2564-592564e5cb64','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Prospects','module',90,0),
('b3a3b3c7-5b46-b4ec-113b-592564bb8255','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Quotes','module',90,0),
('b40f274b-56bb-b84d-003b-59256484cf91','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Leads','module',90,0),
('b488b56d-07c7-573b-0e33-5925646c6428','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Prospects','module',90,0),
('b503e4e0-8ad9-e420-32f7-592824dafd8b','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','access','dp_license','module',89,0),
('b509c134-ea8a-5ee4-fb63-59256473781d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Quotes','module',90,0),
('b57dfad6-d1a8-4521-3e36-59256417d4e3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Leads','module',90,0),
('b58c80c8-20d1-eef5-10de-592564275ef0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOR_Reports','module',89,0),
('b609639b-b963-475d-9431-592564f766fe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Prospects','module',90,0),
('b652beff-6f92-c2e1-1207-592564bb428a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Quotes','module',90,0),
('b6edd723-8d8e-ea05-3a68-59256410dacf','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOR_Reports','module',90,0),
('b719c335-361d-5434-d1d5-59256405fce5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Leads','module',90,0),
('b7b87a63-3ace-21b2-2891-592564546b12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Quotes','module',90,0),
('b81a61df-8b0d-c08f-ea62-592564184c31','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOR_Reports','module',90,0),
('b82bcf10-09ee-678e-6ea8-592564144a53','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Prospects','module',90,0),
('b89803a4-a709-19fc-6dac-5925640b706a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Leads','module',90,0),
('b940fbe9-1be8-5832-b408-5925644df2ea','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Prospects','module',90,0),
('b9525773-ebce-299e-a2b8-592564d902fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOR_Reports','module',90,0),
('ba0b2353-2687-3ba0-94f1-5925649eabd7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Quotes','module',90,0),
('ba436fdf-f437-4df1-ced7-592564a021a3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Prospects','module',90,0),
('bb63626f-14a6-7db4-ceab-59256405a686','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOR_Reports','module',90,0),
('bb6baf92-b14e-d5e0-0f52-5925649277fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Prospects','module',90,0),
('bbdea725-c7de-f2bd-652d-592564c065a1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Calls_Reschedule','module',89,0),
('bc02a448-967a-0970-a4d0-59256458de20','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Quotes','module',90,0),
('bc162da9-0dcb-1df8-4c1c-592824867fb1','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','view','dp_license','module',90,0),
('bc1a0642-70fb-bd58-f89f-59256483596c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Alerts','module',90,0),
('bcbc1548-6947-13f8-2018-592564d6aef3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOR_Reports','module',90,0),
('bd94a534-3319-c9c5-b47d-59282449fe15','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','list','dp_license','module',90,0),
('bde96f5e-b36d-b7e9-bb14-59256483588a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Quotes','module',90,0),
('be42632d-5408-c7d3-06d9-5925648efbaa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOR_Reports','module',90,0),
('be9f8c89-8e4f-cea9-02d4-592564025250','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Meetings','module',89,0),
('bea8b4ff-e1db-0585-8996-592564cfb9f2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Calls_Reschedule','module',90,0),
('bf27e9ff-dae8-9e0b-c9c7-5928245babc6','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','edit','dp_license','module',90,0),
('bf9890e9-6469-37a3-cf58-5925645d9e33','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOR_Reports','module',90,0),
('bfcdf9d8-413e-466f-3472-592564f02c1c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Meetings','module',90,0),
('c0312370-8eda-7184-dc43-592564aa00dc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Calls_Reschedule','module',90,0),
('c09277db-b273-117d-bc44-59282421474e','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','delete','dp_license','module',90,0),
('c0db855d-6257-0995-6527-592564bc0676','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Meetings','module',90,0),
('c191f75b-c9a0-ff99-9641-592564bf3577','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Calls_Reschedule','module',90,0),
('c218689c-8812-5bfd-5e8b-5928248f6571','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','import','dp_license','module',90,0),
('c237d749-bfc5-19a0-68b3-592564c18e14','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Meetings','module',90,0),
('c34a0a42-3243-18da-e2b6-592564875092','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOW_Processed','module',89,0),
('c37ac16e-68dd-95da-191b-592824ad8aaf','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','export','dp_license','module',90,0),
('c386652c-6ddb-7dae-de19-592564f60250','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Calls_Reschedule','module',90,0),
('c40870a5-e0f5-ceba-5bf5-592564d67e1a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Meetings','module',90,0),
('c4d16e3b-e3a8-2e8e-05b6-592824c52301','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','massupdate','dp_license','module',90,0),
('c4ffaa81-5029-0143-bba7-59256453e5b5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Calls_Reschedule','module',90,0),
('c54626ca-2205-923e-0d02-592564ef6ebf','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Meetings','module',90,0),
('c641ec1b-e63d-f4a7-b78a-5925645bb84a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Calls_Reschedule','module',90,0),
('c666478f-25c6-df9b-236e-592564c829d5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Meetings','module',90,0),
('c7a238f6-8063-6950-1ce6-592564919cd7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Calls_Reschedule','module',90,0),
('c7d72dc4-2238-e2bc-bdc1-5925648d5907','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Meetings','module',90,0),
('c9c73879-801f-2f3d-dc92-592564fb5ad7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','EmailMarketing','module',89,0),
('caaa0ff1-2662-d488-7bae-592564a4cc89','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOK_KnowledgeBase','module',89,0),
('cc63a273-5328-d30b-3699-592564290912','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','EmailMarketing','module',90,0),
('cd7f7d50-4795-8816-1331-592564b55f12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','EmailMarketing','module',90,0),
('cd8b0646-d90a-ffe8-adb9-592564695e30','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Bugs','module',90,0),
('ce79e5d9-a75e-d0f3-4d9a-592564e39851','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Cases','module',89,0),
('ce945be8-3e14-8fac-5896-5925641deeb2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','EmailMarketing','module',90,0),
('cfc1a7db-59de-db29-8676-5925646dcc08','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','EmailMarketing','module',90,0),
('d0258c5b-6894-df16-51fd-5925641b8081','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Cases','module',90,0),
('d0c80d70-d9fc-3638-9e4a-592564349e7d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Alerts','module',90,0),
('d11e4709-20c5-5d80-ee86-59256403b831','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','EmailMarketing','module',90,0),
('d19ef571-500a-e7b8-f466-592564ea3726','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Tasks','module',89,0),
('d1a34f1d-0c3f-fa52-7115-59256466fa59','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AM_TaskTemplates','module',89,0),
('d1c102a3-2993-a192-d878-59256464b217','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Cases','module',90,0),
('d222ce7f-ce1e-a307-7622-592564d3f208','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','EmailMarketing','module',90,0),
('d22700c5-19bd-c1a0-af9e-59256406ac3d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','SecurityGroups','module',89,0),
('d321d382-fe5e-3613-273d-59256404e3b2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Tasks','module',90,0),
('d335fc39-b447-17be-60ea-592564b8803a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AM_TaskTemplates','module',90,0),
('d33c8c7c-53be-6906-4834-59256485a333','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Cases','module',90,0),
('d35d7c4e-762d-b7bd-5fc1-592564d8c42b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','EmailMarketing','module',90,0),
('d3f76523-7188-6078-cc8d-592564c2731b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','SecurityGroups','module',90,0),
('d452862e-a776-d7ed-0e3c-5925645d41cd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Tasks','module',90,0),
('d47fee2e-e684-ac40-2c42-592564b27d95','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Cases','module',90,0),
('d4e0d847-e5a5-0cbc-fced-5925643b47be','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOW_WorkFlow','module',89,0),
('d4ed85f3-c423-b7c8-e959-5925643851a7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AM_TaskTemplates','module',90,0),
('d57063b7-be97-b7eb-79ac-592564a4e5c4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','SecurityGroups','module',90,0),
('d570e2e1-8b6d-e21d-f470-5925647611f7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Tasks','module',90,0),
('d5b1d0c6-eb5f-e00b-d1dd-592564f2c827','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Cases','module',90,0),
('d62c9b9c-e4d0-f67b-4924-5925648f8ee3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AM_TaskTemplates','module',90,0),
('d67021e7-4d95-b290-868e-5925642fc82a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOW_WorkFlow','module',90,0),
('d6a41f93-7c0b-6692-5e19-592564852d5d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Tasks','module',90,0),
('d6c6750d-3aab-e4a8-14cf-592564086404','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','SecurityGroups','module',90,0),
('d76c5c58-816f-3fa7-43de-5925640460c9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Cases','module',90,0),
('d79b21c4-db12-23c8-64bf-59256477f388','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AM_TaskTemplates','module',90,0),
('d7c4551e-7866-8a41-23a4-592564fe9a20','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Tasks','module',90,0),
('d80fd00d-bc92-bb06-ca91-592564db9aab','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','SecurityGroups','module',90,0),
('d8118dfd-6f8d-e88e-2972-5925648cfe92','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOW_WorkFlow','module',90,0),
('d8b31032-a0e5-a3c5-0a9e-59256448e044','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AM_TaskTemplates','module',90,0),
('d8dbbab2-bc85-9e73-df6b-592564a6f2c0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Cases','module',90,0),
('d9155b0a-5bfc-b1c4-a543-592564e4757d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Tasks','module',90,0),
('d93c820e-6727-4b68-add5-59256405c0a2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','SecurityGroups','module',90,0),
('d99a8f45-1436-f414-1b70-592564af912b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOW_WorkFlow','module',90,0),
('d9c81c10-63f7-0f13-7992-592564378318','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AM_TaskTemplates','module',90,0),
('d9f20532-f485-885f-b380-5925648dc9f5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Contracts','module',90,0),
('da8680ef-4207-58ea-502a-5925649fa112','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','SecurityGroups','module',90,0),
('daa40ed7-4ada-a968-ecb6-5925643e4917','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Tasks','module',90,0),
('db016c6f-af5c-1c6e-f594-5925649cb49b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AM_TaskTemplates','module',90,0),
('dbb378cd-5c36-e292-a504-592564c8043c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOW_WorkFlow','module',90,0),
('dbd49dbd-96cd-4810-973a-592564fd9d3c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','SecurityGroups','module',90,0),
('dd2d0077-a1c6-01ed-e29c-5925645afd45','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOW_WorkFlow','module',90,0),
('de990503-546b-6054-ebfd-592564b70dcb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOK_KnowledgeBase','module',90,0),
('df2aca5e-22f4-7ef7-9bf8-592564e76887','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOW_WorkFlow','module',90,0),
('e09b4d5a-1560-54b2-7e13-592564d951d0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOW_WorkFlow','module',90,0),
('e646cbbe-5b4a-4a6a-3725-592564cd6f3b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOR_Scheduled_Reports','module',89,0),
('e7ce0228-c508-6a29-f5be-592564e519d5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Alerts','module',90,0),
('e7f5c4a6-95ab-641c-8791-59256401f007','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','OutboundEmailAccounts','module',89,0),
('e90e8f5c-24e2-9e17-5870-592564824993','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOR_Scheduled_Reports','module',90,0),
('e9a71ab8-82d1-c442-c5e1-592564277cba','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','OutboundEmailAccounts','module',90,0),
('ea888bf2-f049-b3cf-c210-59256408536d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOR_Scheduled_Reports','module',90,0),
('eb293405-926c-8af5-8ab6-592564ed89bd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','OutboundEmailAccounts','module',90,0),
('ebb007d2-62e5-e849-60dd-592564e9f985','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Bugs','module',89,0),
('ebfd8757-8e2e-c9a1-29fa-59256458bdc6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOR_Scheduled_Reports','module',90,0),
('ecca2d44-59d4-5ca5-e1b5-5925642e0a8b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','OutboundEmailAccounts','module',90,0),
('ed2c78ab-59c5-d8ce-b665-59256457bb57','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Bugs','module',90,0),
('ed93055d-235f-ddf3-7c4f-592564e9c172','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOK_Knowledge_Base_Categories','module',89,0),
('eda1943d-c0f8-4675-b348-5925648e5bc1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOR_Scheduled_Reports','module',90,0),
('ee508cbe-f9df-8732-1278-592564c5555d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','OutboundEmailAccounts','module',90,0),
('eebea8f2-4149-fb32-9c88-5925641e6365','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOK_Knowledge_Base_Categories','module',90,0),
('eedfe052-473d-a0ce-a966-5925648b835e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Bugs','module',90,0),
('ef19df34-0607-a454-49e5-5925645c4d26','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOR_Scheduled_Reports','module',90,0),
('efce29cb-3824-bcf7-0a2c-592564a15273','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOK_Knowledge_Base_Categories','module',90,0),
('f01805df-9cb9-b299-3ecb-59256408b005','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Contacts','module',89,0),
('f0a3bf62-de49-d960-d4fd-592564688794','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOR_Scheduled_Reports','module',90,0),
('f0b4d9b6-74bb-61e3-29d3-592564f57c61','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Bugs','module',90,0),
('f0e2787c-abef-d10a-cd0a-5925640f73ca','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOK_Knowledge_Base_Categories','module',90,0),
('f145b997-26c0-1299-7410-59256456ea78','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Contacts','module',90,0),
('f2800537-834c-01b7-e1f9-59256448c13e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Contacts','module',90,0),
('f2803842-58df-e514-6c6e-592564cce7b3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOK_Knowledge_Base_Categories','module',90,0),
('f29c3eab-b08c-bc8b-3290-59256455ae3e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOR_Scheduled_Reports','module',90,0),
('f37e5c31-3303-c6f4-ad42-592564225605','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Contacts','module',90,0),
('f3b9de43-1d56-2e5d-42e7-59256405f466','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOK_Knowledge_Base_Categories','module',90,0),
('f5190af2-3c36-026d-eb5c-592564a52931','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOK_KnowledgeBase','module',90,0),
('f73b0072-4b54-0452-feb9-592564555dad','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOW_Processed','module',90,0),
('fb0102f1-7242-0a4b-c308-592564b18034','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Contracts','module',90,0),
('fba3006d-f61d-ae33-ed89-592564fc3525','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Alerts','module',90,0)	;
#	TC`acl_roles`utf8_general_ci	;
CREATE TABLE `acl_roles` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aclrole_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`acl_roles_actions`utf8_general_ci	;
CREATE TABLE `acl_roles_actions` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `action_id` varchar(36) DEFAULT NULL,
  `access_override` int(3) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acl_role_id` (`role_id`),
  KEY `idx_acl_action_id` (`action_id`),
  KEY `idx_aclrole_action` (`role_id`,`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`acl_roles_users`utf8_general_ci	;
CREATE TABLE `acl_roles_users` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aclrole_id` (`role_id`),
  KEY `idx_acluser_id` (`user_id`),
  KEY `idx_aclrole_user` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`address_book`utf8_general_ci	;
CREATE TABLE `address_book` (
  `assigned_user_id` char(36) NOT NULL,
  `bean` varchar(50) DEFAULT NULL,
  `bean_id` char(36) NOT NULL,
  KEY `ab_user_bean_idx` (`assigned_user_id`,`bean`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`alerts`utf8_general_ci	;
CREATE TABLE `alerts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `target_module` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url_redirect` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates`utf8_general_ci	;
CREATE TABLE `am_projecttemplates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Draft',
  `priority` varchar(100) DEFAULT 'High',
  `override_business_hours` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_audit`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_am_projecttemplates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_contacts_1_c`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_contacts_1_alt` (`am_projecttemplates_ida`,`contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_project_1_c`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_project_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_projecttemplates_project_1am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `am_projecttemplates_project_1project_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_project_1_ida1` (`am_projecttemplates_project_1am_projecttemplates_ida`),
  KEY `am_projecttemplates_project_1_alt` (`am_projecttemplates_project_1project_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_users_1_c`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_users_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `users_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_users_1_alt` (`am_projecttemplates_ida`,`users_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_tasktemplates`utf8_general_ci	;
CREATE TABLE `am_tasktemplates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `priority` varchar(100) DEFAULT 'High',
  `percent_complete` int(255) DEFAULT '0',
  `predecessors` int(255) DEFAULT NULL,
  `milestone_flag` tinyint(1) DEFAULT '0',
  `relationship_type` varchar(100) DEFAULT 'FS',
  `task_number` int(255) DEFAULT NULL,
  `order_number` int(255) DEFAULT NULL,
  `estimated_effort` int(255) DEFAULT NULL,
  `utilization` varchar(100) DEFAULT '0',
  `duration` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_tasktemplates_am_projecttemplates_c`utf8_general_ci	;
CREATE TABLE `am_tasktemplates_am_projecttemplates_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_tasktemplates_am_projecttemplatesam_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `am_tasktemplates_am_projecttemplatesam_tasktemplates_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_tasktemplates_am_projecttemplates_ida1` (`am_tasktemplates_am_projecttemplatesam_projecttemplates_ida`),
  KEY `am_tasktemplates_am_projecttemplates_alt` (`am_tasktemplates_am_projecttemplatesam_tasktemplates_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_tasktemplates_audit`utf8_general_ci	;
CREATE TABLE `am_tasktemplates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_am_tasktemplates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aobh_businesshours`utf8_general_ci	;
CREATE TABLE `aobh_businesshours` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `opening_hours` varchar(100) DEFAULT '1',
  `closing_hours` varchar(100) DEFAULT '1',
  `open` tinyint(1) DEFAULT NULL,
  `day` varchar(100) DEFAULT 'monday',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aod_index`utf8_general_ci	;
CREATE TABLE `aod_index` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `last_optimised` datetime DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`aod_index`utf8_general_ci	;
INSERT INTO `aod_index` VALUES 
('1','Index','2017-05-24 10:52:17','2017-05-24 10:52:17','1','1',\N,0,\N,\N,'modules/AOD_Index/Index/Index')	;
#	TC`aod_index_audit`utf8_general_ci	;
CREATE TABLE `aod_index_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aod_index_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aod_indexevent`utf8_general_ci	;
CREATE TABLE `aod_indexevent` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  `success` tinyint(1) DEFAULT '0',
  `record_id` char(36) DEFAULT NULL,
  `record_module` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_record_module` (`record_module`),
  KEY `idx_record_id` (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`aod_indexevent`utf8_general_ci	;
INSERT INTO `aod_indexevent` VALUES 
('108496bb-4fa1-1a59-6a78-5927e621c70b','Общество с ограниченной ответственностью «Эффективные технологии»','2017-05-26 08:26:49','2017-05-28 17:37:21','1','1',\N,0,'',\N,1,'f1c17d43-b29f-16ef-5774-5927e6b4501a','Accounts'),
('1ef5cc1d-e67d-8962-0225-5927e5aaa735','Семён Антонов','2017-05-26 08:23:21','2017-05-26 08:25:16','1','1',\N,0,'',\N,1,'e41e39af-5bdc-0b83-c659-5927e5a9adf7','Contacts'),
('6747c645-dedb-78dd-c2e4-59272dca0930','443068, г. Самара, ул. Ново-Садовая, д. 106, оф. 613','2017-05-25 19:16:57','2017-05-25 19:21:26','1','1',\N,0,'',\N,1,'55092ca4-45ce-f10f-c85d-59272dbd7b35','dp_realty'),
('d33cb93f-01f4-c838-89ba-5925713e42ae','Общество с ограниченной ответственностью «Солнечная долина»','2017-05-24 11:42:01','2017-05-26 07:51:40','1','1',\N,0,'',\N,1,'b9f49b4f-21dc-4a20-5646-592571b11c40','Accounts'),
('dd92d96c-96f4-a95d-2a55-5926d365a66d','Российский капитал','2017-05-25 12:54:05','2017-05-25 12:54:05','1','1',\N,0,\N,\N,1,'cc7ac549-b341-f38a-0bdc-5926d3163ea2','dp_bkrv')	;
#	TC`aod_indexevent_audit`utf8_general_ci	;
CREATE TABLE `aod_indexevent_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aod_indexevent_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledge_base_categories`utf8_general_ci	;
CREATE TABLE `aok_knowledge_base_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledge_base_categories_audit`utf8_general_ci	;
CREATE TABLE `aok_knowledge_base_categories_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aok_knowledge_base_categories_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledgebase`utf8_general_ci	;
CREATE TABLE `aok_knowledgebase` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Draft',
  `revision` varchar(255) DEFAULT NULL,
  `additional_info` text,
  `user_id_c` char(36) DEFAULT NULL,
  `user_id1_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledgebase_audit`utf8_general_ci	;
CREATE TABLE `aok_knowledgebase_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aok_knowledgebase_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledgebase_categories`utf8_general_ci	;
CREATE TABLE `aok_knowledgebase_categories` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aok_knowledgebase_id` varchar(36) DEFAULT NULL,
  `aok_knowledge_base_categories_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aok_knowledgebase_categories_alt` (`aok_knowledgebase_id`,`aok_knowledge_base_categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_events`utf8_general_ci	;
CREATE TABLE `aop_case_events` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_events_audit`utf8_general_ci	;
CREATE TABLE `aop_case_events_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aop_case_events_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_updates`utf8_general_ci	;
CREATE TABLE `aop_case_updates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `internal` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_updates_audit`utf8_general_ci	;
CREATE TABLE `aop_case_updates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aop_case_updates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_charts`utf8_general_ci	;
CREATE TABLE `aor_charts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aor_report_id` char(36) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `x_field` int(11) DEFAULT NULL,
  `y_field` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_conditions`utf8_general_ci	;
CREATE TABLE `aor_conditions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aor_report_id` char(36) DEFAULT NULL,
  `condition_order` int(255) DEFAULT NULL,
  `logic_op` varchar(255) DEFAULT NULL,
  `parenthesis` varchar(255) DEFAULT NULL,
  `module_path` longtext,
  `field` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `value_type` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `parameter` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aor_conditions_index_report_id` (`aor_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_fields`utf8_general_ci	;
CREATE TABLE `aor_fields` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aor_report_id` char(36) DEFAULT NULL,
  `field_order` int(255) DEFAULT NULL,
  `module_path` longtext,
  `field` varchar(100) DEFAULT NULL,
  `display` tinyint(1) DEFAULT NULL,
  `link` tinyint(1) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `field_function` varchar(100) DEFAULT NULL,
  `sort_by` varchar(100) DEFAULT NULL,
  `format` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `sort_order` varchar(100) DEFAULT NULL,
  `group_by` tinyint(1) DEFAULT NULL,
  `group_order` varchar(100) DEFAULT NULL,
  `group_display` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aor_fields_index_report_id` (`aor_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_reports`utf8_general_ci	;
CREATE TABLE `aor_reports` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `report_module` varchar(100) DEFAULT NULL,
  `graphs_per_row` int(11) DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_reports_audit`utf8_general_ci	;
CREATE TABLE `aor_reports_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aor_reports_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_scheduled_reports`utf8_general_ci	;
CREATE TABLE `aor_scheduled_reports` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `schedule` varchar(100) DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `email_recipients` longtext,
  `aor_report_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_contracts`utf8_general_ci	;
CREATE TABLE `aos_contracts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `reference_code` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `total_contract_value` decimal(26,6) DEFAULT NULL,
  `total_contract_value_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `customer_signed_date` date DEFAULT NULL,
  `company_signed_date` date DEFAULT NULL,
  `renewal_reminder_date` datetime DEFAULT NULL,
  `contract_type` varchar(100) DEFAULT 'Type',
  `contract_account_id` char(36) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `call_id` char(36) DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_contracts_audit`utf8_general_ci	;
CREATE TABLE `aos_contracts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_contracts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_contracts_documents`utf8_general_ci	;
CREATE TABLE `aos_contracts_documents` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_contracts_id` varchar(36) DEFAULT NULL,
  `documents_id` varchar(36) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_contracts_documents_alt` (`aos_contracts_id`,`documents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_invoices`utf8_general_ci	;
CREATE TABLE `aos_invoices` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `billing_account_id` char(36) DEFAULT NULL,
  `billing_contact_id` char(36) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `quote_number` int(11) DEFAULT NULL,
  `quote_date` date DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `template_ddown_c` text,
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_invoices_audit`utf8_general_ci	;
CREATE TABLE `aos_invoices_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_invoices_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_line_item_groups`utf8_general_ci	;
CREATE TABLE `aos_line_item_groups` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_line_item_groups_audit`utf8_general_ci	;
CREATE TABLE `aos_line_item_groups_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_line_item_groups_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_pdf_templates`utf8_general_ci	;
CREATE TABLE `aos_pdf_templates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `type` varchar(100) DEFAULT NULL,
  `pdfheader` text,
  `pdffooter` text,
  `margin_left` int(255) DEFAULT '15',
  `margin_right` int(255) DEFAULT '15',
  `margin_top` int(255) DEFAULT '16',
  `margin_bottom` int(255) DEFAULT '16',
  `margin_header` int(255) DEFAULT '9',
  `margin_footer` int(255) DEFAULT '9',
  `page_size` varchar(100) DEFAULT NULL,
  `orientation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_pdf_templates_audit`utf8_general_ci	;
CREATE TABLE `aos_pdf_templates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_pdf_templates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_product_categories`utf8_general_ci	;
CREATE TABLE `aos_product_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT '0',
  `parent_category_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_product_categories_audit`utf8_general_ci	;
CREATE TABLE `aos_product_categories_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_product_categories_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products`utf8_general_ci	;
CREATE TABLE `aos_products` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `maincode` varchar(100) DEFAULT 'XXXX',
  `part_number` varchar(25) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT 'Good',
  `cost` decimal(26,6) DEFAULT NULL,
  `cost_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `price` decimal(26,6) DEFAULT NULL,
  `price_usdollar` decimal(26,6) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `aos_product_category_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products_audit`utf8_general_ci	;
CREATE TABLE `aos_products_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_products_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products_quotes`utf8_general_ci	;
CREATE TABLE `aos_products_quotes` (
  `id` char(36) NOT NULL,
  `name` text,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `part_number` varchar(255) DEFAULT NULL,
  `item_description` text,
  `number` int(11) DEFAULT NULL,
  `product_qty` decimal(18,4) DEFAULT NULL,
  `product_cost_price` decimal(26,6) DEFAULT NULL,
  `product_cost_price_usdollar` decimal(26,6) DEFAULT NULL,
  `product_list_price` decimal(26,6) DEFAULT NULL,
  `product_list_price_usdollar` decimal(26,6) DEFAULT NULL,
  `product_discount` decimal(26,6) DEFAULT NULL,
  `product_discount_usdollar` decimal(26,6) DEFAULT NULL,
  `product_discount_amount` decimal(26,6) DEFAULT NULL,
  `product_discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount` varchar(255) DEFAULT 'Percentage',
  `product_unit_price` decimal(26,6) DEFAULT NULL,
  `product_unit_price_usdollar` decimal(26,6) DEFAULT NULL,
  `vat_amt` decimal(26,6) DEFAULT NULL,
  `vat_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `product_total_price` decimal(26,6) DEFAULT NULL,
  `product_total_price_usdollar` decimal(26,6) DEFAULT NULL,
  `vat` varchar(100) DEFAULT '5.0',
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `product_id` char(36) DEFAULT NULL,
  `group_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aospq_par_del` (`parent_id`,`parent_type`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products_quotes_audit`utf8_general_ci	;
CREATE TABLE `aos_products_quotes_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_products_quotes_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes`utf8_general_ci	;
CREATE TABLE `aos_quotes` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `approval_issue` text,
  `billing_account_id` char(36) DEFAULT NULL,
  `billing_contact_id` char(36) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `expiration` date DEFAULT NULL,
  `number` int(11) NOT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `template_ddown_c` text,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `stage` varchar(100) DEFAULT 'Draft',
  `term` varchar(100) DEFAULT NULL,
  `terms_c` text,
  `approval_status` varchar(100) DEFAULT NULL,
  `invoice_status` varchar(100) DEFAULT 'Not Invoiced',
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_aos_invoices_c`utf8_general_ci	;
CREATE TABLE `aos_quotes_aos_invoices_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_quotes77d9_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes6b83nvoices_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_aos_invoices_alt` (`aos_quotes77d9_quotes_ida`,`aos_quotes6b83nvoices_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_audit`utf8_general_ci	;
CREATE TABLE `aos_quotes_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_quotes_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_os_contracts_c`utf8_general_ci	;
CREATE TABLE `aos_quotes_os_contracts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_quotese81e_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes4dc0ntracts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_aos_contracts_alt` (`aos_quotese81e_quotes_ida`,`aos_quotes4dc0ntracts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_project_c`utf8_general_ci	;
CREATE TABLE `aos_quotes_project_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_quotes1112_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes7207project_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_project_alt` (`aos_quotes1112_quotes_ida`,`aos_quotes7207project_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_actions`utf8_general_ci	;
CREATE TABLE `aow_actions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aow_workflow_id` char(36) DEFAULT NULL,
  `action_order` int(255) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `parameters` longtext,
  PRIMARY KEY (`id`),
  KEY `aow_action_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_conditions`utf8_general_ci	;
CREATE TABLE `aow_conditions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aow_workflow_id` char(36) DEFAULT NULL,
  `condition_order` int(255) DEFAULT NULL,
  `module_path` longtext,
  `field` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aow_conditions_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_processed`utf8_general_ci	;
CREATE TABLE `aow_processed` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aow_workflow_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  KEY `aow_processed_index_workflow` (`aow_workflow_id`,`status`,`parent_id`,`deleted`),
  KEY `aow_processed_index_status` (`status`),
  KEY `aow_processed_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_processed_aow_actions`utf8_general_ci	;
CREATE TABLE `aow_processed_aow_actions` (
  `id` varchar(36) NOT NULL,
  `aow_processed_id` varchar(36) DEFAULT NULL,
  `aow_action_id` varchar(36) DEFAULT NULL,
  `status` varchar(36) DEFAULT 'Pending',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aow_processed_aow_actions` (`aow_processed_id`,`aow_action_id`),
  KEY `idx_actid_del_freid` (`aow_action_id`,`deleted`,`aow_processed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_workflow`utf8_general_ci	;
CREATE TABLE `aow_workflow` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `flow_module` varchar(100) DEFAULT NULL,
  `flow_run_on` varchar(100) DEFAULT '0',
  `status` varchar(100) DEFAULT 'Active',
  `run_when` varchar(100) DEFAULT 'Always',
  `multiple_runs` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `aow_workflow_index_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_workflow_audit`utf8_general_ci	;
CREATE TABLE `aow_workflow_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aow_workflow_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`bugs`utf8_general_ci	;
CREATE TABLE `bugs` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `bug_number` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  `resolution` varchar(255) DEFAULT NULL,
  `work_log` text,
  `found_in_release` varchar(255) DEFAULT NULL,
  `fixed_in_release` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `product_category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bugsnumk` (`bug_number`),
  KEY `bug_number` (`bug_number`),
  KEY `idx_bug_name` (`name`),
  KEY `idx_bugs_assigned_user` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`bugs_audit`utf8_general_ci	;
CREATE TABLE `bugs_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_bugs_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls`utf8_general_ci	;
CREATE TABLE `calls` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `duration_hours` int(2) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planned',
  `direction` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT '-1',
  `email_reminder_time` int(11) DEFAULT '-1',
  `email_reminder_sent` tinyint(1) DEFAULT '0',
  `outlook_id` varchar(255) DEFAULT NULL,
  `repeat_type` varchar(36) DEFAULT NULL,
  `repeat_interval` int(3) DEFAULT '1',
  `repeat_dow` varchar(7) DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_count` int(7) DEFAULT NULL,
  `repeat_parent_id` char(36) DEFAULT NULL,
  `recurring_source` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_call_name` (`name`),
  KEY `idx_status` (`status`),
  KEY `idx_calls_date_start` (`date_start`),
  KEY `idx_calls_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_calls_assigned_del` (`deleted`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_contacts`utf8_general_ci	;
CREATE TABLE `calls_contacts` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_call_call` (`call_id`),
  KEY `idx_con_call_con` (`contact_id`),
  KEY `idx_call_contact` (`call_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_leads`utf8_general_ci	;
CREATE TABLE `calls_leads` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `lead_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lead_call_call` (`call_id`),
  KEY `idx_lead_call_lead` (`lead_id`),
  KEY `idx_call_lead` (`call_id`,`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_reschedule`utf8_general_ci	;
CREATE TABLE `calls_reschedule` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `call_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_reschedule_audit`utf8_general_ci	;
CREATE TABLE `calls_reschedule_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_calls_reschedule_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_users`utf8_general_ci	;
CREATE TABLE `calls_users` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usr_call_call` (`call_id`),
  KEY `idx_usr_call_usr` (`user_id`),
  KEY `idx_call_users` (`call_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaign_log`utf8_general_ci	;
CREATE TABLE `campaign_log` (
  `id` char(36) NOT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `target_tracker_key` varchar(36) DEFAULT NULL,
  `target_id` varchar(36) DEFAULT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `activity_type` varchar(100) DEFAULT NULL,
  `activity_date` datetime DEFAULT NULL,
  `related_id` varchar(36) DEFAULT NULL,
  `related_type` varchar(100) DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `hits` int(11) DEFAULT '0',
  `list_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `more_information` varchar(100) DEFAULT NULL,
  `marketing_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_camp_tracker` (`target_tracker_key`),
  KEY `idx_camp_campaign_id` (`campaign_id`),
  KEY `idx_camp_more_info` (`more_information`),
  KEY `idx_target_id` (`target_id`),
  KEY `idx_target_id_deleted` (`target_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaign_trkrs`utf8_general_ci	;
CREATE TABLE `campaign_trkrs` (
  `id` char(36) NOT NULL,
  `tracker_name` varchar(30) DEFAULT NULL,
  `tracker_url` varchar(255) DEFAULT 'http://',
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` char(36) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `is_optout` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `campaign_tracker_key_idx` (`tracker_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaigns`utf8_general_ci	;
CREATE TABLE `campaigns` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_count` int(11) DEFAULT '0',
  `refer_url` varchar(255) DEFAULT 'http://',
  `tracker_text` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `impressions` int(11) DEFAULT '0',
  `currency_id` char(36) DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `expected_cost` double DEFAULT NULL,
  `actual_cost` double DEFAULT NULL,
  `expected_revenue` double DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `objective` text,
  `content` text,
  `frequency` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `camp_auto_tracker_key` (`tracker_key`),
  KEY `idx_campaign_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaigns_audit`utf8_general_ci	;
CREATE TABLE `campaigns_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_campaigns_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases`utf8_general_ci	;
CREATE TABLE `cases` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_number` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  `resolution` text,
  `work_log` text,
  `account_id` char(36) DEFAULT NULL,
  `state` varchar(100) DEFAULT 'Open',
  `contact_created_by_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `casesnumk` (`case_number`),
  KEY `case_number` (`case_number`),
  KEY `idx_case_name` (`name`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_cases_stat_del` (`assigned_user_id`,`status`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases_audit`utf8_general_ci	;
CREATE TABLE `cases_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_cases_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases_bugs`utf8_general_ci	;
CREATE TABLE `cases_bugs` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cas_bug_cas` (`case_id`),
  KEY `idx_cas_bug_bug` (`bug_id`),
  KEY `idx_case_bug` (`case_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases_cstm`utf8_general_ci	;
CREATE TABLE `cases_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`config`utf8_general_ci	;
CREATE TABLE `config` (
  `category` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `value` text,
  KEY `idx_config_cat` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`config`utf8_general_ci	;
INSERT INTO `config` VALUES 
('notify','fromaddress','web@finexpert.pro'),
('notify','fromname','ФинЭксперт'),
('notify','send_by_default','1'),
('notify','on','1'),
('notify','send_from_assigning_user','0'),
('info','sugar_version','6.5.24'),
('MySettings','tab','YTozOTp7czo0OiJIb21lIjtzOjQ6IkhvbWUiO3M6ODoiQWNjb3VudHMiO3M6ODoiQWNjb3VudHMiO3M6ODoiQ29udGFjdHMiO3M6ODoiQ29udGFjdHMiO3M6MTM6Ik9wcG9ydHVuaXRpZXMiO3M6MTM6Ik9wcG9ydHVuaXRpZXMiO3M6NToiTGVhZHMiO3M6NToiTGVhZHMiO3M6MTA6IkFPU19RdW90ZXMiO3M6MTA6IkFPU19RdW90ZXMiO3M6ODoiQ2FsZW5kYXIiO3M6ODoiQ2FsZW5kYXIiO3M6OToiRG9jdW1lbnRzIjtzOjk6IkRvY3VtZW50cyI7czo2OiJFbWFpbHMiO3M6NjoiRW1haWxzIjtzOjU6IlNwb3RzIjtzOjU6IlNwb3RzIjtzOjk6IkNhbXBhaWducyI7czo5OiJDYW1wYWlnbnMiO3M6NToiQ2FsbHMiO3M6NToiQ2FsbHMiO3M6ODoiTWVldGluZ3MiO3M6ODoiTWVldGluZ3MiO3M6NToiVGFza3MiO3M6NToiVGFza3MiO3M6NToiTm90ZXMiO3M6NToiTm90ZXMiO3M6MTI6IkFPU19JbnZvaWNlcyI7czoxMjoiQU9TX0ludm9pY2VzIjtzOjEzOiJBT1NfQ29udHJhY3RzIjtzOjEzOiJBT1NfQ29udHJhY3RzIjtzOjU6IkNhc2VzIjtzOjU6IkNhc2VzIjtzOjk6IlByb3NwZWN0cyI7czo5OiJQcm9zcGVjdHMiO3M6MTM6IlByb3NwZWN0TGlzdHMiO3M6MTM6IlByb3NwZWN0TGlzdHMiO3M6NzoiUHJvamVjdCI7czo3OiJQcm9qZWN0IjtzOjE5OiJBTV9Qcm9qZWN0VGVtcGxhdGVzIjtzOjE5OiJBTV9Qcm9qZWN0VGVtcGxhdGVzIjtzOjk6IkZQX2V2ZW50cyI7czo5OiJGUF9ldmVudHMiO3M6MTg6IkZQX0V2ZW50X0xvY2F0aW9ucyI7czoxODoiRlBfRXZlbnRfTG9jYXRpb25zIjtzOjEyOiJBT1NfUHJvZHVjdHMiO3M6MTI6IkFPU19Qcm9kdWN0cyI7czoyMjoiQU9TX1Byb2R1Y3RfQ2F0ZWdvcmllcyI7czoyMjoiQU9TX1Byb2R1Y3RfQ2F0ZWdvcmllcyI7czoxNzoiQU9TX1BERl9UZW1wbGF0ZXMiO3M6MTc6IkFPU19QREZfVGVtcGxhdGVzIjtzOjk6Impqd2dfTWFwcyI7czo5OiJqandnX01hcHMiO3M6MTI6Impqd2dfTWFya2VycyI7czoxMjoiamp3Z19NYXJrZXJzIjtzOjEwOiJqandnX0FyZWFzIjtzOjEwOiJqandnX0FyZWFzIjtzOjE4OiJqandnX0FkZHJlc3NfQ2FjaGUiO3M6MTg6Impqd2dfQWRkcmVzc19DYWNoZSI7czoxMToiQU9SX1JlcG9ydHMiO3M6MTE6IkFPUl9SZXBvcnRzIjtzOjEyOiJBT1dfV29ya0Zsb3ciO3M6MTI6IkFPV19Xb3JrRmxvdyI7czoxNzoiQU9LX0tub3dsZWRnZUJhc2UiO3M6MTc6IkFPS19Lbm93bGVkZ2VCYXNlIjtzOjI5OiJBT0tfS25vd2xlZGdlX0Jhc2VfQ2F0ZWdvcmllcyI7czoyOToiQU9LX0tub3dsZWRnZV9CYXNlX0NhdGVnb3JpZXMiO3M6NzoiZHBfYmtydiI7czo3OiJkcF9ia3J2IjtzOjk6ImRwX3JlYWx0eSI7czo5OiJkcF9yZWFsdHkiO3M6MTA6ImRwX2xpY2Vuc2UiO3M6MTA6ImRwX2xpY2Vuc2UiO3M6MTI6InNyb19zdmlkX3NybyI7czoxMjoic3JvX3N2aWRfc3JvIjt9'),
('portal','on','0'),
('tracker','Tracker','1'),
('system','skypeout_on','1'),
('sugarfeed','enabled','1'),
('sugarfeed','module_UserFeed','1'),
('sugarfeed','module_Contacts','1'),
('sugarfeed','module_Leads','1'),
('sugarfeed','module_Opportunities','1'),
('sugarfeed','module_Cases','1'),
('Update','CheckUpdates','manual'),
('system','name','SuiteCRM'),
('system','adminwizard','1'),
('notify','allow_default_outbound','0')	;
#	TC`contacts`utf8_general_ci	;
CREATE TABLE `contacts` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `lead_source` varchar(255) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `joomla_account_id` varchar(255) DEFAULT NULL,
  `portal_account_disabled` tinyint(1) DEFAULT NULL,
  `portal_user_type` varchar(100) DEFAULT 'Single',
  PRIMARY KEY (`id`),
  KEY `idx_cont_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_contacts_del_last` (`deleted`,`last_name`),
  KEY `idx_cont_del_reports` (`deleted`,`reports_to_id`,`last_name`),
  KEY `idx_reports_to_id` (`reports_to_id`),
  KEY `idx_del_id_user` (`deleted`,`id`,`assigned_user_id`),
  KEY `idx_cont_assigned` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`contacts`utf8_general_ci	;
INSERT INTO `contacts` VALUES 
('e41e39af-5bdc-0b83-c659-5927e5a9adf7','2017-05-26 08:23:20','2017-05-26 08:25:16','1','1',\N,0,'1',\N,'Семён','Антонов',\N,\N,\N,0,\N,'+79879556095','+7(846)205-60-95',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,'',\N,'',\N,0,'Single')	;
#	TC`contacts_audit`utf8_general_ci	;
CREATE TABLE `contacts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_contacts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`contacts_bugs`utf8_general_ci	;
CREATE TABLE `contacts_bugs` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_bug_con` (`contact_id`),
  KEY `idx_con_bug_bug` (`bug_id`),
  KEY `idx_contact_bug` (`contact_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`contacts_cases`utf8_general_ci	;
CREATE TABLE `contacts_cases` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_case_con` (`contact_id`),
  KEY `idx_con_case_case` (`case_id`),
  KEY `idx_contacts_cases` (`contact_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`contacts_cstm`utf8_general_ci	;
CREATE TABLE `contacts_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  `patr_c` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`contacts_cstm`utf8_general_ci	;
INSERT INTO `contacts_cstm` VALUES 
('e41e39af-5bdc-0b83-c659-5927e5a9adf7',0.00000000,0.00000000,'','','Геннадьевич')	;
#	TC`contacts_users`utf8_general_ci	;
CREATE TABLE `contacts_users` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_users_con` (`contact_id`),
  KEY `idx_con_users_user` (`user_id`),
  KEY `idx_contacts_users` (`contact_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cron_remove_documents`utf8_general_ci	;
CREATE TABLE `cron_remove_documents` (
  `id` varchar(36) NOT NULL,
  `bean_id` varchar(36) DEFAULT NULL,
  `module` varchar(25) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cron_remove_document_bean_id` (`bean_id`),
  KEY `idx_cron_remove_document_stamp` (`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`currencies`utf8_general_ci	;
CREATE TABLE `currencies` (
  `id` char(36) NOT NULL,
  `name` varchar(36) DEFAULT NULL,
  `symbol` varchar(36) DEFAULT NULL,
  `iso4217` varchar(3) DEFAULT NULL,
  `conversion_rate` double DEFAULT '0',
  `status` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`custom_fields`utf8_general_ci	;
CREATE TABLE `custom_fields` (
  `bean_id` varchar(36) DEFAULT NULL,
  `set_num` int(11) DEFAULT '0',
  `field0` varchar(255) DEFAULT NULL,
  `field1` varchar(255) DEFAULT NULL,
  `field2` varchar(255) DEFAULT NULL,
  `field3` varchar(255) DEFAULT NULL,
  `field4` varchar(255) DEFAULT NULL,
  `field5` varchar(255) DEFAULT NULL,
  `field6` varchar(255) DEFAULT NULL,
  `field7` varchar(255) DEFAULT NULL,
  `field8` varchar(255) DEFAULT NULL,
  `field9` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  KEY `idx_beanid_set_num` (`bean_id`,`set_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`document_revisions`utf8_general_ci	;
CREATE TABLE `document_revisions` (
  `id` varchar(36) NOT NULL,
  `change_log` varchar(255) DEFAULT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `doc_id` varchar(100) DEFAULT NULL,
  `doc_type` varchar(100) DEFAULT NULL,
  `doc_url` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `file_ext` varchar(100) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `revision` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentrevision_mimetype` (`file_mime_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents`utf8_general_ci	;
CREATE TABLE `documents` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `document_name` varchar(255) DEFAULT NULL,
  `doc_id` varchar(100) DEFAULT NULL,
  `doc_type` varchar(100) DEFAULT 'Sugar',
  `doc_url` varchar(255) DEFAULT NULL,
  `active_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `subcategory_id` varchar(100) DEFAULT NULL,
  `status_id` varchar(100) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  `related_doc_id` char(36) DEFAULT NULL,
  `related_doc_rev_id` char(36) DEFAULT NULL,
  `is_template` tinyint(1) DEFAULT '0',
  `template_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_doc_cat` (`category_id`,`subcategory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_accounts`utf8_general_ci	;
CREATE TABLE `documents_accounts` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_accounts_account_id` (`account_id`,`document_id`),
  KEY `documents_accounts_document_id` (`document_id`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_bugs`utf8_general_ci	;
CREATE TABLE `documents_bugs` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_bugs_bug_id` (`bug_id`,`document_id`),
  KEY `documents_bugs_document_id` (`document_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_cases`utf8_general_ci	;
CREATE TABLE `documents_cases` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_cases_case_id` (`case_id`,`document_id`),
  KEY `documents_cases_document_id` (`document_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_contacts`utf8_general_ci	;
CREATE TABLE `documents_contacts` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_contacts_contact_id` (`contact_id`,`document_id`),
  KEY `documents_contacts_document_id` (`document_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_opportunities`utf8_general_ci	;
CREATE TABLE `documents_opportunities` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_docu_opps_oppo_id` (`opportunity_id`,`document_id`),
  KEY `idx_docu_oppo_docu_id` (`document_id`,`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_bkrv`utf8_general_ci	;
CREATE TABLE `dp_bkrv` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `rsch` varchar(25) DEFAULT NULL,
  `krch` varchar(20) DEFAULT NULL,
  `bik_bank` varchar(9) DEFAULT NULL,
  `inn_bank` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_bkrv`utf8_general_ci	;
INSERT INTO `dp_bkrv` VALUES 
('cc7ac549-b341-f38a-0bdc-5926d3163ea2','Российский капитал','2017-05-25 12:54:05','2017-05-25 12:54:05','1','1','',0,'1','239845698374658973645','8443534','8345693','82764538')	;
#	TC`dp_bkrv_accounts_c`utf8_general_ci	;
CREATE TABLE `dp_bkrv_accounts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `dp_bkrv_accountsaccounts_ida` varchar(36) DEFAULT NULL,
  `dp_bkrv_accountsdp_bkrv_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_bkrv_accounts_ida1` (`dp_bkrv_accountsaccounts_ida`),
  KEY `dp_bkrv_accounts_alt` (`dp_bkrv_accountsdp_bkrv_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_bkrv_accounts_c`utf8_general_ci	;
INSERT INTO `dp_bkrv_accounts_c` VALUES 
('ce33ed69-8e6e-6754-e112-5926d37e962c','2017-05-25 12:54:05',0,'b9f49b4f-21dc-4a20-5646-592571b11c40','cc7ac549-b341-f38a-0bdc-5926d3163ea2')	;
#	TC`dp_bkrv_audit`utf8_general_ci	;
CREATE TABLE `dp_bkrv_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_bkrv_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_license`utf8_general_ci	;
CREATE TABLE `dp_license` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_license_audit`utf8_general_ci	;
CREATE TABLE `dp_license_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_license_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_license_cstm`utf8_general_ci	;
CREATE TABLE `dp_license_cstm` (
  `id_c` char(36) NOT NULL,
  `num_license_c` varchar(20) DEFAULT NULL,
  `date_license_c` date DEFAULT NULL,
  `bywhom_license_c` varchar(100) DEFAULT NULL,
  `account_id_c` char(36) DEFAULT NULL,
  `srok_work_license_c` date DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_realty`utf8_general_ci	;
CREATE TABLE `dp_realty` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status_nedv` varchar(100) DEFAULT NULL,
  `area_nedv` int(10) DEFAULT NULL,
  `target_nedv` varchar(100) DEFAULT NULL,
  `num_svid_nedv` varchar(30) DEFAULT NULL,
  `date_reg_nedv` date DEFAULT NULL,
  `num_dogovor_arend` varchar(20) DEFAULT NULL,
  `date_reg_dogovor_arend` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_realty`utf8_general_ci	;
INSERT INTO `dp_realty` VALUES 
('55092ca4-45ce-f10f-c85d-59272dbd7b35','443068, г. Самара, ул. Ново-Садовая, д. 106, оф. 613','2017-05-25 19:16:57','2017-05-25 19:21:26','1','1',\N,0,'1','arenda',53,'office',\N,\N,\N,\N)	;
#	TC`dp_realty_accounts_c`utf8_general_ci	;
CREATE TABLE `dp_realty_accounts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `dp_realty_accountsaccounts_ida` varchar(36) DEFAULT NULL,
  `dp_realty_accountsdp_realty_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_realty_accounts_ida1` (`dp_realty_accountsaccounts_ida`),
  KEY `dp_realty_accounts_alt` (`dp_realty_accountsdp_realty_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_realty_accounts_c`utf8_general_ci	;
INSERT INTO `dp_realty_accounts_c` VALUES 
('57169c46-7045-9182-e365-59272db8b573','2017-05-25 19:16:57',0,'b9f49b4f-21dc-4a20-5646-592571b11c40','55092ca4-45ce-f10f-c85d-59272dbd7b35')	;
#	TC`dp_realty_audit`utf8_general_ci	;
CREATE TABLE `dp_realty_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_realty_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`eapm`utf8_general_ci	;
CREATE TABLE `eapm` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `application` varchar(100) DEFAULT 'webex',
  `api_data` text,
  `consumer_key` varchar(255) DEFAULT NULL,
  `consumer_secret` varchar(255) DEFAULT NULL,
  `oauth_token` varchar(255) DEFAULT NULL,
  `oauth_secret` varchar(255) DEFAULT NULL,
  `validated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_active` (`assigned_user_id`,`application`,`validated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_addr_bean_rel`utf8_general_ci	;
CREATE TABLE `email_addr_bean_rel` (
  `id` char(36) NOT NULL,
  `email_address_id` char(36) NOT NULL,
  `bean_id` char(36) NOT NULL,
  `bean_module` varchar(100) DEFAULT NULL,
  `primary_address` tinyint(1) DEFAULT '0',
  `reply_to_address` tinyint(1) DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_email_address_id` (`email_address_id`),
  KEY `idx_bean_id` (`bean_id`,`bean_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`email_addr_bean_rel`utf8_general_ci	;
INSERT INTO `email_addr_bean_rel` VALUES 
('2d536e55-b78f-7d76-5acb-5928032fbae8','2d63584a-c431-7ee0-9d12-5928039316ff','f1c17d43-b29f-16ef-5774-5927e6b4501a','Accounts',1,0,'2017-05-26 10:29:49','2017-05-26 10:29:49',0),
('2f424982-e72a-fbe1-664e-592803abe908','ae470cfc-302b-46c8-8425-592564a4429a','f1c17d43-b29f-16ef-5774-5927e6b4501a','Accounts',0,0,'2017-05-26 10:29:49','2017-05-26 10:29:49',0),
('ae332e3a-16b6-cc09-37f9-5925648d9340','ae470cfc-302b-46c8-8425-592564a4429a','1','Users',1,0,'2017-05-24 10:47:24','2017-05-24 10:47:24',0)	;
#	TC`email_addresses`utf8_general_ci	;
CREATE TABLE `email_addresses` (
  `id` char(36) NOT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `email_address_caps` varchar(255) DEFAULT NULL,
  `invalid_email` tinyint(1) DEFAULT '0',
  `opt_out` tinyint(1) DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ea_caps_opt_out_invalid` (`email_address_caps`,`opt_out`,`invalid_email`),
  KEY `idx_ea_opt_out_invalid` (`email_address`,`opt_out`,`invalid_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`email_addresses`utf8_general_ci	;
INSERT INTO `email_addresses` VALUES 
('2d63584a-c431-7ee0-9d12-5928039316ff','info@fksrf.pro','INFO@FKSRF.PRO',0,0,'2017-05-26 10:29:49','2017-05-26 10:29:49',0),
('ae470cfc-302b-46c8-8425-592564a4429a','web@fksrf.pro','WEB@FKSRF.PRO',0,0,'2017-05-24 10:47:24','2017-05-24 10:47:24',0)	;
#	TC`email_cache`utf8_general_ci	;
CREATE TABLE `email_cache` (
  `ie_id` char(36) DEFAULT NULL,
  `mbox` varchar(60) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `fromaddr` varchar(100) DEFAULT NULL,
  `toaddr` varchar(255) DEFAULT NULL,
  `senddate` datetime DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `mailsize` int(10) unsigned DEFAULT NULL,
  `imap_uid` int(10) unsigned DEFAULT NULL,
  `msgno` int(10) unsigned DEFAULT NULL,
  `recent` tinyint(4) DEFAULT NULL,
  `flagged` tinyint(4) DEFAULT NULL,
  `answered` tinyint(4) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `seen` tinyint(4) DEFAULT NULL,
  `draft` tinyint(4) DEFAULT NULL,
  KEY `idx_ie_id` (`ie_id`),
  KEY `idx_mail_date` (`ie_id`,`mbox`,`senddate`),
  KEY `idx_mail_from` (`ie_id`,`mbox`,`fromaddr`),
  KEY `idx_mail_subj` (`subject`),
  KEY `idx_mail_to` (`toaddr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_marketing`utf8_general_ci	;
CREATE TABLE `email_marketing` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `from_name` varchar(100) DEFAULT NULL,
  `from_addr` varchar(100) DEFAULT NULL,
  `reply_to_name` varchar(100) DEFAULT NULL,
  `reply_to_addr` varchar(100) DEFAULT NULL,
  `inbound_email_id` varchar(36) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `template_id` char(36) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `outbound_email_id` char(36) DEFAULT NULL,
  `all_prospect_lists` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emmkt_name` (`name`),
  KEY `idx_emmkit_del` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_marketing_prospect_lists`utf8_general_ci	;
CREATE TABLE `email_marketing_prospect_lists` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `email_marketing_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email_mp_prospects` (`email_marketing_id`,`prospect_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_templates`utf8_general_ci	;
CREATE TABLE `email_templates` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `published` varchar(3) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `body_html` text,
  `deleted` tinyint(1) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `text_only` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_template_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`email_templates`utf8_general_ci	;
INSERT INTO `email_templates` VALUES 
('bff53f0a-2eb5-3f4c-41e7-592564cebbf8','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','System-generated password email','This template is used when the System Administrator sends a new password to a user.','New account information','\nHere is your account username and temporary password:\nUsername : $contact_user_user_name\nPassword : $contact_user_user_hash\n\n$config_site_url\n\nAfter you log in using the above password, you may be required to reset the password to one of your own choice.','<div><table width=\"550\"><tbody><tr><td><p>Here is your account username and temporary password:</p><p>Username : $contact_user_user_name </p><p>Password : $contact_user_user_hash </p><br /><p>$config_site_url</p><br /><p>After you log in using the above password, you may be required to reset the password to one of your own choice.</p>   </td>         </tr><tr><td></td>         </tr></tbody></table></div>',0,\N,0,\N),
('c28d3d07-a18f-eb2d-ddcd-592564f26138','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Forgot Password email','This template is used to send a user a link to click to reset the user\'s account password.','Reset your account password','\nYou recently requested on $contact_user_pwd_last_changed to be able to reset your account password.\n\nClick on the link below to reset your password:\n\n$contact_user_link_guid','<div><table width=\"550\"><tbody><tr><td><p>You recently requested on $contact_user_pwd_last_changed to be able to reset your account password. </p><p>Click on the link below to reset your password:</p><p> $contact_user_link_guid </p>  </td>         </tr><tr><td></td>         </tr></tbody></table></div>',0,\N,0,\N),
('dc4ad7b4-d6ac-7727-02d4-59256490e1fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Case Closure','Template for informing a contact that their case has been closed.','$acase_name [CASE:$acase_case_number] closed','Hi $contact_first_name $contact_last_name,\n\n					   Your case $acase_name (# $acase_case_number) has been closed on $acase_date_entered\n					   Status:				$acase_status\n					   Reference:			$acase_case_number\n					   Resolution:			$acase_resolution','<p> Hi $contact_first_name $contact_last_name,</p>\n					    <p>Your case $acase_name (# $acase_case_number) has been closed on $acase_date_entered</p>\n					    <table border=\"0\"><tbody><tr><td>Status</td><td>$acase_status</td></tr><tr><td>Reference</td><td>$acase_case_number</td></tr><tr><td>Resolution</td><td>$acase_resolution</td></tr></tbody></table>',0,\N,\N,\N),
('ded79ede-3f16-4286-5758-5925648b6ab7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Joomla Account Creation','Template used when informing a contact that they\'ve been given an account on the joomla portal.','Support Portal Account Created','Hi $contact_name,\n					   An account has been created for you at $portal_address.\n					   You may login using this email address and the password $joomla_pass','<p>Hi $contact_name,</p>\n					    <p>An account has been created for you at <a href=\"$portal_address\">$portal_address</a>.</p>\n					    <p>You may login using this email address and the password $joomla_pass</p>',0,\N,\N,\N),
('e1851900-1e03-5229-0560-592564416186','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Case Creation','Template to send to a contact when a case is received from them.','$acase_name [CASE:$acase_case_number]','Hi $contact_first_name $contact_last_name,\n\n					   We\'ve received your case $acase_name (# $acase_case_number) on $acase_date_entered\n					   Status:		$acase_status\n					   Reference:	$acase_case_number\n					   Description:	$acase_description','<p> Hi $contact_first_name $contact_last_name,</p>\n					    <p>We\'ve received your case $acase_name (# $acase_case_number) on $acase_date_entered</p>\n					    <table border=\"0\"><tbody><tr><td>Status</td><td>$acase_status</td></tr><tr><td>Reference</td><td>$acase_case_number</td></tr><tr><td>Description</td><td>$acase_description</td></tr></tbody></table>',0,\N,\N,\N),
('e4b8b10c-83f4-a8bb-8fce-5925647324c0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Contact Case Update','Template to send to a contact when their case is updated.','$acase_name update [CASE:$acase_case_number]','Hi $user_first_name $user_last_name,\n\n					   You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:\n					       $contact_first_name $contact_last_name, said:\n					               $aop_case_updates_description','<p>Hi $contact_first_name $contact_last_name,</p>\n					    <p> </p>\n					    <p>You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:</p>\n					    <p><strong>$user_first_name $user_last_name said:</strong></p>\n					    <p style=\"padding-left:30px;\">$aop_case_updates_description</p>',0,\N,\N,\N),
('e7729ed9-9530-cd0e-4868-5925644484bb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','User Case Update','Email template to send to a Sugar user when their case is updated.','$acase_name (# $acase_case_number) update','Hi $user_first_name $user_last_name,\n\n					   You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:\n					       $contact_first_name $contact_last_name, said:\n					               $aop_case_updates_description\n                        You may review this Case at:\n                            $sugarurl/index.php?module=Cases&action=DetailView&record=$acase_id;','<p>Hi $user_first_name $user_last_name,</p>\n					   <p> </p>\n					   <p>You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:</p>\n					   <p><strong>$contact_first_name $contact_last_name, said:</strong></p>\n					   <p style=\"padding-left:30px;\">$aop_case_updates_description</p>\n					   <p>You may review this Case at: $sugarurl/index.php?module=Cases&action=DetailView&record=$acase_id;</p>\n					   ',0,\N,\N,\N),
('ecd98b03-0523-3d10-dc13-592564de2f8e','2013-05-24 14:31:45','2017-05-24 10:47:24','1','1','off','Event Invite Template','Default event invite template.','You have been invited to $fp_events_name','Dear $contact_name,\r\nYou have been invited to $fp_events_name on $fp_events_date_start to $fp_events_date_end\r\n$fp_events_description\r\nYours Sincerely,\r\n','\n<p>Dear $contact_name,</p>\n<p>You have been invited to $fp_events_name on $fp_events_date_start to $fp_events_date_end</p>\n<p>$fp_events_description</p>\n<p>If you would like to accept this invititation please click accept.</p>\n<p> $fp_events_link or $fp_events_link_declined</p>\n<p>Yours Sincerely,</p>\n',0,\N,\N,'email')	;
#	TC`emailman`utf8_general_ci	;
CREATE TABLE `emailman` (
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` char(36) DEFAULT NULL,
  `marketing_id` char(36) DEFAULT NULL,
  `list_id` char(36) DEFAULT NULL,
  `send_date_time` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `in_queue` tinyint(1) DEFAULT '0',
  `in_queue_date` datetime DEFAULT NULL,
  `send_attempts` int(11) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  `related_id` char(36) DEFAULT NULL,
  `related_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eman_list` (`list_id`,`user_id`,`deleted`),
  KEY `idx_eman_campaign_id` (`campaign_id`),
  KEY `idx_eman_relid_reltype_id` (`related_id`,`related_type`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails`utf8_general_ci	;
CREATE TABLE `emails` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `flagged` tinyint(1) DEFAULT NULL,
  `reply_to_status` tinyint(1) DEFAULT NULL,
  `intent` varchar(100) DEFAULT 'pick',
  `mailbox_id` char(36) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_name` (`name`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_email_parent_id` (`parent_id`),
  KEY `idx_email_assigned` (`assigned_user_id`,`type`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails_beans`utf8_general_ci	;
CREATE TABLE `emails_beans` (
  `id` char(36) NOT NULL,
  `email_id` char(36) DEFAULT NULL,
  `bean_id` char(36) DEFAULT NULL,
  `bean_module` varchar(100) DEFAULT NULL,
  `campaign_data` text,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emails_beans_bean_id` (`bean_id`),
  KEY `idx_emails_beans_email_bean` (`email_id`,`bean_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails_email_addr_rel`utf8_general_ci	;
CREATE TABLE `emails_email_addr_rel` (
  `id` char(36) NOT NULL,
  `email_id` char(36) NOT NULL,
  `address_type` varchar(4) DEFAULT NULL,
  `email_address_id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eearl_email_id` (`email_id`,`address_type`),
  KEY `idx_eearl_address_id` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails_text`utf8_general_ci	;
CREATE TABLE `emails_text` (
  `email_id` char(36) NOT NULL,
  `from_addr` varchar(255) DEFAULT NULL,
  `reply_to_addr` varchar(255) DEFAULT NULL,
  `to_addrs` text,
  `cc_addrs` text,
  `bcc_addrs` text,
  `description` longtext,
  `description_html` longtext,
  `raw_source` longtext,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `emails_textfromaddr` (`from_addr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`favorites`utf8_general_ci	;
CREATE TABLE `favorites` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fields_meta_data`utf8_general_ci	;
CREATE TABLE `fields_meta_data` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `vname` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `help` varchar(255) DEFAULT NULL,
  `custom_module` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `len` int(11) DEFAULT NULL,
  `required` tinyint(1) DEFAULT '0',
  `default_value` varchar(255) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `audited` tinyint(1) DEFAULT '0',
  `massupdate` tinyint(1) DEFAULT '0',
  `duplicate_merge` smallint(6) DEFAULT '0',
  `reportable` tinyint(1) DEFAULT '1',
  `importable` varchar(255) DEFAULT NULL,
  `ext1` varchar(255) DEFAULT NULL,
  `ext2` varchar(255) DEFAULT NULL,
  `ext3` varchar(255) DEFAULT NULL,
  `ext4` text,
  PRIMARY KEY (`id`),
  KEY `idx_meta_id_del` (`id`,`deleted`),
  KEY `idx_meta_cm_del` (`custom_module`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`fields_meta_data`utf8_general_ci	;
INSERT INTO `fields_meta_data` VALUES 
('Accountsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Accounts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Accountsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Accounts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Accountsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Accounts','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Accountsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Accounts','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Casesjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Cases','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Casesjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Cases','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Casesjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Cases','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Casesjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Cases','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Contactsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Contacts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Contactsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Contacts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Contactsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Contacts','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Contactsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Contacts','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Contactspatr_c','patr_c','LBL_PATR','','','Contacts','varchar',100,0,'','2017-05-26 08:12:11',0,0,0,0,1,'true','','','',''),
('dp_licenseaccount_id_c','account_id_c','LBL_LICENSE_FOR_ACCOUNT_ID','','','dp_license','id',36,0,\N,'2017-05-26 13:04:34',0,0,0,0,0,'true','','','',''),
('dp_licensebywhom_license_c','bywhom_license_c','LBL_BYWHOM_LICENSE','','','dp_license','varchar',100,0,'','2017-05-26 12:57:25',0,0,0,0,1,'true','','','',''),
('dp_licensedate_license_c','date_license_c','LBL_DATE_LICENSE','','','dp_license','date',\N,0,'','2017-05-26 12:56:49',0,0,0,0,1,'true','','','',''),
('dp_licenselicense_for_c','license_for_c','LBL_LICENSE_FOR','','','dp_license','relate',255,0,\N,'2017-05-26 13:04:34',0,0,0,0,1,'true','','Accounts','account_id_c',''),
('dp_licensenum_license_c','num_license_c','LBL_NUM_LICENSE','','','dp_license','varchar',20,0,'','2017-05-26 12:56:31',0,0,0,0,1,'true','','','',''),
('dp_licensesrok_work_license_c','srok_work_license_c','LBL_SROK_WORK_LICENSE','','','dp_license','date',\N,0,'-1 day','2017-05-28 17:16:26',0,0,0,0,1,'true','','','',''),
('Leadsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Leads','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Leadsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Leads','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Leadsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Leads','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Leadsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Leads','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Meetingsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Meetings','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Meetingsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Meetings','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Meetingsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Meetings','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Meetingsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Meetings','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Opportunitiesjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Opportunities','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Opportunitiesjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Opportunities','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Opportunitiesjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Opportunities','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Opportunitiesjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Opportunities','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Projectjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Project','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Projectjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Project','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Projectjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Project','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Projectjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Project','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Prospectsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Prospects','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Prospectsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Prospects','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Prospectsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Prospects','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Prospectsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Prospects','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('sro_svid_sroaccount_id_c','account_id_c','LBL_SRO_FOR_ACCOUNT_ID','','','sro_svid_sro','id',36,0,\N,'2017-05-28 17:32:42',0,0,0,0,0,'true','','','',''),
('sro_svid_srobywhom_sro_c','bywhom_sro_c','LBL_BYWHOM_SRO','','','sro_svid_sro','varchar',150,0,'','2017-05-28 17:29:17',0,0,0,0,1,'true','','','',''),
('sro_svid_srodate_sro_c','date_sro_c','LBL_DATE_SRO',\N,\N,'sro_svid_sro','date',\N,0,\N,'2017-05-28 17:29:37',0,0,0,0,1,'true',\N,\N,\N,\N),
('sro_svid_sronum_sro_c','num_sro_c','LBL_NUM_SRO','','','sro_svid_sro','varchar',80,0,'','2017-05-28 17:28:09',0,0,0,0,1,'true','','','',''),
('sro_svid_srosrok_work_sro_c','srok_work_sro_c','LBL_SROK_WORK_SRO','','','sro_svid_sro','date',\N,0,'-1 day','2017-05-28 17:30:08',0,0,0,0,1,'true','','','',''),
('sro_svid_srosro_for_c','sro_for_c','LBL_SRO_FOR','','','sro_svid_sro','relate',255,0,\N,'2017-05-28 17:32:42',0,0,0,0,1,'true','','Accounts','account_id_c','')	;
#	TC`folders`utf8_general_ci	;
CREATE TABLE `folders` (
  `id` char(36) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `folder_type` varchar(25) DEFAULT NULL,
  `parent_folder` char(36) DEFAULT NULL,
  `has_child` tinyint(1) DEFAULT '0',
  `is_group` tinyint(1) DEFAULT '0',
  `is_dynamic` tinyint(1) DEFAULT '0',
  `dynamic_query` text,
  `assign_to_id` char(36) DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  `modified_by` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_folder` (`parent_folder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`folders_rel`utf8_general_ci	;
CREATE TABLE `folders_rel` (
  `id` char(36) NOT NULL,
  `folder_id` char(36) NOT NULL,
  `polymorphic_module` varchar(25) DEFAULT NULL,
  `polymorphic_id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_poly_module_poly_id` (`polymorphic_module`,`polymorphic_id`),
  KEY `idx_fr_id_deleted_poly` (`folder_id`,`deleted`,`polymorphic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`folders_subscriptions`utf8_general_ci	;
CREATE TABLE `folders_subscriptions` (
  `id` char(36) NOT NULL,
  `folder_id` char(36) NOT NULL,
  `assigned_user_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder_id_assigned_user_id` (`folder_id`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_event_locations`utf8_general_ci	;
CREATE TABLE `fp_event_locations` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `address_postalcode` varchar(20) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `capacity` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_event_locations_audit`utf8_general_ci	;
CREATE TABLE `fp_event_locations_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_fp_event_locations_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_event_locations_fp_events_1_c`utf8_general_ci	;
CREATE TABLE `fp_event_locations_fp_events_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_event_locations_fp_events_1fp_event_locations_ida` varchar(36) DEFAULT NULL,
  `fp_event_locations_fp_events_1fp_events_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_event_locations_fp_events_1_ida1` (`fp_event_locations_fp_events_1fp_event_locations_ida`),
  KEY `fp_event_locations_fp_events_1_alt` (`fp_event_locations_fp_events_1fp_events_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events`utf8_general_ci	;
CREATE TABLE `fp_events` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `duration_hours` int(3) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `budget` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `invite_templates` varchar(100) DEFAULT NULL,
  `accept_redirect` varchar(255) DEFAULT NULL,
  `decline_redirect` varchar(255) DEFAULT NULL,
  `activity_status_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_audit`utf8_general_ci	;
CREATE TABLE `fp_events_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_fp_events_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_contacts_c`utf8_general_ci	;
CREATE TABLE `fp_events_contacts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_contactsfp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_contactscontacts_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fp_events_contacts_alt` (`fp_events_contactsfp_events_ida`,`fp_events_contactscontacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_fp_event_delegates_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_fp_event_delegates_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_fp_event_delegates_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_fp_event_delegates_1fp_event_delegates_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_events_fp_event_delegates_1_ida1` (`fp_events_fp_event_delegates_1fp_events_ida`),
  KEY `fp_events_fp_event_delegates_1_alt` (`fp_events_fp_event_delegates_1fp_event_delegates_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_fp_event_locations_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_fp_event_locations_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_fp_event_locations_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_fp_event_locations_1fp_event_locations_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_events_fp_event_locations_1_alt` (`fp_events_fp_event_locations_1fp_events_ida`,`fp_events_fp_event_locations_1fp_event_locations_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_leads_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_leads_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_leads_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_leads_1leads_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fp_events_leads_1_alt` (`fp_events_leads_1fp_events_ida`,`fp_events_leads_1leads_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_prospects_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_prospects_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_prospects_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_prospects_1prospects_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fp_events_prospects_1_alt` (`fp_events_prospects_1fp_events_ida`,`fp_events_prospects_1prospects_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`import_maps`utf8_general_ci	;
CREATE TABLE `import_maps` (
  `id` char(36) NOT NULL,
  `name` varchar(254) DEFAULT NULL,
  `source` varchar(36) DEFAULT NULL,
  `enclosure` varchar(1) DEFAULT ' ',
  `delimiter` varchar(1) DEFAULT ',',
  `module` varchar(36) DEFAULT NULL,
  `content` text,
  `default_values` text,
  `has_header` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_published` varchar(3) DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `idx_owner_module_name` (`assigned_user_id`,`module`,`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`inbound_email`utf8_general_ci	;
CREATE TABLE `inbound_email` (
  `id` varchar(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Active',
  `server_url` varchar(100) DEFAULT NULL,
  `email_user` varchar(100) DEFAULT NULL,
  `email_password` varchar(100) DEFAULT NULL,
  `port` int(5) DEFAULT NULL,
  `service` varchar(50) DEFAULT NULL,
  `mailbox` text,
  `delete_seen` tinyint(1) DEFAULT '0',
  `mailbox_type` varchar(10) DEFAULT NULL,
  `template_id` char(36) DEFAULT NULL,
  `stored_options` text,
  `group_id` char(36) DEFAULT NULL,
  `is_personal` tinyint(1) DEFAULT '0',
  `groupfolder_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`inbound_email_autoreply`utf8_general_ci	;
CREATE TABLE `inbound_email_autoreply` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `autoreplied_to` varchar(100) DEFAULT NULL,
  `ie_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ie_autoreplied_to` (`autoreplied_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`inbound_email_cache_ts`utf8_general_ci	;
CREATE TABLE `inbound_email_cache_ts` (
  `id` varchar(255) NOT NULL,
  `ie_timestamp` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_address_cache`utf8_general_ci	;
CREATE TABLE `jjwg_address_cache` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `lat` float(10,8) DEFAULT NULL,
  `lng` float(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_address_cache_audit`utf8_general_ci	;
CREATE TABLE `jjwg_address_cache_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_address_cache_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_areas`utf8_general_ci	;
CREATE TABLE `jjwg_areas` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `coordinates` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_areas_audit`utf8_general_ci	;
CREATE TABLE `jjwg_areas_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_areas_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps`utf8_general_ci	;
CREATE TABLE `jjwg_maps` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `distance` float(9,4) DEFAULT NULL,
  `unit_type` varchar(100) DEFAULT 'mi',
  `module_type` varchar(100) DEFAULT 'Accounts',
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps_audit`utf8_general_ci	;
CREATE TABLE `jjwg_maps_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_maps_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps_jjwg_areas_c`utf8_general_ci	;
CREATE TABLE `jjwg_maps_jjwg_areas_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `jjwg_maps_5304wg_maps_ida` varchar(36) DEFAULT NULL,
  `jjwg_maps_41f2g_areas_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjwg_maps_jjwg_areas_alt` (`jjwg_maps_5304wg_maps_ida`,`jjwg_maps_41f2g_areas_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps_jjwg_markers_c`utf8_general_ci	;
CREATE TABLE `jjwg_maps_jjwg_markers_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `jjwg_maps_b229wg_maps_ida` varchar(36) DEFAULT NULL,
  `jjwg_maps_2e31markers_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjwg_maps_jjwg_markers_alt` (`jjwg_maps_b229wg_maps_ida`,`jjwg_maps_2e31markers_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_markers`utf8_general_ci	;
CREATE TABLE `jjwg_markers` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `jjwg_maps_lat` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_lng` float(11,8) DEFAULT '0.00000000',
  `marker_image` varchar(100) DEFAULT 'company',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_markers_audit`utf8_general_ci	;
CREATE TABLE `jjwg_markers_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_markers_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`job_queue`utf8_general_ci	;
CREATE TABLE `job_queue` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `scheduler_id` char(36) DEFAULT NULL,
  `execute_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `resolution` varchar(20) DEFAULT NULL,
  `message` text,
  `target` varchar(255) DEFAULT NULL,
  `data` text,
  `requeue` tinyint(1) DEFAULT '0',
  `retry_count` tinyint(4) DEFAULT NULL,
  `failure_count` tinyint(4) DEFAULT NULL,
  `job_delay` int(11) DEFAULT NULL,
  `client` varchar(255) DEFAULT NULL,
  `percent_complete` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status_scheduler` (`status`,`scheduler_id`),
  KEY `idx_status_time` (`status`,`execute_time`,`date_entered`),
  KEY `idx_status_entered` (`status`,`date_entered`),
  KEY `idx_status_modified` (`status`,`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`leads`utf8_general_ci	;
CREATE TABLE `leads` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `converted` tinyint(1) DEFAULT '0',
  `refered_by` varchar(100) DEFAULT NULL,
  `lead_source` varchar(100) DEFAULT NULL,
  `lead_source_description` text,
  `status` varchar(100) DEFAULT NULL,
  `status_description` text,
  `reports_to_id` char(36) DEFAULT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `account_description` text,
  `contact_id` char(36) DEFAULT NULL,
  `account_id` char(36) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `opportunity_name` varchar(255) DEFAULT NULL,
  `opportunity_amount` varchar(50) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `portal_name` varchar(255) DEFAULT NULL,
  `portal_app` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lead_acct_name_first` (`account_name`,`deleted`),
  KEY `idx_lead_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_lead_del_stat` (`last_name`,`status`,`deleted`,`first_name`),
  KEY `idx_lead_opp_del` (`opportunity_id`,`deleted`),
  KEY `idx_leads_acct_del` (`account_id`,`deleted`),
  KEY `idx_del_user` (`deleted`,`assigned_user_id`),
  KEY `idx_lead_assigned` (`assigned_user_id`),
  KEY `idx_lead_contact` (`contact_id`),
  KEY `idx_reports_to` (`reports_to_id`),
  KEY `idx_lead_phone_work` (`phone_work`),
  KEY `idx_leads_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`leads_audit`utf8_general_ci	;
CREATE TABLE `leads_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_leads_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`leads_cstm`utf8_general_ci	;
CREATE TABLE `leads_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`linked_documents`utf8_general_ci	;
CREATE TABLE `linked_documents` (
  `id` varchar(36) NOT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `parent_type` varchar(25) DEFAULT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_document` (`parent_type`,`parent_id`,`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings`utf8_general_ci	;
CREATE TABLE `meetings` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `join_url` varchar(200) DEFAULT NULL,
  `host_url` varchar(400) DEFAULT NULL,
  `displayed_url` varchar(400) DEFAULT NULL,
  `creator` varchar(50) DEFAULT NULL,
  `external_id` varchar(50) DEFAULT NULL,
  `duration_hours` int(3) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planned',
  `type` varchar(255) DEFAULT 'Sugar',
  `parent_id` char(36) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT '-1',
  `email_reminder_time` int(11) DEFAULT '-1',
  `email_reminder_sent` tinyint(1) DEFAULT '0',
  `outlook_id` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT '0',
  `repeat_type` varchar(36) DEFAULT NULL,
  `repeat_interval` int(3) DEFAULT '1',
  `repeat_dow` varchar(7) DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_count` int(7) DEFAULT NULL,
  `repeat_parent_id` char(36) DEFAULT NULL,
  `recurring_source` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mtg_name` (`name`),
  KEY `idx_meet_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_meet_stat_del` (`assigned_user_id`,`status`,`deleted`),
  KEY `idx_meet_date_start` (`date_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_contacts`utf8_general_ci	;
CREATE TABLE `meetings_contacts` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_mtg_mtg` (`meeting_id`),
  KEY `idx_con_mtg_con` (`contact_id`),
  KEY `idx_meeting_contact` (`meeting_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_cstm`utf8_general_ci	;
CREATE TABLE `meetings_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_leads`utf8_general_ci	;
CREATE TABLE `meetings_leads` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `lead_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lead_meeting_meeting` (`meeting_id`),
  KEY `idx_lead_meeting_lead` (`lead_id`),
  KEY `idx_meeting_lead` (`meeting_id`,`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_users`utf8_general_ci	;
CREATE TABLE `meetings_users` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usr_mtg_mtg` (`meeting_id`),
  KEY `idx_usr_mtg_usr` (`user_id`),
  KEY `idx_meeting_users` (`meeting_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`notes`utf8_general_ci	;
CREATE TABLE `notes` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `portal_flag` tinyint(1) DEFAULT NULL,
  `embed_flag` tinyint(1) DEFAULT '0',
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_note_name` (`name`),
  KEY `idx_notes_parent` (`parent_id`,`parent_type`),
  KEY `idx_note_contact` (`contact_id`),
  KEY `idx_notes_assigned_del` (`deleted`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`oauth_consumer`utf8_general_ci	;
CREATE TABLE `oauth_consumer` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `c_key` varchar(255) DEFAULT NULL,
  `c_secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ckey` (`c_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`oauth_nonce`utf8_general_ci	;
CREATE TABLE `oauth_nonce` (
  `conskey` varchar(32) NOT NULL,
  `nonce` varchar(32) NOT NULL,
  `nonce_ts` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`conskey`,`nonce`),
  KEY `oauth_nonce_keyts` (`conskey`,`nonce_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`oauth_tokens`utf8_general_ci	;
CREATE TABLE `oauth_tokens` (
  `id` char(36) NOT NULL,
  `secret` varchar(32) DEFAULT NULL,
  `tstate` varchar(1) DEFAULT NULL,
  `consumer` char(36) NOT NULL,
  `token_ts` bigint(20) DEFAULT NULL,
  `verify` varchar(32) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `callback_url` varchar(255) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`,`deleted`),
  KEY `oauth_state_ts` (`tstate`,`token_ts`),
  KEY `constoken_key` (`consumer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities`utf8_general_ci	;
CREATE TABLE `opportunities` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `opportunity_type` varchar(255) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `lead_source` varchar(50) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `amount_usdollar` double DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `date_closed` date DEFAULT NULL,
  `next_step` varchar(100) DEFAULT NULL,
  `sales_stage` varchar(255) DEFAULT NULL,
  `probability` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_opp_name` (`name`),
  KEY `idx_opp_assigned` (`assigned_user_id`),
  KEY `idx_opp_id_deleted` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities_audit`utf8_general_ci	;
CREATE TABLE `opportunities_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_opportunities_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities_contacts`utf8_general_ci	;
CREATE TABLE `opportunities_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_opp_con` (`contact_id`),
  KEY `idx_con_opp_opp` (`opportunity_id`),
  KEY `idx_opportunities_contacts` (`opportunity_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities_cstm`utf8_general_ci	;
CREATE TABLE `opportunities_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`outbound_email`utf8_general_ci	;
CREATE TABLE `outbound_email` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(15) DEFAULT 'user',
  `user_id` char(36) NOT NULL,
  `mail_sendtype` varchar(8) DEFAULT 'smtp',
  `mail_smtptype` varchar(20) DEFAULT 'other',
  `mail_smtpserver` varchar(100) DEFAULT NULL,
  `mail_smtpport` int(5) DEFAULT '0',
  `mail_smtpuser` varchar(100) DEFAULT NULL,
  `mail_smtppass` varchar(100) DEFAULT NULL,
  `mail_smtpauth_req` tinyint(1) DEFAULT '0',
  `mail_smtpssl` varchar(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`outbound_email`utf8_general_ci	;
INSERT INTO `outbound_email` VALUES 
('3f24d894-100d-909a-9e1d-592564482917','system','system','1','SMTP','other','smtp.yandex.ru',465,'web@finexpert.pro','1xeVJp9NemB1pAqKjO/pSg==',1,'1',\N,\N,\N,\N,0,\N)	;
#	TC`outbound_email_audit`utf8_general_ci	;
CREATE TABLE `outbound_email_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_outbound_email_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project`utf8_general_ci	;
CREATE TABLE `project` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `estimated_start_date` date DEFAULT NULL,
  `estimated_end_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `override_business_hours` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_contacts_1_c`utf8_general_ci	;
CREATE TABLE `project_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `project_contacts_1project_ida` varchar(36) DEFAULT NULL,
  `project_contacts_1contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_contacts_1_alt` (`project_contacts_1project_ida`,`project_contacts_1contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_cstm`utf8_general_ci	;
CREATE TABLE `project_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_task`utf8_general_ci	;
CREATE TABLE `project_task` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `project_id` char(36) NOT NULL,
  `project_task_id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `relationship_type` varchar(255) DEFAULT NULL,
  `description` text,
  `predecessors` text,
  `date_start` date DEFAULT NULL,
  `time_start` int(11) DEFAULT NULL,
  `time_finish` int(11) DEFAULT NULL,
  `date_finish` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_unit` text,
  `actual_duration` int(11) DEFAULT NULL,
  `percent_complete` int(11) DEFAULT NULL,
  `date_due` date DEFAULT NULL,
  `time_due` time DEFAULT NULL,
  `parent_task_id` int(11) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `milestone_flag` tinyint(1) DEFAULT NULL,
  `order_number` int(11) DEFAULT '1',
  `task_number` int(11) DEFAULT NULL,
  `estimated_effort` int(11) DEFAULT NULL,
  `actual_effort` int(11) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `utilization` int(11) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_task_audit`utf8_general_ci	;
CREATE TABLE `project_task_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_project_task_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_users_1_c`utf8_general_ci	;
CREATE TABLE `project_users_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `project_users_1project_ida` varchar(36) DEFAULT NULL,
  `project_users_1users_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_users_1_alt` (`project_users_1project_ida`,`project_users_1users_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_accounts`utf8_general_ci	;
CREATE TABLE `projects_accounts` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_acct_proj` (`project_id`),
  KEY `idx_proj_acct_acct` (`account_id`),
  KEY `projects_accounts_alt` (`project_id`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_bugs`utf8_general_ci	;
CREATE TABLE `projects_bugs` (
  `id` varchar(36) NOT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_bug_proj` (`project_id`),
  KEY `idx_proj_bug_bug` (`bug_id`),
  KEY `projects_bugs_alt` (`project_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_cases`utf8_general_ci	;
CREATE TABLE `projects_cases` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_case_proj` (`project_id`),
  KEY `idx_proj_case_case` (`case_id`),
  KEY `projects_cases_alt` (`project_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_contacts`utf8_general_ci	;
CREATE TABLE `projects_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_con_proj` (`project_id`),
  KEY `idx_proj_con_con` (`contact_id`),
  KEY `projects_contacts_alt` (`project_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_opportunities`utf8_general_ci	;
CREATE TABLE `projects_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_opp_proj` (`project_id`),
  KEY `idx_proj_opp_opp` (`opportunity_id`),
  KEY `projects_opportunities_alt` (`project_id`,`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_products`utf8_general_ci	;
CREATE TABLE `projects_products` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_prod_project` (`project_id`),
  KEY `idx_proj_prod_product` (`product_id`),
  KEY `projects_products_alt` (`project_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospect_list_campaigns`utf8_general_ci	;
CREATE TABLE `prospect_list_campaigns` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `campaign_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pro_id` (`prospect_list_id`),
  KEY `idx_cam_id` (`campaign_id`),
  KEY `idx_prospect_list_campaigns` (`prospect_list_id`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospect_lists`utf8_general_ci	;
CREATE TABLE `prospect_lists` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `list_type` varchar(100) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `description` text,
  `domain_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prospect_list_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospect_lists_prospects`utf8_general_ci	;
CREATE TABLE `prospect_lists_prospects` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `related_id` varchar(36) DEFAULT NULL,
  `related_type` varchar(25) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_plp_pro_id` (`prospect_list_id`),
  KEY `idx_plp_rel_id` (`related_id`,`related_type`,`prospect_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospects`utf8_general_ci	;
CREATE TABLE `prospects` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `birthdate` date DEFAULT NULL,
  `lead_id` char(36) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prospect_auto_tracker_key` (`tracker_key`),
  KEY `idx_prospects_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_prospecs_del_last` (`last_name`,`deleted`),
  KEY `idx_prospects_id_del` (`id`,`deleted`),
  KEY `idx_prospects_assigned` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospects_cstm`utf8_general_ci	;
CREATE TABLE `prospects_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`relationships`utf8_general_ci	;
CREATE TABLE `relationships` (
  `id` char(36) NOT NULL,
  `relationship_name` varchar(150) DEFAULT NULL,
  `lhs_module` varchar(100) DEFAULT NULL,
  `lhs_table` varchar(64) DEFAULT NULL,
  `lhs_key` varchar(64) DEFAULT NULL,
  `rhs_module` varchar(100) DEFAULT NULL,
  `rhs_table` varchar(64) DEFAULT NULL,
  `rhs_key` varchar(64) DEFAULT NULL,
  `join_table` varchar(64) DEFAULT NULL,
  `join_key_lhs` varchar(64) DEFAULT NULL,
  `join_key_rhs` varchar(64) DEFAULT NULL,
  `relationship_type` varchar(64) DEFAULT NULL,
  `relationship_role_column` varchar(64) DEFAULT NULL,
  `relationship_role_column_value` varchar(50) DEFAULT NULL,
  `reverse` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rel_name` (`relationship_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`relationships`utf8_general_ci	;
INSERT INTO `relationships` VALUES 
('1092d309-cd24-8d86-e2b1-592b098fd76b','emails_prospects_rel','Emails','emails','id','Prospects','prospects','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Prospects',0,0),
('11706506-db1d-8727-e638-592b0989d558','meetings_contacts','Meetings','meetings','id','Contacts','contacts','id','meetings_contacts','meeting_id','contact_id','many-to-many',\N,\N,0,0),
('12822ef3-8c17-fa92-f8f6-592b09d399eb','meetings_users','Meetings','meetings','id','Users','users','id','meetings_users','meeting_id','user_id','many-to-many',\N,\N,0,0),
('12db0173-e87c-a2eb-8ee7-592b09799ca5','securitygroups_emails','SecurityGroups','securitygroups','id','Emails','emails','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Emails',0,0),
('132bf7f8-8bde-37aa-dcc6-592b096a63ca','meetings_leads','Meetings','meetings','id','Leads','leads','id','meetings_leads','meeting_id','lead_id','many-to-many',\N,\N,0,0),
('13ce209f-b03b-5e5e-6500-592b0966a856','opportunities_contacts','Opportunities','opportunities','id','Contacts','contacts','id','opportunities_contacts','opportunity_id','contact_id','many-to-many',\N,\N,0,0),
('1413937b-0deb-d488-4677-592b096b83d4','emails_assigned_user','Users','users','id','Emails','emails','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('146f637f-a228-81bb-ae22-592b091656ad','prospect_list_campaigns','ProspectLists','prospect_lists','id','Campaigns','campaigns','id','prospect_list_campaigns','prospect_list_id','campaign_id','many-to-many',\N,\N,0,0),
('14d080e1-4598-39c2-70a6-592b0911b349','emails_modified_user','Users','users','id','Emails','emails','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1528be2c-03c7-5d2c-49f9-592b09a6b178','prospect_list_contacts','ProspectLists','prospect_lists','id','Contacts','contacts','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Contacts',0,0),
('157079be-5fc0-8580-0be9-592b097c37a4','emails_created_by','Users','users','id','Emails','emails','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('15db3d82-406c-97d9-b48e-592b09360d82','prospect_list_prospects','ProspectLists','prospect_lists','id','Prospects','prospects','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Prospects',0,0),
('16184be3-f8e5-4316-476c-592b09bd3afe','emails_notes_rel','Emails','emails','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('168d559b-3b75-916a-07ec-592b09ec7407','prospect_list_leads','ProspectLists','prospect_lists','id','Leads','leads','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Leads',0,0),
('16dbbaa9-4ad1-a06f-fb01-592b090279da','emails_contacts_rel','Emails','emails','id','Contacts','contacts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Contacts',0,0),
('17412ecd-fb8b-8f69-06eb-592b09f0cbd2','prospect_list_users','ProspectLists','prospect_lists','id','Users','users','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Users',0,0),
('17868607-4d7d-e32b-924a-592b094992dc','emails_accounts_rel','Emails','emails','id','Accounts','accounts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Accounts',0,0),
('17fcd89b-dd0b-4827-3385-592b0918bea2','prospect_list_accounts','ProspectLists','prospect_lists','id','Accounts','accounts','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Accounts',0,0),
('183c1c67-4f4c-1840-334b-592b09eba413','emails_leads_rel','Emails','emails','id','Leads','leads','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Leads',0,0),
('18c05b1d-8a55-f05e-000b-592b09584176','roles_users','Roles','roles','id','Users','users','id','roles_users','role_id','user_id','many-to-many',\N,\N,0,0),
('18e18cd8-3761-e178-fcad-592b095a7bfd','emails_aos_contracts_rel','Emails','emails','id','AOS_Contracts','aos_contracts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','AOS_Contracts',0,0),
('1953063b-f691-a551-7f06-592b09699a44','opportunity_currencies','Opportunities','opportunities','currency_id','Currencies','currencies','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('19673c60-cfee-05e8-e974-592b0985fe07','projects_bugs','Project','project','id','Bugs','bugs','id','projects_bugs','project_id','bug_id','many-to-many',\N,\N,0,0),
('19808211-4dd0-5a35-e63c-592b09589a70','emails_meetings_rel','Emails','emails','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1a0044a8-8569-7e7a-c90a-592b095e82e3','projects_cases','Project','project','id','Cases','cases','id','projects_cases','project_id','case_id','many-to-many',\N,\N,0,0),
('1a990559-0857-3373-cbfc-592b09bb04af','projects_accounts','Project','project','id','Accounts','accounts','id','projects_accounts','project_id','account_id','many-to-many',\N,\N,0,0),
('1b2af9e5-6846-4a29-b062-592b0927b7d8','projects_contacts','Project','project','id','Contacts','contacts','id','projects_contacts','project_id','contact_id','many-to-many',\N,\N,0,0),
('1ba6ce16-f4b9-752e-642b-592b0978523e','meetings_modified_user','Users','users','id','Meetings','meetings','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1bbc7b38-e06c-8efb-3443-592b0985745c','projects_opportunities','Project','project','id','Opportunities','opportunities','id','projects_opportunities','project_id','opportunity_id','many-to-many',\N,\N,0,0),
('1c56c47b-451d-1cbe-66dd-592b0902b831','acl_roles_actions','ACLRoles','acl_roles','id','ACLActions','acl_actions','id','acl_roles_actions','role_id','action_id','many-to-many',\N,\N,0,0),
('1c7fe364-f728-b4e7-325e-592b09d5279b','meetings_created_by','Users','users','id','Meetings','meetings','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1cec078c-fccf-2a41-cd2b-592b09a5dfb0','acl_roles_users','ACLRoles','acl_roles','id','Users','users','id','acl_roles_users','role_id','user_id','many-to-many',\N,\N,0,0),
('1d3dfdc3-aeb3-79a6-1818-592b097b05ca','meetings_assigned_user','Users','users','id','Meetings','meetings','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1d79d0b7-21bb-a5eb-97ca-592b09ecf4b5','email_marketing_prospect_lists','EmailMarketing','email_marketing','id','ProspectLists','prospect_lists','id','email_marketing_prospect_lists','email_marketing_id','prospect_list_id','many-to-many',\N,\N,0,0),
('1dec997d-6bc7-ea04-b058-592b09d01072','securitygroups_meetings','SecurityGroups','securitygroups','id','Meetings','meetings','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Meetings',0,0),
('1e095025-d64c-35a6-6537-592b09e7ca34','leads_documents','Leads','leads','id','Documents','documents','id','linked_documents','parent_id','document_id','many-to-many','parent_type','Leads',0,0),
('1e8d1aa1-cde1-93d9-a2ce-592b09a57131','meetings_notes','Meetings','meetings','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Meetings',0,0),
('1f520903-f2a2-420c-cd96-592b0937c847','documents_accounts','Documents','documents','id','Accounts','accounts','id','documents_accounts','document_id','account_id','many-to-many',\N,\N,0,0),
('202e60c0-2862-ccb0-4e82-592b09dc8e05','tasks_modified_user','Users','users','id','Tasks','tasks','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('20778245-f9ff-2722-65e0-592b09dea3ca','documents_contacts','Documents','documents','id','Contacts','contacts','id','documents_contacts','document_id','contact_id','many-to-many',\N,\N,0,0),
('20f3a365-99f4-e8ec-a246-592b09248f0d','tasks_created_by','Users','users','id','Tasks','tasks','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2148f95d-70a6-b413-971e-592b096b0eda','documents_opportunities','Documents','documents','id','Opportunities','opportunities','id','documents_opportunities','document_id','opportunity_id','many-to-many',\N,\N,0,0),
('21a95ae4-350b-84e3-5582-592b0991363e','tasks_assigned_user','Users','users','id','Tasks','tasks','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('21e9ed65-a4a5-77a2-6f1e-592b094f4fe4','documents_cases','Documents','documents','id','Cases','cases','id','documents_cases','document_id','case_id','many-to-many',\N,\N,0,0),
('223bb004-ac6f-78f1-512b-592b09024941','securitygroups_tasks','SecurityGroups','securitygroups','id','Tasks','tasks','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Tasks',0,0),
('227c8bbd-a44f-6f02-d497-592b09f3b71d','documents_bugs','Documents','documents','id','Bugs','bugs','id','documents_bugs','document_id','bug_id','many-to-many',\N,\N,0,0),
('228d0a45-54c8-3074-ab2f-592b0947a20a','opportunities_campaign','Campaigns','campaigns','id','Opportunities','opportunities','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('22c83b91-3d56-1ed7-792b-592b09d6cdec','tasks_notes','Tasks','tasks','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2316bc04-8d25-55af-1261-592b09548de4','aok_knowledgebase_categories','AOK_KnowledgeBase','aok_knowledgebase','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','id','aok_knowledgebase_categories','aok_knowledgebase_id','aok_knowledge_base_categories_id','many-to-many',\N,\N,0,0),
('2430993a-d1a4-5d00-53cb-592b0908e882','am_projecttemplates_project_1','AM_ProjectTemplates','am_projecttemplates','id','Project','project','id','am_projecttemplates_project_1_c','am_projecttemplates_project_1am_projecttemplates_ida','am_projecttemplates_project_1project_idb','many-to-many',\N,\N,0,0),
('24c88e39-e5bc-f60b-1509-592b09f76b98','am_projecttemplates_contacts_1','AM_ProjectTemplates','am_projecttemplates','id','Contacts','contacts','id','am_projecttemplates_contacts_1_c','am_projecttemplates_ida','contacts_idb','many-to-many',\N,\N,0,0),
('257d67ec-4625-9be0-dc04-592b0932a3e0','am_projecttemplates_users_1','AM_ProjectTemplates','am_projecttemplates','id','Users','users','id','am_projecttemplates_users_1_c','am_projecttemplates_ida','users_idb','many-to-many',\N,\N,0,0),
('261bb55f-40ec-f38d-c737-592b096b7b7c','am_tasktemplates_am_projecttemplates','AM_ProjectTemplates','am_projecttemplates','id','AM_TaskTemplates','am_tasktemplates','id','am_tasktemplates_am_projecttemplates_c','am_tasktemplates_am_projecttemplatesam_projecttemplates_ida','am_tasktemplates_am_projecttemplatesam_tasktemplates_idb','many-to-many',\N,\N,0,0),
('26d19726-b3ed-c4f4-3f93-592b09c2d301','alerts_modified_user','Users','users','id','Alerts','alerts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('26dc7e78-7ff5-a665-4482-592b094cb0dc','aos_contracts_documents','AOS_Contracts','aos_contracts','id','Documents','documents','id','aos_contracts_documents','aos_contracts_id','documents_id','many-to-many',\N,\N,0,0),
('2777c7ba-5ddf-0b19-85ad-592b091a23b8','aos_quotes_aos_contracts','AOS_Quotes','aos_quotes','id','AOS_Contracts','aos_contracts','id','aos_quotes_os_contracts_c','aos_quotese81e_quotes_ida','aos_quotes4dc0ntracts_idb','many-to-many',\N,\N,0,0),
('27e81a0c-b236-7772-6cc5-592b09b193fe','alerts_created_by','Users','users','id','Alerts','alerts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('28146ba0-3fe0-6383-92a3-592b09ea6938','aos_quotes_aos_invoices','AOS_Quotes','aos_quotes','id','AOS_Invoices','aos_invoices','id','aos_quotes_aos_invoices_c','aos_quotes77d9_quotes_ida','aos_quotes6b83nvoices_idb','many-to-many',\N,\N,0,0),
('289fb8dc-ae18-b7ff-6325-592b09fcf06f','aos_quotes_project','AOS_Quotes','aos_quotes','id','Project','project','id','aos_quotes_project_c','aos_quotes1112_quotes_ida','aos_quotes7207project_idb','many-to-many',\N,\N,0,0),
('28b3474d-d709-b1d3-66c9-592b09e53b0c','alerts_assigned_user','Users','users','id','Alerts','alerts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('293135f0-ce86-4ebf-957e-592b0946eb84','aow_processed_aow_actions','AOW_Processed','aow_processed','id','AOW_Actions','aow_actions','id','aow_processed_aow_actions','aow_processed_id','aow_action_id','many-to-many',\N,\N,0,0),
('29c9124b-42fb-fdea-5ba0-592b09a8776f','fp_event_locations_fp_events_1','FP_Event_Locations','fp_event_locations','id','FP_events','fp_events','id','fp_event_locations_fp_events_1_c','fp_event_locations_fp_events_1fp_event_locations_ida','fp_event_locations_fp_events_1fp_events_idb','many-to-many',\N,\N,0,0),
('2a63c5c5-b307-efc8-dd44-592b09386880','fp_events_contacts','FP_events','fp_events','id','Contacts','contacts','id','fp_events_contacts_c','fp_events_contactsfp_events_ida','fp_events_contactscontacts_idb','many-to-many',\N,\N,0,0),
('2af934a9-ac95-d4db-1da0-592b09ce1a5f','fp_events_fp_event_locations_1','FP_events','fp_events','id','FP_Event_Locations','fp_event_locations','id','fp_events_fp_event_locations_1_c','fp_events_fp_event_locations_1fp_events_ida','fp_events_fp_event_locations_1fp_event_locations_idb','many-to-many',\N,\N,0,0),
('2b154c0d-2725-4c9a-7c8c-592b09494ee2','documents_modified_user','Users','users','id','Documents','documents','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2b8e0ffd-6e1a-df87-a048-592b0985d548','opportunity_aos_quotes','Opportunities','opportunities','id','AOS_Quotes','aos_quotes','opportunity_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2b911108-74fa-cbe3-2f3a-592b092cf642','fp_events_leads_1','FP_events','fp_events','id','Leads','leads','id','fp_events_leads_1_c','fp_events_leads_1fp_events_ida','fp_events_leads_1leads_idb','many-to-many',\N,\N,0,0),
('2bee8cc5-be22-66e1-24a3-592b09e509e5','documents_created_by','Users','users','id','Documents','documents','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2c302cd6-d52d-40e0-22ee-592b099c3869','fp_events_prospects_1','FP_events','fp_events','id','Prospects','prospects','id','fp_events_prospects_1_c','fp_events_prospects_1fp_events_ida','fp_events_prospects_1prospects_idb','many-to-many',\N,\N,0,0),
('2c88f254-c9bc-9252-0a8f-592b09953a57','documents_assigned_user','Users','users','id','Documents','documents','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2ccba4fc-0812-c587-73df-592b09a96872','jjwg_maps_jjwg_areas','jjwg_Maps','jjwg_maps','id','jjwg_Areas','jjwg_areas','id','jjwg_maps_jjwg_areas_c','jjwg_maps_5304wg_maps_ida','jjwg_maps_41f2g_areas_idb','many-to-many',\N,\N,0,0),
('2d1b18e2-0d7e-d482-45b1-592b09bb68f5','securitygroups_documents','SecurityGroups','securitygroups','id','Documents','documents','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Documents',0,0),
('2d6fe7cb-24bd-081d-67f4-592b0944b581','jjwg_maps_jjwg_markers','jjwg_Maps','jjwg_maps','id','jjwg_Markers','jjwg_markers','id','jjwg_maps_jjwg_markers_c','jjwg_maps_b229wg_maps_ida','jjwg_maps_2e31markers_idb','many-to-many',\N,\N,0,0),
('2db33a22-9bd1-97cc-b325-592b091e24d4','document_revisions','Documents','documents','id','DocumentRevisions','document_revisions','document_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2e1434d4-5bbe-c234-4f92-592b0901be5c','project_contacts_1','Project','project','id','Contacts','contacts','id','project_contacts_1_c','project_contacts_1project_ida','project_contacts_1contacts_idb','many-to-many',\N,\N,0,0),
('2f273f5f-4931-bbdc-e2a8-592b095842c1','revisions_created_by','Users','users','id','DocumentRevisions','document_revisions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2f591337-37d5-fe3e-0191-592b091e08f1','project_users_1','Project','project','id','Users','users','id','project_users_1_c','project_users_1project_ida','project_users_1users_idb','many-to-many',\N,\N,0,0),
('30044058-3dd8-3ece-a939-592b0978f539','securitygroups_acl_roles','SecurityGroups','securitygroups','id','ACLRoles','acl_roles','id','securitygroups_acl_roles','securitygroup_id','role_id','many-to-many',\N,\N,0,0),
('312be9ad-808f-b9d1-0d54-592b09cec2d2','securitygroups_project_task','SecurityGroups','securitygroups','id','ProjectTask','project_task','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProjectTask',0,0),
('31ca8961-02e5-ca30-08c3-592b093a19e4','securitygroups_prospect_lists','SecurityGroups','securitygroups','id','ProspectLists','prospect_lists','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProspectLists',0,0),
('32806ecf-bc94-b5b3-bd41-592b09b780f7','securitygroups_users','SecurityGroups','securitygroups','id','Users','users','id','securitygroups_users','securitygroup_id','user_id','many-to-many',\N,\N,0,0),
('33238cef-04eb-1ad4-7dea-592b099609c9','dp_realty_accounts','Accounts','accounts','id','dp_realty','dp_realty','id','dp_realty_accounts_c','dp_realty_accountsaccounts_ida','dp_realty_accountsdp_realty_idb','many-to-many',\N,\N,0,0),
('33a6ee27-9a5f-b21d-301b-592b09426a33','inbound_email_created_by','Users','users','id','InboundEmail','inbound_email','created_by',\N,\N,\N,'one-to-one',\N,\N,0,0),
('33b9d395-ebf1-7f04-253d-592b094b2dc3','dp_bkrv_accounts','Accounts','accounts','id','dp_bkrv','dp_bkrv','id','dp_bkrv_accounts_c','dp_bkrv_accountsaccounts_ida','dp_bkrv_accountsdp_bkrv_idb','many-to-many',\N,\N,0,0),
('3490a433-5d2d-9d32-6482-592b0995b84f','inbound_email_modified_user_id','Users','users','id','InboundEmail','inbound_email','modified_user_id',\N,\N,\N,'one-to-one',\N,\N,0,0),
('34a10406-8089-911a-bb12-592b09c697ef','opportunity_aos_contracts','Opportunities','opportunities','id','AOS_Contracts','aos_contracts','opportunity_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('36073468-70c3-ba53-7bb9-592b09dbed69','saved_search_assigned_user','Users','users','id','SavedSearch','saved_search','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('38c19aa2-394a-6384-bba3-592b0941a77c','spots_modified_user','Users','users','id','Spots','spots','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('39aed231-73ba-4b46-22b0-592b09f4c262','spots_created_by','Users','users','id','Spots','spots','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3a52acc6-8583-8803-6602-592b09aa441a','spots_assigned_user','Users','users','id','Spots','spots','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3b307a18-94cd-5fc9-4b91-592b094abc5c','securitygroups_spots','SecurityGroups','securitygroups','id','Spots','spots','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Spots',0,0),
('3c7fdf27-e10b-bd3f-c59b-592b09f832b5','aobh_businesshours_modified_user','Users','users','id','AOBH_BusinessHours','aobh_businesshours','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3e7e136d-fd0b-a6f8-6f6e-592b091fc75c','aobh_businesshours_created_by','Users','users','id','AOBH_BusinessHours','aobh_businesshours','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4055c341-08dd-1256-27e8-592b0944be2e','sugarfeed_modified_user','Users','users','id','SugarFeed','sugarfeed','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('413f8886-30e0-b305-c5c4-592b09bbf553','sugarfeed_created_by','Users','users','id','SugarFeed','sugarfeed','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('41f42d7c-d94a-cc7c-bfdb-592b0923a925','sugarfeed_assigned_user','Users','users','id','SugarFeed','sugarfeed','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4524275a-0394-d500-afcd-592b09ce6157','eapm_modified_user','Users','users','id','EAPM','eapm','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('45fa0f9d-ba10-6f10-ed0b-592b091e3e53','eapm_created_by','Users','users','id','EAPM','eapm','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('46acd20f-8e98-bd4e-5824-592b096a3d29','eapm_assigned_user','Users','users','id','EAPM','eapm','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('481ef69b-ca5f-54d1-6aff-592b097b30c4','oauthkeys_modified_user','Users','users','id','OAuthKeys','oauth_consumer','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('491dc60d-8473-7244-a3d3-592b099e44b3','oauthkeys_created_by','Users','users','id','OAuthKeys','oauth_consumer','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('49d368a0-65c7-30ff-7969-592b09fa1678','oauthkeys_assigned_user','Users','users','id','OAuthKeys','oauth_consumer','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4afb3be8-f7ed-b79e-f458-592b0948fa40','consumer_tokens','OAuthKeys','oauth_consumer','id','OAuthTokens','oauth_tokens','consumer',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4bb67513-3e69-e154-9ae8-592b09a773b7','oauthtokens_assigned_user','Users','users','id','OAuthTokens','oauth_tokens','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4d06d25e-6f6a-3b93-9dd9-592b09f06421','am_projecttemplates_modified_user','Users','users','id','AM_ProjectTemplates','am_projecttemplates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4df843df-5f2b-f905-3bff-592b095167de','am_projecttemplates_created_by','Users','users','id','AM_ProjectTemplates','am_projecttemplates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4edc8a19-67a9-bdb4-3086-592b093c0b5b','am_projecttemplates_assigned_user','Users','users','id','AM_ProjectTemplates','am_projecttemplates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4fa7061b-b61b-9344-9a15-592b0902a47e','securitygroups_emailtemplates','SecurityGroups','securitygroups','id','EmailTemplates','email_templates','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','EmailTemplates',0,0),
('50b3b7f4-efea-02b9-1b47-592b0916097f','am_tasktemplates_modified_user','Users','users','id','AM_TaskTemplates','am_tasktemplates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('51200c94-5078-53b7-4b64-592b0926f489','opportunity_emails','Opportunities','opportunities','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('517f0edf-80c6-52af-c110-592b09f338bf','am_tasktemplates_created_by','Users','users','id','AM_TaskTemplates','am_tasktemplates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('521f51ba-e690-4193-512a-592b09d3b202','am_tasktemplates_assigned_user','Users','users','id','AM_TaskTemplates','am_tasktemplates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('52b308b4-87d6-58ad-c3b8-592b09e19358','accounts_bugs','Accounts','accounts','id','Bugs','bugs','id','accounts_bugs','account_id','bug_id','many-to-many',\N,\N,0,0),
('535b46b8-e5e3-a107-9e45-592b09ff5206','favorites_modified_user','Users','users','id','Favorites','favorites','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5421eaff-b20f-6af0-2ba5-592b095c3c3f','favorites_created_by','Users','users','id','Favorites','favorites','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('54c0f4ab-28da-9deb-19bf-592b09843a45','favorites_assigned_user','Users','users','id','Favorites','favorites','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('56190931-65ca-afea-2135-592b09402648','aok_knowledge_base_categories_modified_user','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('56d7b6ef-fb48-51bc-107d-592b093fcbbd','aok_knowledge_base_categories_created_by','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('57773ac8-c441-d235-fecf-592b0900405e','aok_knowledge_base_categories_assigned_user','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('58cce9a5-0aa0-8e66-8e91-592b09f25bbd','aok_knowledgebase_modified_user','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('59b2808e-3011-3962-5296-592b093356d1','aok_knowledgebase_created_by','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5a443781-d6b1-e4b2-8fe7-592b09a68490','aok_knowledgebase_assigned_user','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5ad3ece5-389d-382f-a1ca-592b096dd36c','securitygroups_aok_knowledgebase','SecurityGroups','securitygroups','id','AOK_KnowledgeBase','aok_knowledgebase','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOK_KnowledgeBase',0,0),
('5c4becaa-9b6d-6bb5-2ae7-592b0978c794','reminders_modified_user','Users','users','id','Reminders','reminders','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5c9e01a6-80b7-4687-4a88-592b0944b5cc','emailtemplates_assigned_user','Users','users','id','EmailTemplates','email_templates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5d1fe870-853d-2657-a1cb-592b0999906a','reminders_created_by','Users','users','id','Reminders','reminders','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5dcb0748-adbd-f45b-0723-592b095b1d81','reminders_assigned_user','Users','users','id','Reminders','reminders','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5f14c21d-b9f5-36d7-3938-592b097f9610','reminders_invitees_modified_user','Users','users','id','Reminders_Invitees','reminders_invitees','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5ff7a90d-da4f-0629-d93d-592b09fc78a3','reminders_invitees_created_by','Users','users','id','Reminders_Invitees','reminders_invitees','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('608507a2-89a0-59fb-eaf9-592b0921b4f2','accounts_contacts','Accounts','accounts','id','Contacts','contacts','id','accounts_contacts','account_id','contact_id','many-to-many',\N,\N,0,0),
('60a17047-fa9c-1b34-1908-592b0975abcd','reminders_invitees_assigned_user','Users','users','id','Reminders_Invitees','reminders_invitees','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('622bd8df-127e-b3d7-10f2-592b09d060b2','fp_events_modified_user','Users','users','id','FP_events','fp_events','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6369ee64-2394-f312-bb44-592b0989c45c','fp_events_created_by','Users','users','id','FP_events','fp_events','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6415269a-6f23-986a-1bba-592b09146003','fp_events_assigned_user','Users','users','id','FP_events','fp_events','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('64b1045c-2375-d50f-f14a-592b09a27888','securitygroups_fp_events','SecurityGroups','securitygroups','id','FP_events','fp_events','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','FP_events',0,0),
('662532cd-b0c2-8d05-52c1-592b09c20bef','fp_event_locations_modified_user','Users','users','id','FP_Event_Locations','fp_event_locations','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('66f6dde9-d7db-d08a-dd84-592b094f53f7','fp_event_locations_created_by','Users','users','id','FP_Event_Locations','fp_event_locations','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6796c97c-ffee-e728-a5e0-592b09c63fb6','fp_event_locations_assigned_user','Users','users','id','FP_Event_Locations','fp_event_locations','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6839b538-7a17-c09d-c3b1-592b0943cb78','securitygroups_fp_event_locations','SecurityGroups','securitygroups','id','FP_Event_Locations','fp_event_locations','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','FP_Event_Locations',0,0),
('68dcaa9a-aa6b-d307-3ba5-592b0906c5a7','optimistic_locking',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,0,0),
('6a469c7d-c920-b36a-1cb0-592b095dcc88','unified_search',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,0,0),
('6a7b07b1-637b-d258-7aef-592b0914c1eb','accounts_opportunities','Accounts','accounts','id','Opportunities','opportunities','id','accounts_opportunities','account_id','opportunity_id','many-to-many',\N,\N,0,0),
('6b938a91-1b8b-758f-8603-592b0956ee54','aod_indexevent_modified_user','Users','users','id','AOD_IndexEvent','aod_indexevent','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6c6f7d63-f73e-2b9c-f4af-592b092d4ee8','aod_indexevent_created_by','Users','users','id','AOD_IndexEvent','aod_indexevent','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6d2c871e-794f-5323-78cf-592b09e48365','aod_indexevent_assigned_user','Users','users','id','AOD_IndexEvent','aod_indexevent','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6e3eb59f-8baa-968a-d648-592b09297687','aod_index_modified_user','Users','users','id','AOD_Index','aod_index','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6f09945f-200a-ba5a-b4f5-592b09dda119','aod_index_created_by','Users','users','id','AOD_Index','aod_index','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6fed4329-e57a-ce6f-d0e5-592b09aaeec5','aod_index_assigned_user','Users','users','id','AOD_Index','aod_index','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('712f3a4a-ef2b-e56a-b3f5-592b09973c6c','aop_case_events_modified_user','Users','users','id','AOP_Case_Events','aop_case_events','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('721871ce-0358-207c-1110-592b093c1d8e','aop_case_events_created_by','Users','users','id','AOP_Case_Events','aop_case_events','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7351843e-afc2-5288-7fcf-592b091c24d7','aop_case_events_assigned_user','Users','users','id','AOP_Case_Events','aop_case_events','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('742d0521-bfbc-b32f-bfa7-592b09c0338e','notes_assigned_user','Users','users','id','Notes','notes','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('746c8d52-7404-9f29-2992-592b091eaf74','cases_aop_case_events','Cases','cases','id','AOP_Case_Events','aop_case_events','case_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('74700bbc-53bc-45b5-849e-592b09a1bad5','calls_contacts','Calls','calls','id','Contacts','contacts','id','calls_contacts','call_id','contact_id','many-to-many',\N,\N,0,0),
('75d9df65-2b42-d169-8c34-592b0906bdce','aop_case_updates_modified_user','Users','users','id','AOP_Case_Updates','aop_case_updates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('76d54a5a-dd3d-db40-b900-592b0998f341','aop_case_updates_created_by','Users','users','id','AOP_Case_Updates','aop_case_updates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7793afaa-b347-6e35-ff12-592b09afc262','aop_case_updates_assigned_user','Users','users','id','AOP_Case_Updates','aop_case_updates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('78282117-42c6-4040-e86f-592b09eeb325','cases_aop_case_updates','Cases','cases','id','AOP_Case_Updates','aop_case_updates','case_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('78c99407-7567-ede7-8574-592b09ba5c79','aop_case_updates_notes','AOP_Case_Updates','aop_case_updates','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','AOP_Case_Updates',0,0),
('7b439c83-43e5-fd26-6f46-592b0967f269','aor_reports_modified_user','Users','users','id','AOR_Reports','aor_reports','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7c4e070d-52f4-5c9d-aaf1-592b09db6961','aor_reports_created_by','Users','users','id','AOR_Reports','aor_reports','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7cf76cef-87d2-2e6f-eeab-592b098d278f','aor_reports_assigned_user','Users','users','id','AOR_Reports','aor_reports','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7d940828-de43-cf06-3c25-592b09829abe','securitygroups_aor_reports','SecurityGroups','securitygroups','id','AOR_Reports','aor_reports','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOR_Reports',0,0),
('7e2f0307-7bd6-a704-1aad-592b0940a36d','aor_reports_aor_fields','AOR_Reports','aor_reports','id','AOR_Fields','aor_fields','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7e4809c0-681e-7081-093a-592b09e50de2','calls_users','Calls','calls','id','Users','users','id','calls_users','call_id','user_id','many-to-many',\N,\N,0,0),
('7ec5a2cf-6418-62b1-5507-592b09c076a0','aor_reports_aor_conditions','AOR_Reports','aor_reports','id','AOR_Conditions','aor_conditions','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7f52485c-7bf4-9392-cbb8-592b091f997f','aor_scheduled_reports_aor_reports','AOR_Reports','aor_reports','id','AOR_Scheduled_Reports','aor_scheduled_reports','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('80993420-a60d-c9bd-4482-592b09c76729','aor_fields_modified_user','Users','users','id','AOR_Fields','aor_fields','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('80af0ec2-1395-1653-b36e-592b09bfadad','securitygroups_notes','SecurityGroups','securitygroups','id','Notes','notes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Notes',0,0),
('8187ab5b-dd0e-b73c-b453-592b09e00789','aor_fields_created_by','Users','users','id','AOR_Fields','aor_fields','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('82e66739-9e8b-90ac-423b-592b095f646c','aor_charts_modified_user','Users','users','id','AOR_Charts','aor_charts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('83aca4e7-2fbd-ceba-3772-592b09419f5e','leads_modified_user','Users','users','id','Leads','leads','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('83b03fcd-d9e4-6ccf-656b-592b0981d34a','aor_charts_created_by','Users','users','id','AOR_Charts','aor_charts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('843af56c-afe8-985b-4acb-592b09783513','aor_charts_aor_reports','AOR_Reports','aor_reports','id','AOR_Charts','aor_charts','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('84add48b-b0aa-64fa-92d4-592b09a92900','leads_created_by','Users','users','id','Leads','leads','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8555817f-5ea7-426b-432b-592b09322287','aor_conditions_modified_user','Users','users','id','AOR_Conditions','aor_conditions','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('857ed172-2c6b-d9ad-6e3d-592b0998669c','leads_assigned_user','Users','users','id','Leads','leads','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8618ef7a-f57d-3662-4d2c-592b09178863','aor_conditions_created_by','Users','users','id','AOR_Conditions','aor_conditions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('863d2709-dfb5-536c-9eae-592b09b3fe97','securitygroups_leads','SecurityGroups','securitygroups','id','Leads','leads','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Leads',0,0),
('86e667a1-61f4-03b7-96ef-592b0913a8ae','leads_email_addresses','Leads','leads','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Leads',0,0),
('87390d06-a807-b2cb-cb25-592b09a7844d','calls_leads','Calls','calls','id','Leads','leads','id','calls_leads','call_id','lead_id','many-to-many',\N,\N,0,0),
('878c7648-1700-c01f-7eb3-592b098cdbf4','leads_email_addresses_primary','Leads','leads','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('8796e08e-7b67-ff7f-cbc5-592b09c9222a','aor_scheduled_reports_modified_user','Users','users','id','AOR_Scheduled_Reports','aor_scheduled_reports','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('882555a8-6e25-af45-f272-592b099c924d','lead_direct_reports','Leads','leads','id','Leads','leads','reports_to_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('885029a3-17f3-ca27-6881-592b09dd4454','aor_scheduled_reports_created_by','Users','users','id','AOR_Scheduled_Reports','aor_scheduled_reports','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('88b34506-94e0-93b7-0e66-592b093498c1','lead_tasks','Leads','leads','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('896d776a-fda9-a249-a457-592b093746a5','lead_notes','Leads','leads','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('8a0988f7-29c9-5611-38b2-592b095030eb','aos_contracts_modified_user','Users','users','id','AOS_Contracts','aos_contracts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8a0f73b6-1cf5-aee1-2cbb-592b091c1588','lead_meetings','Leads','leads','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('8ac634ac-9ebf-ca96-7800-592b09362f12','lead_calls','Leads','leads','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('8ad8eefb-700e-142d-1831-592b09986542','aos_contracts_created_by','Users','users','id','AOS_Contracts','aos_contracts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8b584360-12f5-197c-05f3-592b0982167a','lead_emails','Leads','leads','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('8b792ff6-4b37-2c5a-fccf-592b0920c104','aos_contracts_assigned_user','Users','users','id','AOS_Contracts','aos_contracts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8b9a00e9-911a-c1c9-65ed-592b09a71485','notes_modified_user','Users','users','id','Notes','notes','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8c0b635c-8716-f3bf-451a-592b09d4eced','securitygroups_aos_contracts','SecurityGroups','securitygroups','id','AOS_Contracts','aos_contracts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Contracts',0,0),
('8c53296f-0648-3a03-52bd-592b09b688cd','lead_campaign_log','Leads','leads','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Leads',0,0),
('8ca0d851-e824-9585-0312-592b098e1c41','aos_contracts_tasks','AOS_Contracts','aos_contracts','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('8d3bc506-9773-56e6-37ea-592b09969ba1','aos_contracts_notes','AOS_Contracts','aos_contracts','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('8dd2c802-e661-b255-e6d3-592b09674dee','aos_contracts_meetings','AOS_Contracts','aos_contracts','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('8e21ff47-c267-ff3a-2af6-592b09b1b593','cases_modified_user','Users','users','id','Cases','cases','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8e8591c6-9ddd-709f-5b22-592b094aaeae','aos_contracts_calls','AOS_Contracts','aos_contracts','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('8ef5ed4e-cf83-fb9e-6415-592b095a95ce','cases_created_by','Users','users','id','Cases','cases','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8f2067be-206a-0796-8ff1-592b096dbb0f','aos_contracts_aos_products_quotes','AOS_Contracts','aos_contracts','id','AOS_Products_Quotes','aos_products_quotes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8fb80f58-26e7-b324-de72-592b09defca2','aos_contracts_aos_line_item_groups','AOS_Contracts','aos_contracts','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8fc55eb5-c8f8-f94f-8b59-592b0990e953','cases_assigned_user','Users','users','id','Cases','cases','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('90706dad-f2ce-f617-a0e9-592b09118045','securitygroups_cases','SecurityGroups','securitygroups','id','Cases','cases','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Cases',0,0),
('912d3e74-0427-9e4e-9d54-592b09059cef','case_calls','Cases','cases','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('91926b7e-13b4-ceb4-c85d-592b09232973','aos_invoices_modified_user','Users','users','id','AOS_Invoices','aos_invoices','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('92030da8-d8a7-ead5-c56d-592b097f92ae','case_tasks','Cases','cases','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('9270813b-0c00-5206-caed-592b09ce20e2','aos_invoices_created_by','Users','users','id','AOS_Invoices','aos_invoices','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('93174552-11bd-f935-9fbf-592b098aed9d','case_notes','Cases','cases','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('932708f7-f3a0-c101-c3c3-592b09950819','cases_bugs','Cases','cases','id','Bugs','bugs','id','cases_bugs','case_id','bug_id','many-to-many',\N,\N,0,0),
('932b8cfa-c73f-8b37-8c26-592b09056a17','aos_invoices_assigned_user','Users','users','id','AOS_Invoices','aos_invoices','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('93ec6bed-1934-1b20-8584-592b09741d64','case_meetings','Cases','cases','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('93f28e57-c69a-2198-6942-592b09b52f81','securitygroups_aos_invoices','SecurityGroups','securitygroups','id','AOS_Invoices','aos_invoices','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Invoices',0,0),
('94a0c3f9-fa23-cf17-9c2b-592b09b42a1f','case_emails','Cases','cases','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('95338d0d-883a-1fbc-155c-592b09aa2f0a','aos_invoices_aos_product_quotes','AOS_Invoices','aos_invoices','id','AOS_Products_Quotes','aos_products_quotes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9558dd9c-0570-7cfe-9e88-592b09a643bf','cases_created_contact','Contacts','contacts','id','Cases','cases','contact_created_by_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('95d0c4f6-5b66-119b-3bc5-592b09d15420','aos_invoices_aos_line_item_groups','AOS_Invoices','aos_invoices','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('96f99d12-8953-b80b-a322-592b09bada2b','bugs_modified_user','Users','users','id','Bugs','bugs','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('97454cc7-4172-1b0e-c23f-592b097db925','aos_pdf_templates_modified_user','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('978f061b-2f5b-f593-9764-592b09a7a525','notes_created_by','Users','users','id','Notes','notes','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('97bcb4da-c992-8303-9270-592b09785ea0','bugs_created_by','Users','users','id','Bugs','bugs','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9806b89f-2f85-142e-a125-592b099af4ff','aos_pdf_templates_created_by','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('98576889-b547-516c-c96a-592b09ad59e4','bugs_assigned_user','Users','users','id','Bugs','bugs','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('989e7f37-1491-902c-873c-592b09e29e66','aos_pdf_templates_assigned_user','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('98f78d60-d1ff-0052-e789-592b098936b8','securitygroups_bugs','SecurityGroups','securitygroups','id','Bugs','bugs','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Bugs',0,0),
('992ec95b-e8d0-e36c-271d-592b09f28781','securitygroups_aos_pdf_templates','SecurityGroups','securitygroups','id','AOS_PDF_Templates','aos_pdf_templates','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_PDF_Templates',0,0),
('99e4c77c-201b-9a3a-26bf-592b09b95c4a','bug_tasks','Bugs','bugs','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('9a80b53c-c1b7-de2f-9512-592b094a4170','aos_product_categories_modified_user','Users','users','id','AOS_Product_Categories','aos_product_categories','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9a8d0f29-c092-a019-75bc-592b099db7e4','bug_meetings','Bugs','bugs','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('9b2f70f4-84d8-6055-e4e4-592b09e62f8e','bug_calls','Bugs','bugs','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('9b51614c-2a95-d1d2-869d-592b095028a6','aos_product_categories_created_by','Users','users','id','AOS_Product_Categories','aos_product_categories','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9bcb34c5-a2f8-cbc5-9615-592b09297a9f','bug_emails','Bugs','bugs','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('9c161071-ac9c-4f8c-3d07-592b0925c4dd','aos_product_categories_assigned_user','Users','users','id','AOS_Product_Categories','aos_product_categories','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9c66e360-6500-076b-9d5f-592b09d9356b','bug_notes','Bugs','bugs','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('9cb7e172-3bcb-3409-3551-592b0992fa44','securitygroups_aos_product_categories','SecurityGroups','securitygroups','id','AOS_Product_Categories','aos_product_categories','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Product_Categories',0,0),
('9d031c86-a32e-8179-0df5-592b09bf710b','bugs_release','Releases','releases','id','Bugs','bugs','found_in_release',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9d5da050-e35b-2710-1fbc-592b09be3dc0','sub_product_categories','AOS_Product_Categories','aos_product_categories','id','AOS_Product_Categories','aos_product_categories','parent_category_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9d9b5c79-fc9a-888b-6005-592b0934427c','bugs_fixed_in_release','Releases','releases','id','Bugs','bugs','fixed_in_release',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9e7f35cf-1a9e-d76e-9235-592b098192fd','user_direct_reports','Users','users','id','Users','users','reports_to_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9ec3d4c3-1476-ff1a-58a6-592b09b24789','aos_products_modified_user','Users','users','id','AOS_Products','aos_products','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9f13f8c9-38ed-0fcb-e775-592b09027593','users_email_addresses','Users','users','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Users',0,0),
('9f93477e-5589-2d03-f64d-592b09dbb5b5','aos_products_created_by','Users','users','id','AOS_Products','aos_products','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9fa50c82-b490-ca68-d293-592b09da75e2','contacts_bugs','Contacts','contacts','id','Bugs','bugs','id','contacts_bugs','contact_id','bug_id','many-to-many',\N,\N,0,0),
('9fb5e48d-d59e-35c6-dbcc-592b094debda','users_email_addresses_primary','Users','users','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('a052aaf0-4289-3eb8-a851-592b091be323','aos_products_assigned_user','Users','users','id','AOS_Products','aos_products','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a0d33ade-8ffb-cc04-1f0d-592b091243d6','campaignlog_contact','CampaignLog','campaign_log','related_id','Contacts','contacts','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a0f3e333-468d-f88a-d513-592b094c2430','securitygroups_aos_products','SecurityGroups','securitygroups','id','AOS_Products','aos_products','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Products',0,0),
('a1957ca7-f79d-4cda-f201-592b09bfb50f','product_categories','AOS_Product_Categories','aos_product_categories','id','AOS_Products','aos_products','aos_product_category_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a1aa1ded-0556-3f79-d9e3-592b093cbde2','campaignlog_lead','CampaignLog','campaign_log','related_id','Leads','leads','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a2631428-aebc-f2b6-a093-592b096df338','campaignlog_created_opportunities','CampaignLog','campaign_log','related_id','Opportunities','opportunities','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a32652eb-e722-4d8d-9cde-592b094b6a1f','campaignlog_targeted_users','CampaignLog','campaign_log','target_id','Users','users','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a359dbb1-3481-684c-1e3b-592b0926c608','aos_products_quotes_modified_user','Users','users','id','AOS_Products_Quotes','aos_products_quotes','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a3dc6468-8b5d-9a7e-cf64-592b0959113c','campaignlog_sent_emails','CampaignLog','campaign_log','related_id','Emails','emails','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a41a8089-3854-fee5-2a54-592b0972ffd3','aos_products_quotes_created_by','Users','users','id','AOS_Products_Quotes','aos_products_quotes','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a4c47a49-8934-13b4-ae28-592b09e8f25f','aos_products_quotes_assigned_user','Users','users','id','AOS_Products_Quotes','aos_products_quotes','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a5793894-231a-9701-e036-592b09ae07e2','aos_product_quotes_aos_products','AOS_Products','aos_products','id','AOS_Products_Quotes','aos_products_quotes','product_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a58d82f7-c5e2-3349-2bfd-592b09a156dd','securitygroups_project','SecurityGroups','securitygroups','id','Project','project','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Project',0,0),
('a6656030-19f6-4cfe-3393-592b09e90e57','projects_notes','Project','project','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('a6cb5bb4-b810-874f-f605-592b091f4449','aos_line_item_groups_modified_user','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a75b4dce-b881-768b-a543-592b09c7823c','projects_tasks','Project','project','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('a7a27c91-4a40-9a4d-50e1-592b09459176','aos_line_item_groups_created_by','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a800c7bf-1b17-3d33-cb8f-592b09265780','projects_meetings','Project','project','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('a8634bdc-740e-91d3-5df2-592b09d4e4b3','aos_line_item_groups_assigned_user','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a89bb5fb-a832-00f1-ae09-592b09923812','projects_calls','Project','project','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('a91b3151-2caf-b8a6-c704-592b0988e2e8','groups_aos_product_quotes','AOS_Line_Item_Groups','aos_line_item_groups','id','AOS_Products_Quotes','aos_products_quotes','group_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a942db58-8bf3-016c-5280-592b09d3c7fa','projects_emails','Project','project','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('a9f16916-dab5-beba-dc6f-592b0947f8a3','projects_project_tasks','Project','project','id','ProjectTask','project_task','project_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('aa837b47-9542-8619-f27a-592b094853a7','projects_assigned_user','Users','users','id','Project','project','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('aae3b80b-59c9-c7e3-3648-592b099dc431','aos_quotes_modified_user','Users','users','id','AOS_Quotes','aos_quotes','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ab25bfac-2c4c-c42e-ae1a-592b096d95ad','projects_modified_user','Users','users','id','Project','project','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('abb58388-3de4-5bdc-aea3-592b099b692a','aos_quotes_created_by','Users','users','id','AOS_Quotes','aos_quotes','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('abc905e4-ee09-b278-c85f-592b0976cdad','contacts_cases','Contacts','contacts','id','Cases','cases','id','contacts_cases','contact_id','case_id','many-to-many',\N,\N,0,0),
('abccee4d-2710-0a7f-fa56-592b09367f7e','projects_created_by','Users','users','id','Project','project','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ac534301-60e6-ef93-4d71-592b096841d4','aos_quotes_assigned_user','Users','users','id','AOS_Quotes','aos_quotes','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ad149acf-c287-d4b4-95ec-592b092859dd','securitygroups_aos_quotes','SecurityGroups','securitygroups','id','AOS_Quotes','aos_quotes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Quotes',0,0),
('ad6e8322-06ea-ef8d-af6d-592b09001b61','securitygroups_projecttask','SecurityGroups','securitygroups','id','ProjectTask','project_task','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProjectTask',0,0),
('adbafe98-21eb-17fe-f159-592b09e10c16','aos_quotes_aos_product_quotes','AOS_Quotes','aos_quotes','id','AOS_Products_Quotes','aos_products_quotes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ae2a7c54-71a9-2234-8d50-592b09a493ce','project_tasks_notes','ProjectTask','project_task','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('ae5086b5-9254-61f2-d9b8-592b09fe3167','aos_quotes_aos_line_item_groups','AOS_Quotes','aos_quotes','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('aed475e9-0052-dd1b-58d2-592b098b6eca','project_tasks_tasks','ProjectTask','project_task','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('af70b376-e840-ff4d-a051-592b0900529e','project_tasks_meetings','ProjectTask','project_task','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('afbbbbec-ac96-d705-03d9-592b091c463c','aow_actions_modified_user','Users','users','id','AOW_Actions','aow_actions','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b02c25cf-8465-3fe7-196a-592b095a55d5','project_tasks_calls','ProjectTask','project_task','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('b1c65a44-503f-a645-68a3-592b09bfb4b6','project_tasks_emails','ProjectTask','project_task','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('b215f36c-27d5-90c4-8df4-592b090f275e','aow_actions_created_by','Users','users','id','AOW_Actions','aow_actions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b28d0c7c-ebb6-71e6-c477-592b09b7ffd6','project_tasks_assigned_user','Users','users','id','ProjectTask','project_task','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b30f6d59-1296-bc6a-ae10-592b09ddec49','aow_workflow_modified_user','Users','users','id','AOW_WorkFlow','aow_workflow','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b33d728b-b820-33d9-a603-592b09ab7fe0','project_tasks_modified_user','Users','users','id','ProjectTask','project_task','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b3cc7090-6f7c-7f7a-1447-592b09f5cc22','aow_workflow_created_by','Users','users','id','AOW_WorkFlow','aow_workflow','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b3f3ca40-cc40-eca1-221c-592b09a3eb8d','project_tasks_created_by','Users','users','id','ProjectTask','project_task','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b4c4fdc5-f594-a706-c6b5-592b0985081c','aow_workflow_assigned_user','Users','users','id','AOW_WorkFlow','aow_workflow','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b58c2c3c-122f-f65f-db80-592b0978e91e','securitygroups_aow_workflow','SecurityGroups','securitygroups','id','AOW_WorkFlow','aow_workflow','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOW_WorkFlow',0,0),
('b6345d9b-8a7e-fdff-7427-592b0966374a','campaigns_modified_user','Users','users','id','Campaigns','campaigns','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b64a0a7d-b85f-4908-24af-592b092ad750','aow_workflow_aow_conditions','AOW_WorkFlow','aow_workflow','id','AOW_Conditions','aow_conditions','aow_workflow_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b66a0802-67fb-bdbb-823f-592b091fe580','calls_modified_user','Users','users','id','Calls','calls','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b6e7e0d1-ad14-c739-3dd0-592b09d81210','aow_workflow_aow_actions','AOW_WorkFlow','aow_workflow','id','AOW_Actions','aow_actions','aow_workflow_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b728b192-ddc2-185c-5b4d-592b09901fb0','campaigns_created_by','Users','users','id','Campaigns','campaigns','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b784e95b-4f00-adff-8e01-592b098d63b4','aow_workflow_aow_processed','AOW_WorkFlow','aow_workflow','id','AOW_Processed','aow_processed','aow_workflow_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b7ebfaf6-47d9-bcd6-261d-592b0938cafb','campaigns_assigned_user','Users','users','id','Campaigns','campaigns','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b894074a-d4a3-cc69-f408-592b09723d2d','contacts_users','Contacts','contacts','id','Users','users','id','contacts_users','contact_id','user_id','many-to-many',\N,\N,0,0),
('b89f5c43-f95d-d098-c771-592b09083a10','securitygroups_campaigns','SecurityGroups','securitygroups','id','Campaigns','campaigns','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Campaigns',0,0),
('b8e56f51-394e-455a-346f-592b09f9054a','aow_processed_modified_user','Users','users','id','AOW_Processed','aow_processed','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b943c549-ba09-2278-285f-592b09fc7033','campaign_accounts','Campaigns','campaigns','id','Accounts','accounts','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b9ade5ac-1361-bb0b-37f0-592b09b90e2e','aow_processed_created_by','Users','users','id','AOW_Processed','aow_processed','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b9dd0bbd-3697-0410-2988-592b093c38b7','campaign_contacts','Campaigns','campaigns','id','Contacts','contacts','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ba83e91f-ee24-28fd-8f8f-592b09d717e9','campaign_leads','Campaigns','campaigns','id','Leads','leads','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bb11cbe7-4cec-9786-0e23-592b09af8615','aow_conditions_modified_user','Users','users','id','AOW_Conditions','aow_conditions','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bb2ff0e6-447b-0810-49da-592b09b9412d','campaign_prospects','Campaigns','campaigns','id','Prospects','prospects','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bbd54f70-bf2e-76e9-9660-592b09062da8','aow_conditions_created_by','Users','users','id','AOW_Conditions','aow_conditions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bbeb8a58-ac08-17a4-40b3-592b091a6eb0','campaign_opportunities','Campaigns','campaigns','id','Opportunities','opportunities','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bd198267-2ed9-46f4-917d-592b09a07f4c','campaign_email_marketing','Campaigns','campaigns','id','EmailMarketing','email_marketing','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('be297954-ed49-f704-d6e8-592b09280f32','campaign_emailman','Campaigns','campaigns','id','EmailMan','emailman','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('be771ff4-ccf0-8c93-5927-592b09f67ec6','jjwg_maps_modified_user','Users','users','id','jjwg_Maps','jjwg_maps','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bedf246a-8897-88d5-7354-592b0947e084','campaign_campaignlog','Campaigns','campaigns','id','CampaignLog','campaign_log','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bf4a258d-6eb9-06bd-695b-592b099266cb','jjwg_maps_created_by','Users','users','id','jjwg_Maps','jjwg_maps','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bf98f731-1409-dbb6-5fc2-592b09bf40f4','campaign_assigned_user','Users','users','id','Campaigns','campaigns','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bffec500-bbba-7bd1-a86e-592b09938195','jjwg_maps_assigned_user','Users','users','id','jjwg_Maps','jjwg_maps','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c044fcac-f7b8-590f-b40c-592b096ec8d8','campaign_modified_user','Users','users','id','Campaigns','campaigns','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c0acebf3-8b99-a6eb-8e7f-592b09b2eaf3','securitygroups_jjwg_maps','SecurityGroups','securitygroups','id','jjwg_Maps','jjwg_maps','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Maps',0,0),
('c1411d3e-c95c-6fa6-6341-592b0954e1bd','jjwg_Maps_accounts','jjwg_Maps','jjwg_Maps','parent_id','Accounts','accounts','id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('c1da76e8-30a5-c57e-466f-592b095b1320','jjwg_Maps_contacts','jjwg_Maps','jjwg_Maps','parent_id','Contacts','contacts','id',\N,\N,\N,'one-to-many','parent_type','Contacts',0,0),
('c2274266-5b8b-0cf1-c3ee-592b09310037','prospectlists_assigned_user','Users','users','id','prospectlists','prospect_lists','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c2862300-4864-89fd-32db-592b09675f38','jjwg_Maps_leads','jjwg_Maps','jjwg_Maps','parent_id','Leads','leads','id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('c2efcf81-ad34-5908-a55e-592b097ba9ac','securitygroups_prospectlists','SecurityGroups','securitygroups','id','ProspectLists','prospect_lists','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProspectLists',0,0),
('c39501d2-cea9-e643-a5a8-592b0912fa77','calls_created_by','Users','users','id','Calls','calls','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c39669e7-6140-43a6-8722-592b09430bee','jjwg_Maps_opportunities','jjwg_Maps','jjwg_Maps','parent_id','Opportunities','opportunities','id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('c40e071f-3afb-e800-e205-592b097c92ed','emails_bugs_rel','Emails','emails','id','Bugs','bugs','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Bugs',0,0),
('c42b5933-cba9-c79d-84ae-592b09c770fd','jjwg_Maps_cases','jjwg_Maps','jjwg_Maps','parent_id','Cases','cases','id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('c4c2dd80-2e1b-f0c8-345f-592b096ebd7d','prospects_modified_user','Users','users','id','Prospects','prospects','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c4c48b34-4831-4306-3e68-592b092afcc6','jjwg_Maps_projects','jjwg_Maps','jjwg_Maps','parent_id','Project','project','id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('c557a2b5-0396-9e97-a57a-592b09b9678f','jjwg_Maps_meetings','jjwg_Maps','jjwg_Maps','parent_id','Meetings','meetings','id',\N,\N,\N,'one-to-many','parent_type','Meetings',0,0),
('c59af1ba-f331-c21a-107e-592b097b1be6','prospects_created_by','Users','users','id','Prospects','prospects','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c5e49495-3bbf-5bcd-062b-592b09ccd764','jjwg_Maps_prospects','jjwg_Maps','jjwg_Maps','parent_id','Prospects','prospects','id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('c63aa066-f987-3255-ff39-592b098b9301','prospects_assigned_user','Users','users','id','Prospects','prospects','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c6e0d8c0-63f5-6b31-2156-592b0968d183','securitygroups_prospects','SecurityGroups','securitygroups','id','Prospects','prospects','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Prospects',0,0),
('c77de14c-c725-13d9-a6a1-592b09b3adf1','prospects_email_addresses','Prospects','prospects','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Prospects',0,0),
('c83b507f-7665-7674-3510-592b0967e9f1','prospects_email_addresses_primary','Prospects','prospects','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('c87e6d05-9121-2318-aa68-592b09382935','jjwg_markers_modified_user','Users','users','id','jjwg_Markers','jjwg_markers','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c8d634f8-8e03-d72c-c1ca-592b09184682','prospect_tasks','Prospects','prospects','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('c96a5114-0469-d0e0-81b7-592b09f01dd9','jjwg_markers_created_by','Users','users','id','jjwg_Markers','jjwg_markers','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c96adbd9-1b42-2620-0f9a-592b09b2a0d9','prospect_notes','Prospects','prospects','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('c9fd8666-0b21-a02a-b005-592b092810bb','prospect_meetings','Prospects','prospects','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('ca18e8eb-7717-b224-87be-592b0932f808','jjwg_markers_assigned_user','Users','users','id','jjwg_Markers','jjwg_markers','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ca8d5aad-eba7-e15d-7a87-592b092d6359','prospect_calls','Prospects','prospects','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('cad37c6a-b6c9-dc5d-d063-592b0980ae3a','securitygroups_jjwg_markers','SecurityGroups','securitygroups','id','jjwg_Markers','jjwg_markers','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Markers',0,0),
('cb18bcfe-c9c5-1a0a-2a74-592b09177a43','prospect_emails','Prospects','prospects','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('cb9dc766-01f2-7dc3-ea75-592b092c1763','prospect_campaign_log','Prospects','prospects','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Prospects',0,0),
('ccc3049b-3ab7-8e1f-f885-592b09b9cb56','email_template_email_marketings','EmailTemplates','email_templates','id','EmailMarketing','email_marketing','template_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cd742fbe-03ae-a87a-c1cf-592b0932275e','jjwg_areas_modified_user','Users','users','id','jjwg_Areas','jjwg_areas','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cdef5eda-de9a-7bcb-3134-592b0927b410','campaign_campaigntrakers','Campaigns','campaigns','id','CampaignTrackers','campaign_trkrs','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cdfd0003-6dd0-899b-865d-592b096926d7','emails_cases_rel','Emails','emails','id','Cases','cases','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Cases',0,0),
('ce6b7246-4aff-f1f5-14af-592b09ee9664','jjwg_areas_created_by','Users','users','id','jjwg_Areas','jjwg_areas','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ced30988-1f2e-78a3-dcc9-592b09e992d6','calls_assigned_user','Users','users','id','Calls','calls','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cf18b1ea-3c6f-c528-9732-592b091430e1','jjwg_areas_assigned_user','Users','users','id','jjwg_Areas','jjwg_areas','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cfb6a084-8b9c-7fde-0ff5-592b097c754f','securitygroups_jjwg_areas','SecurityGroups','securitygroups','id','jjwg_Areas','jjwg_areas','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Areas',0,0),
('d0b4c9e4-f718-fb61-1677-592b091a4464','schedulers_created_by_rel','Users','users','id','Schedulers','schedulers','created_by',\N,\N,\N,'one-to-one',\N,\N,0,0),
('d1b1a3e0-4c40-e1ac-e56d-592b0988658c','schedulers_modified_user_id_rel','Users','users','id','Schedulers','schedulers','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d1d0e145-4676-ebe2-43a9-592b099ccb79','jjwg_address_cache_modified_user','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d27fea52-0767-8c2b-3329-592b093cd8a4','schedulers_jobs_rel','Schedulers','schedulers','id','SchedulersJobs','job_queue','scheduler_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d2bb7465-d011-24e6-cf71-592b098c6756','jjwg_address_cache_created_by','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d35741a2-4cde-d53e-40d3-592b09e8a483','schedulersjobs_assigned_user','Users','users','id','SchedulersJobs','job_queue','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d37a177f-ad8a-2592-7079-592b097f46e7','jjwg_address_cache_assigned_user','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d4c4bee2-ba2b-e5c1-db82-592b0923b76b','calls_reschedule_modified_user','Users','users','id','Calls_Reschedule','calls_reschedule','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d5917574-9518-bbcd-d80a-592b091d051a','calls_reschedule_created_by','Users','users','id','Calls_Reschedule','calls_reschedule','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d596909a-6881-32f2-aa99-592b09555af9','contacts_modified_user','Users','users','id','Contacts','contacts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d68ae0b7-a5a5-017d-2db2-592b092f46bc','calls_reschedule_assigned_user','Users','users','id','Calls_Reschedule','calls_reschedule','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d6ac9b6b-6a23-f222-b1b1-592b09af8219','contacts_created_by','Users','users','id','Contacts','contacts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d74dc2d5-4d8e-9719-8df2-592b096d7325','contacts_assigned_user','Users','users','id','Contacts','contacts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d76d5c6f-495e-a54f-2614-592b0987b32d','securitygroups_modified_user','Users','users','id','SecurityGroups','securitygroups','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d7fe1bed-cc67-f4a7-7746-592b095fb3a9','securitygroups_contacts','SecurityGroups','securitygroups','id','Contacts','contacts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Contacts',0,0),
('d80936e6-8107-580d-edc2-592b0975ce95','securitygroups_created_by','Users','users','id','SecurityGroups','securitygroups','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d891c081-febc-a141-4ee5-592b09103f52','contacts_email_addresses','Contacts','contacts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Contacts',0,0),
('d8b02c51-2460-5162-73d0-592b090e0549','securitygroups_assigned_user','Users','users','id','SecurityGroups','securitygroups','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d9301bb0-5852-bc7d-de96-592b096965bc','contacts_email_addresses_primary','Contacts','contacts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('d97f08e0-6b25-3e9d-dce9-592b09bf9f8c','emails_opportunities_rel','Emails','emails','id','Opportunities','opportunities','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Opportunities',0,0),
('d9d968ca-6786-078c-56e5-592b09daf1a1','contact_direct_reports','Contacts','contacts','id','Contacts','contacts','reports_to_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d9f729ba-a40a-74ae-a7c2-592b09488419','outbound_email_modified_user','Users','users','id','OutboundEmailAccounts','outbound_email','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('da8a4a9c-a895-9e54-4a84-592b09fd19ff','contact_leads','Contacts','contacts','id','Leads','leads','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('daae051e-880f-e876-2179-592b0983a0b6','securitygroups_calls','SecurityGroups','securitygroups','id','Calls','calls','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Calls',0,0),
('dab3c76e-a132-6143-69b3-592b09c31f93','outbound_email_created_by','Users','users','id','OutboundEmailAccounts','outbound_email','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('db31846f-ef74-0e54-3bcf-592b09b48209','contact_notes','Contacts','contacts','id','Notes','notes','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('db5fe0d0-ae45-adde-cda6-592b096fd1f6','outbound_email_assigned_user','Users','users','id','OutboundEmailAccounts','outbound_email','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dbce718d-9025-73aa-9bb6-592b09a5ea4e','contact_tasks','Contacts','contacts','id','Tasks','tasks','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dc64d210-fdd3-5075-7760-592b09021ebc','contact_tasks_parent','Contacts','contacts','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Contacts',0,0),
('dc9081ea-cae4-c09b-56d1-592b09458160','templatesectionline_modified_user','Users','users','id','TemplateSectionLine','templatesectionline','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dd019314-593e-fd8e-e8ab-592b09e1f578','contact_notes_parent','Contacts','contacts','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Contacts',0,0),
('dd42b46c-b00b-ebf2-aaff-592b093a5ed2','templatesectionline_created_by','Users','users','id','TemplateSectionLine','templatesectionline','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dd9b45cc-bdd3-55d7-9a06-592b094e8edf','contact_campaign_log','Contacts','contacts','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Contacts',0,0),
('de3aa985-cf23-50f2-c1b5-592b094dd35f','contact_aos_quotes','Contacts','contacts','id','AOS_Quotes','aos_quotes','billing_contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('de6db8e1-5bde-3ba6-6c0d-592b0968dca8','sro_svid_sro_modified_user','Users','users','id','sro_svid_sro','sro_svid_sro','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ded7cabb-d7e1-e076-e4f2-592b0958db6e','contact_aos_invoices','Contacts','contacts','id','AOS_Invoices','aos_invoices','billing_contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('df2e078e-62b9-eea6-fb0d-592b09574fba','sro_svid_sro_created_by','Users','users','id','sro_svid_sro','sro_svid_sro','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('df72a084-ad2a-2537-6c8d-592b09b0631d','contact_aos_contracts','Contacts','contacts','id','AOS_Contracts','aos_contracts','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dfce896a-a7ef-0cd0-408a-592b0931d7fa','sro_svid_sro_assigned_user','Users','users','id','sro_svid_sro','sro_svid_sro','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e01688bf-5bd0-3ca4-7d41-592b09933775','contacts_aop_case_updates','Contacts','contacts','id','AOP_Case_Updates','aop_case_updates','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e06d8ab5-8f77-7c71-cff2-592b09cb8175','securitygroups_sro_svid_sro','SecurityGroups','securitygroups','id','sro_svid_sro','sro_svid_sro','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','sro_svid_sro',0,0),
('e2072dde-80f5-ccf6-c8f0-592b090854b4','dp_bkrv_modified_user','Users','users','id','dp_bkrv','dp_bkrv','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e2725263-1f5c-91d3-f13b-592b0987dc7d','accounts_modified_user','Users','users','id','Accounts','accounts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e2c814b0-3f4e-d289-7fe4-592b09be704d','dp_bkrv_created_by','Users','users','id','dp_bkrv','dp_bkrv','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e30e07ed-6987-c753-567a-592b09eb2e05','emails_tasks_rel','Emails','emails','id','Tasks','tasks','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Tasks',0,0),
('e3656511-3f27-9e59-5b1b-592b0904ebf0','accounts_created_by','Users','users','id','Accounts','accounts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e37e753b-68cc-46c5-6068-592b098beab3','dp_bkrv_assigned_user','Users','users','id','dp_bkrv','dp_bkrv','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e404edb2-c0d1-2a0e-e762-592b090a1065','accounts_assigned_user','Users','users','id','Accounts','accounts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e480a183-921b-1928-a3b3-592b0939f2a5','securitygroups_dp_bkrv','SecurityGroups','securitygroups','id','dp_bkrv','dp_bkrv','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_bkrv',0,0),
('e49c2fd2-7ce7-c984-6397-592b0918ae6e','securitygroups_accounts','SecurityGroups','securitygroups','id','Accounts','accounts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Accounts',0,0),
('e5577d50-a713-f286-6143-592b09fe1dcc','accounts_email_addresses','Accounts','accounts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Accounts',0,0),
('e5b0018d-7474-b64a-62f8-592b09ca123c','calls_notes','Calls','calls','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Calls',0,0),
('e5fc8c07-aeec-8950-6505-592b0986f191','accounts_email_addresses_primary','Accounts','accounts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('e68afebb-9fd0-d4e3-b0f4-592b090357c6','member_accounts','Accounts','accounts','id','Accounts','accounts','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e6c61efb-df42-5f61-168f-592b0987a485','dp_realty_modified_user','Users','users','id','dp_realty','dp_realty','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e73db7ca-15f8-2a9a-3a2b-592b0994b972','account_cases','Accounts','accounts','id','Cases','cases','account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e7b7bfa3-cd02-5bc8-66d5-592b091abe15','dp_realty_created_by','Users','users','id','dp_realty','dp_realty','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e7d9ad2b-4b16-8076-0f93-592b098ad4e3','account_tasks','Accounts','accounts','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('e86f496f-bb61-886f-eeb2-592b09cba66b','dp_realty_assigned_user','Users','users','id','dp_realty','dp_realty','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e893e95e-73af-8157-a06e-592b09e8c33e','account_notes','Accounts','accounts','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('e91a449f-20af-9102-3073-592b096f8304','securitygroups_dp_realty','SecurityGroups','securitygroups','id','dp_realty','dp_realty','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_realty',0,0),
('e942bb19-c2ab-6b3c-fc3b-592b0941dbd2','account_meetings','Accounts','accounts','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('e9df14e8-c512-cfd1-43ad-592b09c52383','account_calls','Accounts','accounts','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('ea6d5c65-8406-272e-ceca-592b093e8c98','account_emails','Accounts','accounts','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('ea8a6a1b-dff0-0355-5c8f-592b09b87e23','dp_license_modified_user','Users','users','id','dp_license','dp_license','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('eb04cc17-e1e4-6575-739a-592b0936dd26','account_leads','Accounts','accounts','id','Leads','leads','account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('eb69007c-eca0-b1a5-3cee-592b09c1a92a','dp_license_created_by','Users','users','id','dp_license','dp_license','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('eb976209-252f-0316-8b72-592b09bccf4a','account_campaign_log','Accounts','accounts','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Accounts',0,0),
('ebfd76a1-e12e-4a53-cdb5-592b09a4ceaa','dp_license_assigned_user','Users','users','id','dp_license','dp_license','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ec25ed60-4457-a4a8-2e5f-592b09eae667','account_aos_quotes','Accounts','accounts','id','AOS_Quotes','aos_quotes','billing_account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ec460aa3-ecdc-c201-0d2a-592b09e97bf5','emails_users_rel','Emails','emails','id','Users','users','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Users',0,0),
('ecaa505d-e40e-5203-e632-592b09110f6d','securitygroups_dp_license','SecurityGroups','securitygroups','id','dp_license','dp_license','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_license',0,0),
('ecd2ca47-aec1-388f-55c4-592b091dc260','account_aos_invoices','Accounts','accounts','id','AOS_Invoices','aos_invoices','billing_account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ed6960bd-e99f-3827-c0e1-592b09e17f14','account_aos_contracts','Accounts','accounts','id','AOS_Contracts','aos_contracts','contract_account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ef263676-687c-f2f9-b290-592b093dffea','opportunities_modified_user','Users','users','id','Opportunities','opportunities','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ef6602d1-d3c4-3123-a5b4-592b09fcefd1','calls_reschedule','Calls','calls','id','Calls_Reschedule','calls_reschedule','call_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('eff325d6-b878-9702-ce1a-592b0947f513','opportunities_created_by','Users','users','id','Opportunities','opportunities','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f0b17620-14dd-43cf-fd90-592b09d115bb','opportunities_assigned_user','Users','users','id','Opportunities','opportunities','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f15b839c-aa3e-708e-ffe3-592b0957e950','securitygroups_opportunities','SecurityGroups','securitygroups','id','Opportunities','opportunities','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Opportunities',0,0),
('f1f8ed75-bc08-a1db-84f5-592b09df6e30','opportunity_calls','Opportunities','opportunities','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('f289a66c-1089-6ff1-5111-592b09f9a589','opportunity_meetings','Opportunities','opportunities','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('f325828a-a0ac-36ad-de67-592b090dcd39','opportunity_tasks','Opportunities','opportunities','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('f3c8747f-fde0-5140-42a7-592b09c13fc0','opportunity_notes','Opportunities','opportunities','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('f4c00082-bd59-efd5-9d23-592b093bd049','opportunity_leads','Opportunities','opportunities','id','Leads','leads','opportunity_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f6a403d1-85b6-be37-ae64-592b09175f9a','emails_project_task_rel','Emails','emails','id','ProjectTask','project_task','id','emails_beans','email_id','bean_id','many-to-many','bean_module','ProjectTask',0,0),
('fff70141-fbca-1d9f-8754-592b09a17d42','emails_projects_rel','Emails','emails','id','Project','project','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Project',0,0)	;
#	TC`releases`utf8_general_ci	;
CREATE TABLE `releases` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `list_order` int(4) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_releases` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`reminders`utf8_general_ci	;
CREATE TABLE `reminders` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `popup` tinyint(1) DEFAULT NULL,
  `email` tinyint(1) DEFAULT NULL,
  `email_sent` tinyint(1) DEFAULT NULL,
  `timer_popup` varchar(32) DEFAULT NULL,
  `timer_email` varchar(32) DEFAULT NULL,
  `related_event_module` varchar(32) DEFAULT NULL,
  `related_event_module_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_name` (`name`),
  KEY `idx_reminder_deleted` (`deleted`),
  KEY `idx_reminder_related_event_module` (`related_event_module`),
  KEY `idx_reminder_related_event_module_id` (`related_event_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`reminders_invitees`utf8_general_ci	;
CREATE TABLE `reminders_invitees` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `reminder_id` char(36) NOT NULL,
  `related_invitee_module` varchar(32) DEFAULT NULL,
  `related_invitee_module_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_invitee_name` (`name`),
  KEY `idx_reminder_invitee_assigned_user_id` (`assigned_user_id`),
  KEY `idx_reminder_invitee_reminder_id` (`reminder_id`),
  KEY `idx_reminder_invitee_related_invitee_module` (`related_invitee_module`),
  KEY `idx_reminder_invitee_related_invitee_module_id` (`related_invitee_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`roles`utf8_general_ci	;
CREATE TABLE `roles` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text,
  `modules` text,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_role_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`roles_modules`utf8_general_ci	;
CREATE TABLE `roles_modules` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `module_id` varchar(36) DEFAULT NULL,
  `allow` tinyint(1) DEFAULT '0',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`roles_users`utf8_general_ci	;
CREATE TABLE `roles_users` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ru_role_id` (`role_id`),
  KEY `idx_ru_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`saved_search`utf8_general_ci	;
CREATE TABLE `saved_search` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `search_module` varchar(150) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `contents` text,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `idx_desc` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`schedulers`utf8_general_ci	;
CREATE TABLE `schedulers` (
  `id` varchar(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `date_time_start` datetime DEFAULT NULL,
  `date_time_end` datetime DEFAULT NULL,
  `job_interval` varchar(100) DEFAULT NULL,
  `time_from` time DEFAULT NULL,
  `time_to` time DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `catch_up` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_schedule` (`date_time_start`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`schedulers`utf8_general_ci	;
INSERT INTO `schedulers` VALUES 
('9ef2e732-8331-b0ce-2e5d-592564fb2f50',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Process Workflow Tasks','function::processAOW_Workflow','2015-01-01 07:45:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',1),
('a120b680-1757-229f-bcef-592564348ef3',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Report Generation Scheduled Tasks','function::aorRunScheduledReports','2015-01-01 12:15:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',1),
('a2ef5d99-d760-be9e-24e0-5925649c8f60',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Prune Tracker Tables','function::trimTracker','2015-01-01 16:15:01',\N,'0::2::1::*::*',\N,\N,\N,'Active',1),
('a48fc895-c74d-ca4e-9b94-592564195048',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Check Inbound Mailboxes','function::pollMonitoredInboxesAOP','2015-01-01 11:30:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',0),
('a606571d-ba31-c37f-a269-59256486afdd',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Nightly Process Bounced Campaign Emails','function::pollMonitoredInboxesForBouncedCampaignEmails','2015-01-01 06:00:01',\N,'0::2-6::*::*::*',\N,\N,\N,'Active',1),
('a77671b5-8be3-33be-ae32-5925640cbfa5',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Nightly Mass Email Campaigns','function::runMassEmailCampaign','2015-01-01 09:15:01',\N,'0::2-6::*::*::*',\N,\N,\N,'Active',1),
('a94f32f9-38c3-87a5-658f-592564b763cc',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Prune Database on 1st of Month','function::pruneDatabase','2015-01-01 08:00:01',\N,'0::4::1::*::*',\N,\N,\N,'Inactive',0),
('ab26f650-02f9-743d-1709-5925642e7797',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Perform Lucene Index','function::aodIndexUnindexed','2015-01-01 18:15:01',\N,'0::0::*::*::*',\N,\N,\N,'Active',0),
('ace7bd31-a898-1077-f590-5925644d5619',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Optimise AOD Index','function::aodOptimiseIndex','2015-01-01 09:15:01',\N,'0::*/3::*::*::*',\N,\N,\N,'Active',0),
('ae7475bd-d44d-9cab-de89-5925646c927b',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Email Reminder Notifications','function::sendEmailReminders','2015-01-01 08:15:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',0),
('b033f8dd-c87b-0589-a0ff-5925649ee29b',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Clean Jobs Queue','function::cleanJobQueue','2015-01-01 13:30:01',\N,'0::5::*::*::*',\N,\N,\N,'Active',0),
('b1b3df87-0c25-6d61-59ba-592564f86a90',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Removal of documents from filesystem','function::removeDocumentsFromFS','2015-01-01 14:00:01',\N,'0::3::1::*::*',\N,\N,\N,'Active',0),
('b306a670-ffa8-f0b8-14f5-5925647b1c99',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Prune SuiteCRM Feed Tables','function::trimSugarFeeds','2015-01-01 11:30:01',\N,'0::2::1::*::*',\N,\N,\N,'Active',1)	;
#	TC`securitygroups`utf8_general_ci	;
CREATE TABLE `securitygroups` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `noninheritable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_acl_roles`utf8_general_ci	;
CREATE TABLE `securitygroups_acl_roles` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `role_id` char(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_audit`utf8_general_ci	;
CREATE TABLE `securitygroups_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_securitygroups_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_default`utf8_general_ci	;
CREATE TABLE `securitygroups_default` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_records`utf8_general_ci	;
CREATE TABLE `securitygroups_records` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `record_id` char(36) DEFAULT NULL,
  `module` char(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_securitygroups_records_mod` (`module`,`deleted`,`record_id`,`securitygroup_id`),
  KEY `idx_securitygroups_records_del` (`deleted`,`record_id`,`module`,`securitygroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_users`utf8_general_ci	;
CREATE TABLE `securitygroups_users` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `securitygroup_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `primary_group` tinyint(1) DEFAULT NULL,
  `noninheritable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `securitygroups_users_idxa` (`securitygroup_id`),
  KEY `securitygroups_users_idxb` (`user_id`),
  KEY `securitygroups_users_idxc` (`user_id`,`deleted`,`securitygroup_id`,`id`),
  KEY `securitygroups_users_idxd` (`user_id`,`deleted`,`securitygroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`spots`utf8_general_ci	;
CREATE TABLE `spots` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `config` longtext,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sro_svid_sro`utf8_general_ci	;
CREATE TABLE `sro_svid_sro` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sro_svid_sro_audit`utf8_general_ci	;
CREATE TABLE `sro_svid_sro_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_sro_svid_sro_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sro_svid_sro_cstm`utf8_general_ci	;
CREATE TABLE `sro_svid_sro_cstm` (
  `id_c` char(36) NOT NULL,
  `num_sro_c` varchar(80) DEFAULT NULL,
  `date_sro_c` date DEFAULT NULL,
  `bywhom_sro_c` varchar(150) DEFAULT NULL,
  `srok_work_sro_c` date DEFAULT NULL,
  `account_id_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sugarfeed`utf8_general_ci	;
CREATE TABLE `sugarfeed` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `related_module` varchar(100) DEFAULT NULL,
  `related_id` char(36) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `link_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sgrfeed_date` (`date_entered`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`sugarfeed`utf8_general_ci	;
INSERT INTO `sugarfeed` VALUES 
('f17c0131-270e-7a85-15c6-5927e51a6912','<b>{this.CREATED_BY}</b> {SugarFeed.CREATED_CONTACT} [Contacts:e41e39af-5bdc-0b83-c659-5927e5a9adf7:Семён Антонов]','2017-05-26 08:23:20','2017-05-26 08:23:20','1','1',\N,0,'1','Contacts','e41e39af-5bdc-0b83-c659-5927e5a9adf7',\N,\N)	;
#	TC`tasks`utf8_general_ci	;
CREATE TABLE `tasks` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `date_due_flag` tinyint(1) DEFAULT '0',
  `date_due` datetime DEFAULT NULL,
  `date_start_flag` tinyint(1) DEFAULT '0',
  `date_start` datetime DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tsk_name` (`name`),
  KEY `idx_task_con_del` (`contact_id`,`deleted`),
  KEY `idx_task_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_task_assigned` (`assigned_user_id`),
  KEY `idx_task_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`templatesectionline`utf8_general_ci	;
CREATE TABLE `templatesectionline` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `thumbnail` varchar(255) DEFAULT NULL,
  `grp` varchar(255) DEFAULT NULL,
  `ord` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tracker`utf8_general_ci	;
CREATE TABLE `tracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monitor_id` char(36) NOT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  `item_id` varchar(36) DEFAULT NULL,
  `item_summary` varchar(255) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `session_id` varchar(36) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tracker_iid` (`item_id`),
  KEY `idx_tracker_userid_vis_id` (`user_id`,`visible`,`id`),
  KEY `idx_tracker_userid_itemid_vis` (`user_id`,`item_id`,`visible`),
  KEY `idx_tracker_monitor_id` (`monitor_id`),
  KEY `idx_tracker_date_modified` (`date_modified`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8	;
#	TD`tracker`utf8_general_ci	;
INSERT INTO `tracker` VALUES 
(26,'d9cce47e-7f9e-88d1-db5d-59272c0293fe','1','dp_bkrv','cc7ac549-b341-f38a-0bdc-5926d3163ea2','Российский капитал','2017-05-25 19:13:28','detailview','2sf5r7pv4flgeorgcs8dih1h17',1,0),
(47,'8864fff3-b56a-722b-c7be-5927340cd92e','1','dp_realty','55092ca4-45ce-f10f-c85d-59272dbd7b35','443068, г. Самара, ул. Ново-Садовая, д. 106, оф. 613','2017-05-25 19:45:02','editview','2sf5r7pv4flgeorgcs8dih1h17',1,0),
(73,'6cc6d584-d8ef-257f-dcc0-592803bc2e8e','1','Accounts','b9f49b4f-21dc-4a20-5646-592571b11c40','Общество с ограниченной ответственностью «Солнечная долина»','2017-05-26 10:30:37','editview','1l9a8hsqb125cg4efp7au6ccr2',1,0),
(81,'84ad1603-9085-0a2a-d55d-592b09de704e','1','Contacts','e41e39af-5bdc-0b83-c659-5927e5a9adf7','Семён Антонов','2017-05-28 17:32:07','editview','bbje83id5bahhef871vjq135j7',1,0),
(86,'c0834ed5-decc-852e-f30a-592b127d36b3','1','Accounts','f1c17d43-b29f-16ef-5774-5927e6b4501a','Общество с ограниченной ответственностью «Эффективные технологии»','2017-05-28 18:10:24','editview','oektf4ebsvg66gsjau486ovss3',1,0)	;
#	TC`upgrade_history`utf8_general_ci	;
CREATE TABLE `upgrade_history` (
  `id` char(36) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `md5sum` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `version` varchar(64) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `id_name` varchar(255) DEFAULT NULL,
  `manifest` longtext,
  `date_entered` datetime DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `upgrade_history_md5_uk` (`md5sum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`upgrade_history`utf8_general_ci	;
INSERT INTO `upgrade_history` VALUES 
('323753ed-04ad-de2b-0a21-5926cf321f6c','upload/upgrades/module/project_lp2017_05_25_153515.zip','6e652259e49d8e0ee2a2d506e3d89d6e','module','installed','1495715715','project_lp','Дополнительные параметры','project_lp','YTozOntzOjg6Im1hbmlmZXN0IjthOjEzOntpOjA7YToxOntzOjI1OiJhY2NlcHRhYmxlX3N1Z2FyX3ZlcnNpb25zIjthOjE6e2k6MDtzOjY6IjYuNS4yNCI7fX1pOjE7YToxOntzOjI0OiJhY2NlcHRhYmxlX3N1Z2FyX2ZsYXZvcnMiO2E6Mzp7aTowO3M6MjoiQ0UiO2k6MTtzOjM6IlBSTyI7aToyO3M6MzoiRU5UIjt9fXM6NjoicmVhZG1lIjtzOjA6IiI7czozOiJrZXkiO3M6MjoiZHAiO3M6NjoiYXV0aG9yIjtzOjQ6ImlhbXkiO3M6MTE6ImRlc2NyaXB0aW9uIjtzOjQ3OiLQlNC+0L/QvtC70L3QuNGC0LXQu9GM0L3Ri9C1INC/0LDRgNCw0LzQtdGC0YDRiyI7czo0OiJpY29uIjtzOjA6IiI7czoxNjoiaXNfdW5pbnN0YWxsYWJsZSI7YjoxO3M6NDoibmFtZSI7czoxMDoicHJvamVjdF9scCI7czoxNDoicHVibGlzaGVkX2RhdGUiO3M6MTk6IjIwMTctMDUtMjUgMTI6MzU6MTUiO3M6NDoidHlwZSI7czo2OiJtb2R1bGUiO3M6NzoidmVyc2lvbiI7aToxNDk1NzE1NzE1O3M6MTM6InJlbW92ZV90YWJsZXMiO3M6NjoicHJvbXB0Ijt9czoxMToiaW5zdGFsbGRlZnMiO2E6Mjp7czoyOiJpZCI7czoxMDoicHJvamVjdF9scCI7czo0OiJjb3B5IjthOjE6e2k6MDthOjI6e3M6NDoiZnJvbSI7czoxMzoiPGJhc2VwYXRoPi9scCI7czoyOiJ0byI7czozMjoiY3VzdG9tL21vZHVsZWJ1aWxkZXIvcGFja2FnZXMvbHAiO319fXM6MTY6InVwZ3JhZGVfbWFuaWZlc3QiO3M6MDoiIjt9','2017-05-25 12:36:33',1),
('60b11b2a-aca4-c019-6603-592566248774','upload/upgrades/langpack/ru.zip','8be6d98cef9222ffa18dfcf37aa23ebd','langpack','installed','7.8.3.6','Russian (Russia)','Перевод: www.crowdin.com/project/suitecrmtranslations','ru_RU','YTozOntzOjg6Im1hbmlmZXN0IjthOjk6e3M6NDoibmFtZSI7czoxNjoiUnVzc2lhbiAoUnVzc2lhKSI7czoxMToiZGVzY3JpcHRpb24iO3M6NjA6ItCf0LXRgNC10LLQvtC0OiB3d3cuY3Jvd2Rpbi5jb20vcHJvamVjdC9zdWl0ZWNybXRyYW5zbGF0aW9ucyI7czo0OiJ0eXBlIjtzOjg6ImxhbmdwYWNrIjtzOjE2OiJpc191bmluc3RhbGxhYmxlIjtzOjM6IlllcyI7czoyNToiYWNjZXB0YWJsZV9zdWdhcl92ZXJzaW9ucyI7YTowOnt9czoyNDoiYWNjZXB0YWJsZV9zdWdhcl9mbGF2b3JzIjthOjE6e2k6MDtzOjI6IkNFIjt9czo2OiJhdXRob3IiO3M6MTg6IlN1aXRlQ1JNIENvbW11bml0eSI7czo3OiJ2ZXJzaW9uIjtzOjc6IjcuOC4zLjYiO3M6MTQ6InB1Ymxpc2hlZF9kYXRlIjtzOjEwOiIyMDE3LTA1LTA4Ijt9czoxMToiaW5zdGFsbGRlZnMiO2E6Mzp7czoyOiJpZCI7czo1OiJydV9SVSI7czo5OiJpbWFnZV9kaXIiO3M6MTc6IjxiYXNlcGF0aD4vaW1hZ2VzIjtzOjQ6ImNvcHkiO2E6Mzp7aTowO2E6Mjp7czo0OiJmcm9tIjtzOjE4OiI8YmFzZXBhdGg+L2luY2x1ZGUiO3M6MjoidG8iO3M6NzoiaW5jbHVkZSI7fWk6MTthOjI6e3M6NDoiZnJvbSI7czoxODoiPGJhc2VwYXRoPi9tb2R1bGVzIjtzOjI6InRvIjtzOjc6Im1vZHVsZXMiO31pOjI7YToyOntzOjQ6ImZyb20iO3M6MTg6IjxiYXNlcGF0aD4vaW5zdGFsbCI7czoyOiJ0byI7czo3OiJpbnN0YWxsIjt9fX1zOjE2OiJ1cGdyYWRlX21hbmlmZXN0IjtzOjA6IiI7fQ==','2017-05-24 10:55:35',1),
('67cb0767-7802-6378-0fed-5926d29a86d7','upload/upgrades/module/lp2017_05_26_154005.zip','7709905595f94d3c6d841af7532acca4','module','installed','1495802405','lp','Дополнительные параметры','lp','YTozOntzOjg6Im1hbmlmZXN0IjthOjEzOntpOjA7YToxOntzOjI1OiJhY2NlcHRhYmxlX3N1Z2FyX3ZlcnNpb25zIjthOjE6e2k6MDtzOjA6IiI7fX1pOjE7YToxOntzOjI0OiJhY2NlcHRhYmxlX3N1Z2FyX2ZsYXZvcnMiO2E6Mzp7aTowO3M6MjoiQ0UiO2k6MTtzOjM6IlBSTyI7aToyO3M6MzoiRU5UIjt9fXM6NjoicmVhZG1lIjtzOjA6IiI7czozOiJrZXkiO3M6MjoiZHAiO3M6NjoiYXV0aG9yIjtzOjQ6ImlhbXkiO3M6MTE6ImRlc2NyaXB0aW9uIjtzOjQ3OiLQlNC+0L/QvtC70L3QuNGC0LXQu9GM0L3Ri9C1INC/0LDRgNCw0LzQtdGC0YDRiyI7czo0OiJpY29uIjtzOjA6IiI7czoxNjoiaXNfdW5pbnN0YWxsYWJsZSI7YjoxO3M6NDoibmFtZSI7czoyOiJscCI7czoxNDoicHVibGlzaGVkX2RhdGUiO3M6MTk6IjIwMTctMDUtMjYgMTI6NDA6MDUiO3M6NDoidHlwZSI7czo2OiJtb2R1bGUiO3M6NzoidmVyc2lvbiI7aToxNDk1ODAyNDA1O3M6MTM6InJlbW92ZV90YWJsZXMiO3M6NjoicHJvbXB0Ijt9czoxMToiaW5zdGFsbGRlZnMiO2E6OTp7czoyOiJpZCI7czoyOiJscCI7czo1OiJiZWFucyI7YTozOntpOjA7YTo0OntzOjY6Im1vZHVsZSI7czo3OiJkcF9ia3J2IjtzOjU6ImNsYXNzIjtzOjc6ImRwX2JrcnYiO3M6NDoicGF0aCI7czoyNzoibW9kdWxlcy9kcF9ia3J2L2RwX2JrcnYucGhwIjtzOjM6InRhYiI7YjoxO31pOjE7YTo0OntzOjY6Im1vZHVsZSI7czo5OiJkcF9yZWFsdHkiO3M6NToiY2xhc3MiO3M6OToiZHBfcmVhbHR5IjtzOjQ6InBhdGgiO3M6MzE6Im1vZHVsZXMvZHBfcmVhbHR5L2RwX3JlYWx0eS5waHAiO3M6MzoidGFiIjtiOjE7fWk6MjthOjQ6e3M6NjoibW9kdWxlIjtzOjEwOiJkcF9saWNlbnNlIjtzOjU6ImNsYXNzIjtzOjEwOiJkcF9saWNlbnNlIjtzOjQ6InBhdGgiO3M6MzM6Im1vZHVsZXMvZHBfbGljZW5zZS9kcF9saWNlbnNlLnBocCI7czozOiJ0YWIiO2I6MTt9fXM6MTA6ImxheW91dGRlZnMiO2E6Mjp7aTowO2E6Mjp7czo0OiJmcm9tIjtzOjc4OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xheW91dGRlZnMvZHBfYmtydl9hY2NvdW50c19BY2NvdW50cy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjg6IkFjY291bnRzIjt9aToxO2E6Mjp7czo0OiJmcm9tIjtzOjgwOiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xheW91dGRlZnMvZHBfcmVhbHR5X2FjY291bnRzX0FjY291bnRzLnBocCI7czo5OiJ0b19tb2R1bGUiO3M6ODoiQWNjb3VudHMiO319czoxMzoicmVsYXRpb25zaGlwcyI7YToyOntpOjA7YToxOntzOjk6Im1ldGFfZGF0YSI7czo4MDoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy9yZWxhdGlvbnNoaXBzL2RwX2JrcnZfYWNjb3VudHNNZXRhRGF0YS5waHAiO31pOjE7YToxOntzOjk6Im1ldGFfZGF0YSI7czo4MjoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy9yZWxhdGlvbnNoaXBzL2RwX3JlYWx0eV9hY2NvdW50c01ldGFEYXRhLnBocCI7fX1zOjk6ImltYWdlX2RpciI7czoxNjoiPGJhc2VwYXRoPi9pY29ucyI7czo0OiJjb3B5IjthOjM6e2k6MDthOjI6e3M6NDoiZnJvbSI7czozOToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbW9kdWxlcy9kcF9ia3J2IjtzOjI6InRvIjtzOjE1OiJtb2R1bGVzL2RwX2JrcnYiO31pOjE7YToyOntzOjQ6ImZyb20iO3M6NDE6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL21vZHVsZXMvZHBfcmVhbHR5IjtzOjI6InRvIjtzOjE3OiJtb2R1bGVzL2RwX3JlYWx0eSI7fWk6MjthOjI6e3M6NDoiZnJvbSI7czo0MjoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbW9kdWxlcy9kcF9saWNlbnNlIjtzOjI6InRvIjtzOjE4OiJtb2R1bGVzL2RwX2xpY2Vuc2UiO319czo4OiJsYW5ndWFnZSI7YToxMDp7aTowO2E6Mzp7czo0OiJmcm9tIjtzOjU4OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL2RwX2JrcnYucGhwIjtzOjk6InRvX21vZHVsZSI7czo3OiJkcF9ia3J2IjtzOjg6Imxhbmd1YWdlIjtzOjU6ImVuX3VzIjt9aToxO2E6Mzp7czo0OiJmcm9tIjtzOjU4OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL2RwX2JrcnYucGhwIjtzOjk6InRvX21vZHVsZSI7czo3OiJkcF9ia3J2IjtzOjg6Imxhbmd1YWdlIjtzOjU6InJ1X1JVIjt9aToyO2E6Mzp7czo0OiJmcm9tIjtzOjU5OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL0FjY291bnRzLnBocCI7czo5OiJ0b19tb2R1bGUiO3M6ODoiQWNjb3VudHMiO3M6ODoibGFuZ3VhZ2UiO3M6NToiZW5fdXMiO31pOjM7YTozOntzOjQ6ImZyb20iO3M6NTk6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvbGFuZ3VhZ2UvQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fWk6NDthOjM6e3M6NDoiZnJvbSI7czo2MDoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy9sYW5ndWFnZS9kcF9yZWFsdHkucGhwIjtzOjk6InRvX21vZHVsZSI7czo5OiJkcF9yZWFsdHkiO3M6ODoibGFuZ3VhZ2UiO3M6NToiZW5fdXMiO31pOjU7YTozOntzOjQ6ImZyb20iO3M6NjA6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvbGFuZ3VhZ2UvZHBfcmVhbHR5LnBocCI7czo5OiJ0b19tb2R1bGUiO3M6OToiZHBfcmVhbHR5IjtzOjg6Imxhbmd1YWdlIjtzOjU6InJ1X1JVIjt9aTo2O2E6Mzp7czo0OiJmcm9tIjtzOjU5OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL0FjY291bnRzLnBocCI7czo5OiJ0b19tb2R1bGUiO3M6ODoiQWNjb3VudHMiO3M6ODoibGFuZ3VhZ2UiO3M6NToiZW5fdXMiO31pOjc7YTozOntzOjQ6ImZyb20iO3M6NTk6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvbGFuZ3VhZ2UvQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fWk6ODthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vZW5fdXMubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJlbl91cyI7fWk6OTthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vcnVfUlUubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fX1zOjc6InZhcmRlZnMiO2E6NDp7aTowO2E6Mjp7czo0OiJmcm9tIjtzOjc0OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL3ZhcmRlZnMvZHBfYmtydl9hY2NvdW50c19kcF9ia3J2LnBocCI7czo5OiJ0b19tb2R1bGUiO3M6NzoiZHBfYmtydiI7fWk6MTthOjI6e3M6NDoiZnJvbSI7czo3NToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy92YXJkZWZzL2RwX2JrcnZfYWNjb3VudHNfQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7fWk6MjthOjI6e3M6NDoiZnJvbSI7czo3ODoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy92YXJkZWZzL2RwX3JlYWx0eV9hY2NvdW50c19kcF9yZWFsdHkucGhwIjtzOjk6InRvX21vZHVsZSI7czo5OiJkcF9yZWFsdHkiO31pOjM7YToyOntzOjQ6ImZyb20iO3M6Nzc6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvdmFyZGVmcy9kcF9yZWFsdHlfYWNjb3VudHNfQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7fX1zOjEyOiJsYXlvdXRmaWVsZHMiO2E6Mjp7aTowO2E6MTp7czoxNzoiYWRkaXRpb25hbF9maWVsZHMiO2E6MDp7fX1pOjE7YToxOntzOjE3OiJhZGRpdGlvbmFsX2ZpZWxkcyI7YTowOnt9fX19czoxNjoidXBncmFkZV9tYW5pZmVzdCI7czowOiIiO30=','2017-05-25 12:46:45',1),
('d3eb6ab5-2acd-b923-651c-592b08293fdc','upload/upgrades/module/sro2017_05_28_202219.zip','662ed9e49383d17e08ae7c69998251a9','module','installed','1495992139','sro','','sro','YTozOntzOjg6Im1hbmlmZXN0IjthOjEzOntpOjA7YToxOntzOjI1OiJhY2NlcHRhYmxlX3N1Z2FyX3ZlcnNpb25zIjthOjE6e2k6MDtzOjA6IiI7fX1pOjE7YToxOntzOjI0OiJhY2NlcHRhYmxlX3N1Z2FyX2ZsYXZvcnMiO2E6Mzp7aTowO3M6MjoiQ0UiO2k6MTtzOjM6IlBSTyI7aToyO3M6MzoiRU5UIjt9fXM6NjoicmVhZG1lIjtzOjA6IiI7czozOiJrZXkiO3M6Mzoic3JvIjtzOjY6ImF1dGhvciI7czowOiIiO3M6MTE6ImRlc2NyaXB0aW9uIjtzOjA6IiI7czo0OiJpY29uIjtzOjA6IiI7czoxNjoiaXNfdW5pbnN0YWxsYWJsZSI7YjoxO3M6NDoibmFtZSI7czozOiJzcm8iO3M6MTQ6InB1Ymxpc2hlZF9kYXRlIjtzOjE5OiIyMDE3LTA1LTI4IDE3OjIyOjE5IjtzOjQ6InR5cGUiO3M6NjoibW9kdWxlIjtzOjc6InZlcnNpb24iO2k6MTQ5NTk5MjEzOTtzOjEzOiJyZW1vdmVfdGFibGVzIjtzOjY6InByb21wdCI7fXM6MTE6Imluc3RhbGxkZWZzIjthOjc6e3M6MjoiaWQiO3M6Mzoic3JvIjtzOjU6ImJlYW5zIjthOjE6e2k6MDthOjQ6e3M6NjoibW9kdWxlIjtzOjEyOiJzcm9fc3ZpZF9zcm8iO3M6NToiY2xhc3MiO3M6MTI6InNyb19zdmlkX3NybyI7czo0OiJwYXRoIjtzOjM3OiJtb2R1bGVzL3Nyb19zdmlkX3Nyby9zcm9fc3ZpZF9zcm8ucGhwIjtzOjM6InRhYiI7YjoxO319czoxMDoibGF5b3V0ZGVmcyI7YTowOnt9czoxMzoicmVsYXRpb25zaGlwcyI7YTowOnt9czo5OiJpbWFnZV9kaXIiO3M6MTY6IjxiYXNlcGF0aD4vaWNvbnMiO3M6NDoiY29weSI7YToxOntpOjA7YToyOntzOjQ6ImZyb20iO3M6NDQ6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL21vZHVsZXMvc3JvX3N2aWRfc3JvIjtzOjI6InRvIjtzOjIwOiJtb2R1bGVzL3Nyb19zdmlkX3NybyI7fX1zOjg6Imxhbmd1YWdlIjthOjI6e2k6MDthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vZW5fdXMubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJlbl91cyI7fWk6MTthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vcnVfUlUubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fX19czoxNjoidXBncmFkZV9tYW5pZmVzdCI7czowOiIiO30=','2017-05-28 17:26:32',1)	;
#	TC`user_preferences`utf8_general_ci	;
CREATE TABLE `user_preferences` (
  `id` char(36) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `contents` longtext,
  PRIMARY KEY (`id`),
  KEY `idx_userprefnamecat` (`assigned_user_id`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`user_preferences`utf8_general_ci	;
INSERT INTO `user_preferences` VALUES 
('14906690-13e2-b525-a51d-59272d6decb3','dp_realty2_DP_REALTY',0,'2017-05-25 19:15:37','2017-05-25 19:15:37','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('27b10dc0-6fbe-4225-2009-5926d49d7ee5','Prospects2_PROSPECT',0,'2017-05-25 12:56:54','2017-05-25 12:56:54','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('30e0011c-a1f1-744f-081f-59282451af06','dp_license2_DP_LICENSE',0,'2017-05-26 12:52:02','2017-05-26 12:52:02','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('3a860cbc-57dc-302a-d9d3-59256e040e17','Project2_PROJECT',0,'2017-05-24 11:28:38','2017-05-24 11:28:38','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('3e12fe37-dff6-6e50-bc30-592568798c55','Contacts2_CONTACT',0,'2017-05-24 11:02:44','2017-05-24 11:02:44','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('450f3f0d-e413-d1a1-dbfa-59256d454f66','Employees2_EMPLOYEE',0,'2017-05-24 11:24:34','2017-05-24 11:24:34','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('499af557-58e4-bc64-e614-59256e6c09fe','Campaigns2_CAMPAIGN',0,'2017-05-24 11:28:10','2017-05-24 11:28:10','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('59487d1e-21ee-04e2-56a8-5925657dc335','Home',0,'2017-05-24 10:52:17','2017-05-28 17:31:38','1','YToyOntzOjg6ImRhc2hsZXRzIjthOjY6e3M6MzY6IjE4YTliNmMwLTk5NTYtNGVkMy05N2NlLTU5MjU2NTI3ZjA0YyI7YTo0OntzOjk6ImNsYXNzTmFtZSI7czoxNjoiU3VnYXJGZWVkRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6OToiU3VnYXJGZWVkIjtzOjExOiJmb3JjZUNvbHVtbiI7aToxO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo2NDoibW9kdWxlcy9TdWdhckZlZWQvRGFzaGxldHMvU3VnYXJGZWVkRGFzaGxldC9TdWdhckZlZWREYXNobGV0LnBocCI7fXM6MzY6IjE5MjJjYzEyLWEwNmUtNjYyNy00MGQ1LTU5MjU2NTYxNTQ4ZSI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoxNDoiTXlDYWxsc0Rhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjU6IkNhbGxzIjtzOjExOiJmb3JjZUNvbHVtbiI7aTowO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo1NjoibW9kdWxlcy9DYWxscy9EYXNobGV0cy9NeUNhbGxzRGFzaGxldC9NeUNhbGxzRGFzaGxldC5waHAiO3M6Nzoib3B0aW9ucyI7YTowOnt9fXM6MzY6IjE5YWRiZTJiLTg0ZmUtM2RlNS1mNzU1LTU5MjU2NWQ0ZDhmNCI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoxNzoiTXlNZWV0aW5nc0Rhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjg6Ik1lZXRpbmdzIjtzOjExOiJmb3JjZUNvbHVtbiI7aTowO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo2NToibW9kdWxlcy9NZWV0aW5ncy9EYXNobGV0cy9NeU1lZXRpbmdzRGFzaGxldC9NeU1lZXRpbmdzRGFzaGxldC5waHAiO3M6Nzoib3B0aW9ucyI7YTowOnt9fXM6MzY6IjE5ZjdlN2Q2LWZiNDItZGI2NS1iOTllLTU5MjU2NTRjZTcxNCI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoyMjoiTXlPcHBvcnR1bml0aWVzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6MTM6Ik9wcG9ydHVuaXRpZXMiO3M6MTE6ImZvcmNlQ29sdW1uIjtpOjA7czoxMjoiZmlsZUxvY2F0aW9uIjtzOjgwOiJtb2R1bGVzL09wcG9ydHVuaXRpZXMvRGFzaGxldHMvTXlPcHBvcnR1bml0aWVzRGFzaGxldC9NeU9wcG9ydHVuaXRpZXNEYXNobGV0LnBocCI7czo3OiJvcHRpb25zIjthOjA6e319czozNjoiMWE1ZjhkM2UtMjA2NC05NTkzLTdlNTItNTkyNTY1MWY3N2I1IjthOjU6e3M6OToiY2xhc3NOYW1lIjtzOjE3OiJNeUFjY291bnRzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6ODoiQWNjb3VudHMiO3M6MTE6ImZvcmNlQ29sdW1uIjtpOjA7czoxMjoiZmlsZUxvY2F0aW9uIjtzOjY1OiJtb2R1bGVzL0FjY291bnRzL0Rhc2hsZXRzL015QWNjb3VudHNEYXNobGV0L015QWNjb3VudHNEYXNobGV0LnBocCI7czo3OiJvcHRpb25zIjthOjA6e319czozNjoiMWFjY2IwYjctYzgyMS01NDZiLWY2ZTUtNTkyNTY1ZGM0YTI0IjthOjU6e3M6OToiY2xhc3NOYW1lIjtzOjE0OiJNeUxlYWRzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6NToiTGVhZHMiO3M6MTE6ImZvcmNlQ29sdW1uIjtpOjA7czoxMjoiZmlsZUxvY2F0aW9uIjtzOjU2OiJtb2R1bGVzL0xlYWRzL0Rhc2hsZXRzL015TGVhZHNEYXNobGV0L015TGVhZHNEYXNobGV0LnBocCI7czo3OiJvcHRpb25zIjthOjA6e319fXM6NToicGFnZXMiO2E6MTp7aTowO2E6Mzp7czo3OiJjb2x1bW5zIjthOjI6e2k6MDthOjI6e3M6NToid2lkdGgiO3M6MzoiNjAlIjtzOjg6ImRhc2hsZXRzIjthOjU6e2k6MDtzOjM2OiIxYTVmOGQzZS0yMDY0LTk1OTMtN2U1Mi01OTI1NjUxZjc3YjUiO2k6MTtzOjM2OiIxOTIyY2MxMi1hMDZlLTY2MjctNDBkNS01OTI1NjU2MTU0OGUiO2k6MjtzOjM2OiIxOWFkYmUyYi04NGZlLTNkZTUtZjc1NS01OTI1NjVkNGQ4ZjQiO2k6MztzOjM2OiIxOWY3ZTdkNi1mYjQyLWRiNjUtYjk5ZS01OTI1NjU0Y2U3MTQiO2k6NDtzOjM2OiIxYWNjYjBiNy1jODIxLTU0NmItZjZlNS01OTI1NjVkYzRhMjQiO319aToxO2E6Mjp7czo1OiJ3aWR0aCI7czozOiI0MCUiO3M6ODoiZGFzaGxldHMiO2E6MTp7aTowO3M6MzY6IjE4YTliNmMwLTk5NTYtNGVkMy05N2NlLTU5MjU2NTI3ZjA0YyI7fX19czoxMDoibnVtQ29sdW1ucyI7czoxOiIzIjtzOjE0OiJwYWdlVGl0bGVMYWJlbCI7czoyMDoiTEJMX0hPTUVfUEFHRV8xX05BTUUiO319fQ=='),
('5b917778-bd89-90a5-be3b-5926d401874e','FP_Event_Locations2_FP_EVENT_LOCATIONS',0,'2017-05-25 12:57:40','2017-05-25 12:57:40','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('5d41d5f1-21c5-a576-372d-592565ade681','Home2_CALL',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6009eec0-f7eb-18e1-5a56-592565bb469a','Home2_MEETING',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6295b8a3-4af7-8ccb-e8a3-592565c5ecb4','Home2_OPPORTUNITY',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('65300a0a-e81c-49f5-0259-59256ee16f85','AOW_WorkFlow2_AOW_WORKFLOW',0,'2017-05-24 11:28:59','2017-05-24 11:28:59','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('65cc5abf-0361-9dd8-eed1-592565d2c010','Home2_ACCOUNT',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6831b2ff-a382-cdf9-df7a-5925655f906c','Home2_LEAD',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6a97551f-9d31-1c94-73b0-5925658141c4','Home2_SUGARFEED',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('775ed48c-4659-e55d-9beb-59256767ae98','Accounts2_ACCOUNT',0,'2017-05-24 11:00:14','2017-05-24 11:00:14','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('9c608ae9-c86f-6682-09d8-592564d88a8f','global',0,'2017-05-24 10:47:24','2017-05-28 17:37:49','1','YTo0NDp7czoyMDoiY2FsZW5kYXJfcHVibGlzaF9rZXkiO3M6MzY6IjljMmNmYzg0LWRlNDktOThmOS04ZGQ2LTU5MjU2NDJlMTk4OSI7czo4OiJ0aW1lem9uZSI7czoxMzoiRXVyb3BlL01vc2NvdyI7czoxMjoibWFpbG1lcmdlX29uIjtzOjI6Im9uIjtzOjE2OiJzd2FwX2xhc3Rfdmlld2VkIjtzOjA6IiI7czoxNDoic3dhcF9zaG9ydGN1dHMiO3M6MDoiIjtzOjE5OiJuYXZpZ2F0aW9uX3BhcmFkaWdtIjtzOjI6ImdtIjtzOjEzOiJzdWJwYW5lbF90YWJzIjtzOjA6IiI7czoxMDoidXNlcl90aGVtZSI7czo2OiJTdWl0ZVIiO3M6MTQ6Im1vZHVsZV9mYXZpY29uIjtzOjA6IiI7czo5OiJoaWRlX3RhYnMiO2E6MDp7fXM6MTE6InJlbW92ZV90YWJzIjthOjA6e31zOjc6Im5vX29wcHMiO3M6Mzoib2ZmIjtzOjEzOiJyZW1pbmRlcl90aW1lIjtpOjE4MDA7czoxOToiZW1haWxfcmVtaW5kZXJfdGltZSI7aTozNjAwO3M6MTY6InJlbWluZGVyX2NoZWNrZWQiO3M6MToiMSI7czoyMjoiZW1haWxfcmVtaW5kZXJfY2hlY2tlZCI7TjtzOjI6InV0IjtzOjE6IjEiO3M6NToiZGF0ZWYiO3M6NToibS9kL1kiO3M6MTU6Im1haWxfc210cHNlcnZlciI7czowOiIiO3M6MTM6Im1haWxfc210cHBvcnQiO3M6MjoiMjUiO3M6MTM6Im1haWxfc210cHVzZXIiO3M6MDoiIjtzOjEzOiJtYWlsX3NtdHBwYXNzIjtzOjA6IiI7czoyNjoiZGVmYXVsdF9sb2NhbGVfbmFtZV9mb3JtYXQiO3M6NToicyBmIGwiO3M6MTY6ImV4cG9ydF9kZWxpbWl0ZXIiO3M6MToiLCI7czoyMjoiZGVmYXVsdF9leHBvcnRfY2hhcnNldCI7czo1OiJVVEYtOCI7czoxNDoidXNlX3JlYWxfbmFtZXMiO3M6Mjoib24iO3M6MTc6Im1haWxfc210cGF1dGhfcmVxIjtzOjE6IjEiO3M6MTI6Im1haWxfc210cHNzbCI7aToxO3M6MTc6ImVtYWlsX3Nob3dfY291bnRzIjtpOjA7czoyMToiZGVmYXVsdF9lbWFpbF9jaGFyc2V0IjtzOjU6IlVURi04IjtzOjE5OiJ0aGVtZV9jdXJyZW50X2dyb3VwIjtzOjY6ItCS0YHQtSI7czo5OiJBY2NvdW50c1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxNToiYWR2YW5jZWRfc2VhcmNoIjt9czo5OiJDb250YWN0c1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMDoiRW1wbG95ZWVzUSI7YTo0OntzOjY6Im1vZHVsZSI7czo5OiJFbXBsb3llZXMiO3M6NjoiYWN0aW9uIjtzOjU6ImluZGV4IjtzOjU6InF1ZXJ5IjtzOjQ6InRydWUiO3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6MTA6IkNhbXBhaWduc1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czo4OiJQcm9qZWN0USI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjEzOiJBT1dfV29ya0Zsb3dRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6NjoiVGFza3NRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6ODoiZHBfYmtydlEiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMDoiUHJvc3BlY3RzUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjE5OiJGUF9FdmVudF9Mb2NhdGlvbnNRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6MTA6ImRwX3JlYWx0eVEiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMToiZHBfbGljZW5zZVEiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMzoic3JvX3N2aWRfc3JvUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO319'),
('b205e08a-ff6b-4093-e437-592564bca40d','ETag',0,'2017-05-24 10:47:24','2017-05-28 17:26:32','1','YToxOntzOjEyOiJtYWluTWVudUVUYWciO2k6MTM7fQ=='),
('b39dab77-91f1-94ec-bac4-592b0a25f993','sro_svid_sro2_SRO_SVID_SRO',0,'2017-05-28 17:37:49','2017-05-28 17:37:49','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('dc22c045-21f4-83c7-e553-5926d2945207','dp_bkrv2_DP_BKRV',0,'2017-05-25 12:47:04','2017-05-25 12:47:04','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('dd379fae-d419-840b-d1c7-592567f5da71','Home2_LEAD_1accb0b7-c821-546b-f6e5-592565dc4a24',0,'2017-05-24 10:57:12','2017-05-24 10:57:12','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ==')	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  `user_hash` varchar(255) DEFAULT NULL,
  `system_generated_password` tinyint(1) DEFAULT NULL,
  `pwd_last_changed` datetime DEFAULT NULL,
  `authenticate_id` varchar(100) DEFAULT NULL,
  `sugar_login` tinyint(1) DEFAULT '1',
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `external_auth_only` tinyint(1) DEFAULT '0',
  `receive_notifications` tinyint(1) DEFAULT '1',
  `description` text,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `phone_home` varchar(50) DEFAULT NULL,
  `phone_mobile` varchar(50) DEFAULT NULL,
  `phone_work` varchar(50) DEFAULT NULL,
  `phone_other` varchar(50) DEFAULT NULL,
  `phone_fax` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `address_street` varchar(150) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `address_postalcode` varchar(20) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `portal_only` tinyint(1) DEFAULT '0',
  `show_on_employees` tinyint(1) DEFAULT '1',
  `employee_status` varchar(100) DEFAULT NULL,
  `messenger_id` varchar(100) DEFAULT NULL,
  `messenger_type` varchar(100) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `is_group` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_name` (`user_name`,`is_group`,`status`,`last_name`,`first_name`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
('1','admin','$1$Wbv7KmQO$UUr8Z6wWsFI29T64hcOiL1',0,\N,\N,1,\N,'Administrator',1,0,1,\N,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','','Administrator',\N,\N,\N,\N,\N,\N,\N,'Active',\N,\N,\N,\N,\N,0,0,1,'Active',\N,\N,'',0)	;
#	TC`users_feeds`utf8_general_ci	;
CREATE TABLE `users_feeds` (
  `user_id` varchar(36) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  KEY `idx_ud_user_id` (`user_id`,`feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`users_last_import`utf8_general_ci	;
CREATE TABLE `users_last_import` (
  `id` char(36) NOT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `import_module` varchar(36) DEFAULT NULL,
  `bean_type` varchar(36) DEFAULT NULL,
  `bean_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`users_password_link`utf8_general_ci	;
CREATE TABLE `users_password_link` (
  `id` char(36) NOT NULL,
  `username` varchar(36) DEFAULT NULL,
  `date_generated` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`users_signatures`utf8_general_ci	;
CREATE TABLE `users_signatures` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `signature` text,
  `signature_html` text,
  PRIMARY KEY (`id`),
  KEY `idx_usersig_uid` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`vcals`utf8_general_ci	;
CREATE TABLE `vcals` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `idx_vcal` (`type`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
