#SXD20|20011|50552|50630|2017.05.31 16:03:11|auser|0|227|1052|
#TA accounts`3`16384|accounts_audit`2`16384|accounts_bugs`0`16384|accounts_cases`0`16384|accounts_contacts`1`16384|accounts_contacts_1_c`0`16384|accounts_cstm`3`16384|accounts_opportunities`0`16384|acl_actions`447`147456|acl_roles`0`16384|acl_roles_actions`0`16384|acl_roles_users`0`16384|address_book`0`16384|alerts`0`16384|am_projecttemplates`0`16384|am_projecttemplates_audit`0`16384|am_projecttemplates_contacts_1_c`0`16384|am_projecttemplates_project_1_c`0`16384|am_projecttemplates_users_1_c`0`16384|am_tasktemplates`0`16384|am_tasktemplates_am_projecttemplates_c`0`16384|am_tasktemplates_audit`0`16384|aobh_businesshours`0`16384|aod_index`1`16384|aod_index_audit`0`16384|aod_indexevent`12`16384|aod_indexevent_audit`0`16384|aok_knowledge_base_categories`0`16384|aok_knowledge_base_categories_audit`0`16384|aok_knowledgebase`0`16384|aok_knowledgebase_audit`0`16384|aok_knowledgebase_categories`0`16384|aop_case_events`0`16384|aop_case_events_audit`0`16384|aop_case_updates`0`16384|aop_case_updates_audit`0`16384|aor_charts`0`16384|aor_conditions`0`16384|aor_fields`0`16384|aor_reports`0`16384|aor_reports_audit`0`16384|aor_scheduled_reports`0`16384|aos_contracts`0`16384|aos_contracts_audit`0`16384|aos_contracts_documents`0`16384|aos_invoices`0`16384|aos_invoices_audit`0`16384|aos_line_item_groups`0`16384|aos_line_item_groups_audit`0`16384|aos_pdf_templates`1`81920|aos_pdf_templates_audit`1`16384|aos_product_categories`0`16384|aos_product_categories_audit`0`16384|aos_products`0`16384|aos_products_audit`0`16384|aos_products_quotes`0`16384|aos_products_quotes_audit`0`16384|aos_quotes`0`16384|aos_quotes_aos_invoices_c`0`16384|aos_quotes_audit`0`16384|aos_quotes_os_contracts_c`0`16384|aos_quotes_project_c`0`16384|aow_actions`0`16384|aow_conditions`0`16384|aow_processed`0`16384|aow_processed_aow_actions`0`16384|aow_workflow`0`16384|aow_workflow_audit`0`16384|bugs`0`16384|bugs_audit`0`16384|calls`0`16384|calls_contacts`0`16384|calls_leads`0`16384|calls_reschedule`0`16384|calls_reschedule_audit`0`16384|calls_users`0`16384|campaign_log`0`16384|campaign_trkrs`0`16384|campaigns`0`16384|campaigns_audit`0`16384|cases`0`16384|cases_audit`0`16384|cases_bugs`0`16384|cases_cstm`0`16384|config`20`16384|contacts`3`16384|contacts_audit`0`16384|contacts_bugs`0`16384|contacts_cases`0`16384|contacts_cstm`3`16384|contacts_users`0`16384|cron_remove_documents`0`16384|currencies`0`16384|custom_fields`0`16384|document_revisions`0`16384|documents`0`16384|documents_accounts`0`16384|documents_bugs`0`16384|documents_cases`0`16384|documents_contacts`0`16384|documents_opportunities`0`16384|dp_bkrv`1`16384|dp_bkrv_accounts_c`1`16384|dp_bkrv_audit`0`16384|dp_founder_fl`1`16384|dp_founder_fl_audit`0`16384|dp_founder_fl_contacts_1_c`1`16384|dp_founder_fl_cstm`1`16384|dp_founder_ul`0`16384|dp_founder_ul_accounts_1_c`0`16384|dp_founder_ul_audit`0`16384|dp_founder_ul_cstm`0`16384|dp_license`0`16384|dp_license_audit`0`16384|dp_license_cstm`0`16384|dp_realty`1`16384|dp_realty_accounts_c`1`16384|dp_realty_audit`0`16384|eapm`0`16384|email_addr_bean_rel`3`16384|email_addresses`2`16384|email_cache`0`16384|email_marketing`0`16384|email_marketing_prospect_lists`0`16384|email_templates`8`16384|emailman`0`16384|emails`0`16384|emails_beans`0`16384|emails_email_addr_rel`0`16384|emails_text`0`0|favorites`0`16384|fields_meta_data`55`16384|folders`0`16384|folders_rel`0`16384|folders_subscriptions`0`16384|fp_event_locations`0`16384|fp_event_locations_audit`0`16384|fp_event_locations_fp_events_1_c`0`16384|fp_events`0`16384|fp_events_audit`0`16384|fp_events_contacts_c`0`16384|fp_events_fp_event_delegates_1_c`0`16384|fp_events_fp_event_locations_1_c`0`16384|fp_events_leads_1_c`0`16384|fp_events_prospects_1_c`0`16384|import_maps`0`16384|inbound_email`0`16384|inbound_email_autoreply`0`16384|inbound_email_cache_ts`0`16384|jjwg_address_cache`0`16384|jjwg_address_cache_audit`0`16384|jjwg_areas`0`16384|jjwg_areas_audit`0`16384|jjwg_maps`0`16384|jjwg_maps_audit`0`16384|jjwg_maps_jjwg_areas_c`0`16384|jjwg_maps_jjwg_markers_c`0`16384|jjwg_markers`0`16384|jjwg_markers_audit`0`16384|job_queue`0`16384|leads`0`16384|leads_audit`0`16384|leads_cstm`0`16384|linked_documents`0`16384|meetings`0`16384|meetings_contacts`0`16384|meetings_cstm`0`16384|meetings_leads`0`16384|meetings_users`0`16384|notes`3`16384|oauth_consumer`0`16384|oauth_nonce`0`16384|oauth_tokens`0`16384|opportunities`0`16384|opportunities_audit`0`16384|opportunities_contacts`0`16384|opportunities_cstm`0`16384|outbound_email`1`16384|outbound_email_audit`0`16384|project`0`16384|project_contacts_1_c`0`16384|project_cstm`0`16384|project_task`0`16384|project_task_audit`0`16384|project_users_1_c`0`16384|projects_accounts`0`16384|projects_bugs`0`16384|projects_cases`0`16384|projects_contacts`0`16384|projects_opportunities`0`16384|projects_products`0`16384|prospect_list_campaigns`0`16384|prospect_lists`0`16384|prospect_lists_prospects`0`16384|prospects`0`16384|prospects_cstm`0`16384|relationships`419`163840|releases`0`16384|reminders`0`16384|reminders_invitees`0`16384|roles`0`16384|roles_modules`0`16384|roles_users`0`16384|saved_search`0`16384|schedulers`13`16384|securitygroups`0`16384|securitygroups_acl_roles`0`16384|securitygroups_audit`0`16384|securitygroups_default`0`16384|securitygroups_records`0`16384|securitygroups_users`0`16384|spots`0`16384|sro_svid_sro`0`16384|sro_svid_sro_audit`0`16384|sro_svid_sro_cstm`0`16384|sugarfeed`3`16384|tasks`0`16384|templatesectionline`0`16384|tracker`10`16384|upgrade_history`4`16384|user_preferences`26`16384|users`1`16384|users_feeds`0`16384|users_last_import`0`16384|users_password_link`0`16384|users_signatures`0`16384|vcals`0`16384
#EOH

#	TC`accounts`utf8_general_ci	;
CREATE TABLE `accounts` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `industry` varchar(50) DEFAULT NULL,
  `annual_revenue` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `rating` varchar(100) DEFAULT NULL,
  `phone_office` varchar(100) DEFAULT NULL,
  `phone_alternate` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `ownership` varchar(100) DEFAULT NULL,
  `employees` varchar(10) DEFAULT NULL,
  `ticker_symbol` varchar(10) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `sic_code` varchar(255) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `shname` varchar(255) DEFAULT NULL,
  `inn` varchar(12) DEFAULT NULL,
  `kpp` varchar(9) DEFAULT NULL,
  `resident` varchar(255) DEFAULT 'Да',
  `okpo` varchar(8) DEFAULT NULL,
  `ogrn` varchar(15) DEFAULT NULL,
  `okopf` varchar(10) DEFAULT NULL,
  `okogu` varchar(7) DEFAULT NULL,
  `okfs` varchar(20) DEFAULT NULL,
  `date_ifns` date DEFAULT NULL,
  `nm_regorgan` varchar(150) DEFAULT NULL,
  `date_gosreg` date DEFAULT NULL,
  `nm_gosreg` varchar(150) DEFAULT NULL,
  `ur_locality` varchar(150) DEFAULT NULL,
  `ur_area` varchar(150) DEFAULT NULL,
  `ur_house` varchar(10) DEFAULT NULL,
  `ur_structure` varchar(10) DEFAULT NULL,
  `ur_apartment` varchar(10) DEFAULT NULL,
  `ur_area_fact` varchar(150) DEFAULT NULL,
  `ur_locality_fact` varchar(150) DEFAULT NULL,
  `ur_house_fact` varchar(10) DEFAULT NULL,
  `ur_structure_fact` varchar(10) DEFAULT NULL,
  `ur_apartment_fact` varchar(10) DEFAULT NULL,
  `oktmo_fact` varchar(11) DEFAULT NULL,
  `oktmo_ur` varchar(11) DEFAULT NULL,
  `date_reg_ustav` date DEFAULT NULL,
  `authorized_share_capital` varchar(10) DEFAULT NULL,
  `paid_share_capital` varchar(10) DEFAULT NULL,
  `region_activity` varchar(255) DEFAULT NULL,
  `eio_position_fl` varchar(80) DEFAULT NULL,
  `eio_appointment_date_fl` date DEFAULT NULL,
  `eio_total_length_service_fl` varchar(255) DEFAULT NULL,
  `gbuh_position_fl` varchar(80) DEFAULT NULL,
  `gbuh_appointment_date_fl` date DEFAULT NULL,
  `gbuh_total_length_service_fl` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accnt_id_del` (`id`,`deleted`),
  KEY `idx_accnt_name_del` (`name`,`deleted`),
  KEY `idx_accnt_assigned_del` (`deleted`,`assigned_user_id`),
  KEY `idx_accnt_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts`utf8_general_ci	;
INSERT INTO `accounts` VALUES 
('2a8faeef-e265-daa3-6127-592bdec3ef7b','Общество с ограниченной ответственностью «Аста»','2017-05-29 08:41:04','2017-05-29 11:53:57','1','1',\N,0,'1',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,'http://',\N,\N,\N,\N,\N,\N,\N,\N,'',\N,'','ООО «Аста»','6311118863','631201001','Да','62477190','1106311000124',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
('b9f49b4f-21dc-4a20-5646-592571b11c40','Общество с ограниченной ответственностью «Солнечная долина»','2017-05-24 11:42:01','2017-05-29 08:15:21','1','1',\N,0,'1',\N,\N,\N,\N,'Студеный овраг, просека 10','Самара',\N,'443031','Российская Федерация',\N,\N,\N,'http://ksil.ru/',\N,'30',\N,'Ново-Садовая','Самара',\N,'443068','Российская Федерация','','47.64 Торговля розничная спортивным оборудованием и спортивными товарами в специализированных магазинах','','ООО «Солнечная долина»','6318123326','631201001','Да','21121044','1026301511708','12300','4210014','16','2011-11-10','Инспекция Федеральной налоговой службы по Кировскому району г. Самары','2002-01-16','Инспекция Федеральной налоговой службы по Кировскому району г. Самары',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N),
('f1c17d43-b29f-16ef-5774-5927e6b4501a','Общество с ограниченной ответственностью «Эффективные технологии»','2017-05-26 08:26:48','2017-05-29 12:27:50','1','1',\N,0,'1',\N,\N,\N,\N,'Ташкентская, 171Г','Самара','Самарская область','443122','Россия',\N,\N,\N,'https://fksrf.pro',\N,\N,\N,'Ташкентская, 171Г','Самара','Самарская область','443122','Россия','',\N,'','ООО «Эффективные технологии»','6324003370','631201001','Да','62450630','1096324003093',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N)	;
#	TC`accounts_audit`utf8_general_ci	;
CREATE TABLE `accounts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts_audit`utf8_general_ci	;
INSERT INTO `accounts_audit` VALUES 
('a27e54d1-6ca6-f793-5fa1-5926b3cec92d','b9f49b4f-21dc-4a20-5646-592571b11c40','2017-05-25 10:35:28','1','inn','varchar',\N,'6318123326',\N,\N),
('a3a1a28d-fc51-f6b2-2f2e-5926b3573a3d','b9f49b4f-21dc-4a20-5646-592571b11c40','2017-05-25 10:35:28','1','kpp','varchar',\N,'631201001',\N,\N)	;
#	TC`accounts_bugs`utf8_general_ci	;
CREATE TABLE `accounts_bugs` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acc_bug_acc` (`account_id`),
  KEY `idx_acc_bug_bug` (`bug_id`),
  KEY `idx_account_bug` (`account_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`accounts_cases`utf8_general_ci	;
CREATE TABLE `accounts_cases` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acc_case_acc` (`account_id`),
  KEY `idx_acc_acc_case` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`accounts_contacts`utf8_general_ci	;
CREATE TABLE `accounts_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_account_contact` (`account_id`,`contact_id`),
  KEY `idx_contid_del_accid` (`contact_id`,`deleted`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts_contacts`utf8_general_ci	;
INSERT INTO `accounts_contacts` VALUES 
('c813f409-47e8-0d6c-dac8-5927e651e1ab','e41e39af-5bdc-0b83-c659-5927e5a9adf7','b9f49b4f-21dc-4a20-5646-592571b11c40','2017-05-29 04:39:59',0)	;
#	TC`accounts_contacts_1_c`utf8_general_ci	;
CREATE TABLE `accounts_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `accounts_contacts_1accounts_ida` varchar(36) DEFAULT NULL,
  `accounts_contacts_1contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_contacts_1_ida1` (`accounts_contacts_1accounts_ida`),
  KEY `accounts_contacts_1_idb2` (`accounts_contacts_1contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`accounts_cstm`utf8_general_ci	;
CREATE TABLE `accounts_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  `contact_id_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`accounts_cstm`utf8_general_ci	;
INSERT INTO `accounts_cstm` VALUES 
('2a8faeef-e265-daa3-6127-592bdec3ef7b',0.00000000,0.00000000,'','',''),
('b9f49b4f-21dc-4a20-5646-592571b11c40',0.00000000,0.00000000,'','',''),
('f1c17d43-b29f-16ef-5774-5927e6b4501a',0.00000000,0.00000000,'','','')	;
#	TC`accounts_opportunities`utf8_general_ci	;
CREATE TABLE `accounts_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_account_opportunity` (`account_id`,`opportunity_id`),
  KEY `idx_oppid_del_accid` (`opportunity_id`,`deleted`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`acl_actions`utf8_general_ci	;
CREATE TABLE `acl_actions` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `acltype` varchar(100) DEFAULT NULL,
  `aclaccess` int(3) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aclaction_id_del` (`id`,`deleted`),
  KEY `idx_category_name` (`category`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`acl_actions`utf8_general_ci	;
INSERT INTO `acl_actions` VALUES 
('10a80e96-b098-6601-8379-59256453825f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOK_KnowledgeBase','module',90,0),
('1136eacd-c082-6b79-6b1f-59256429d460','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Alerts','module',90,0),
('11d9e0c1-fcf1-816e-1e18-592564720589','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOW_Processed','module',90,0),
('11f625c9-e3e2-e001-4b25-592564854749','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOK_KnowledgeBase','module',90,0),
('126232fb-5c60-0894-c06d-5925647f355f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Contracts','module',90,0),
('129a67f8-cb5e-f63f-be52-5925643b6da1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','TemplateSectionLine','module',89,0),
('129ce679-2ebd-47a8-1484-592564b68dab','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Alerts','module',90,0),
('13681532-b7e0-2ca3-e4a5-59256443d40a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOK_KnowledgeBase','module',90,0),
('13ed1d0b-3245-032e-a4fc-592564c56a26','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOW_Processed','module',90,0),
('13fc03ef-e460-576b-61b4-59256446a200','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Contracts','module',90,0),
('144aaa60-c9ff-1431-1285-592564b9b4dc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','TemplateSectionLine','module',90,0),
('14d325f7-8913-0a80-9927-592564d1fa37','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOK_KnowledgeBase','module',90,0),
('1559f2e0-63fe-2f49-6d82-5925640b597d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Contracts','module',90,0),
('15c0aaec-03e8-2455-e599-592564e6156f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','TemplateSectionLine','module',90,0),
('15c908f8-567c-ed28-ecad-5925640d9e0e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Contacts','module',90,0),
('1611060c-a47a-f918-36da-592564c35afa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOK_Knowledge_Base_Categories','module',90,0),
('1618c853-de1c-ce4b-6a2b-592564298f2d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOK_KnowledgeBase','module',90,0),
('16771a55-95aa-2c2c-fb2d-592564be78f5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOW_Processed','module',90,0),
('1736716a-e954-4f01-f2de-5925645a97ac','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Contracts','module',90,0),
('176379f9-8df8-6d6b-044c-59256442115a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','TemplateSectionLine','module',90,0),
('18824dba-8e7c-8d21-7307-5925647e907a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Contracts','module',90,0),
('18e0f408-9f5c-e6fc-2cf3-592564cfbefd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','TemplateSectionLine','module',90,0),
('1a7bf93b-edd7-da92-947b-592564891071','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','TemplateSectionLine','module',90,0),
('1b117f2c-54f5-e6fa-3d00-59256459734e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOW_Processed','module',90,0),
('1bf08da0-6b79-3773-718b-592564c71ef1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','TemplateSectionLine','module',90,0),
('1c3e0c8e-5cbb-694c-b944-592564e076f2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Bugs','module',90,0),
('1da35dfc-eec1-4dc6-6de7-59256432df12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','TemplateSectionLine','module',90,0),
('1f5948d6-45c9-50cd-d57c-592564677870','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Accounts','module',89,0),
('1fd004e6-6935-f325-9332-592564750cd3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOW_Processed','module',90,0),
('203c7ae6-e17a-7e32-42fd-592564afdd3d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Documents','module',89,0),
('207272ae-76df-407a-db68-59256477fffb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Accounts','module',90,0),
('216f99a0-6cf1-4a49-7d6c-592564a63805','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Documents','module',90,0),
('21d7b2f0-7636-7380-64bc-59256442bc74','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Accounts','module',90,0),
('228eee29-bef8-0bb3-deac-592564cef734','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOW_Processed','module',90,0),
('22995699-b1fb-fd93-d2a6-592564786c07','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Documents','module',90,0),
('22e0512b-c62c-8c52-02e5-592564cc7b91','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Accounts','module',90,0),
('23c08dcf-87be-6380-406f-592564729cde','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Documents','module',90,0),
('23e54dbb-328c-fa24-a215-592564a30cc1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Accounts','module',90,0),
('24b91c9d-58f1-fd40-2abc-5925643f8726','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Documents','module',90,0),
('24fc9692-a40b-6cb9-c037-5925648bb3ad','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Accounts','module',90,0),
('25e191a7-2fa9-0db7-cc00-592564f2f1b1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Documents','module',90,0),
('26449795-ba99-ff69-5a1d-5925644f0327','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Accounts','module',90,0),
('26e50096-7504-3457-fc87-5925645c8379','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Contacts','module',90,0),
('26fcfaf3-e0de-3075-70cf-592564ec9f8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Documents','module',90,0),
('278d051e-1ec7-f16f-3301-592564cb15a3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Accounts','module',90,0),
('27dd07ed-cd1f-5838-900a-5925646843f5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOK_Knowledge_Base_Categories','module',90,0),
('283690bc-5685-c915-c572-59256424f6ba','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Documents','module',90,0),
('28ea09d6-bf9f-c334-7063-592564771a82','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','OutboundEmailAccounts','module',90,0),
('2ad92b97-fbfb-4123-7137-592b9c11685c','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','access','dp_founder_ul','module',89,0),
('2bebba28-0624-5160-3f2f-5925641af4e2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Users','module',89,0),
('2d544540-199e-1e66-72fb-592564fce02c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Users','module',90,0),
('2e7663a1-0cf0-80c1-24b7-592564b5bcf4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Users','module',90,0),
('2fcdd39a-2ea7-f27c-bba8-59256406b53a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Users','module',90,0),
('2feb8d86-1135-82df-32e3-5925640e5732','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Invoices','module',89,0),
('30dd4943-3a0d-aefc-e1ee-5925640d66f9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Users','module',90,0),
('3138d219-df01-3589-97d5-5925646af5f3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Invoices','module',90,0),
('3148b73c-3663-09d4-71d2-592564ae7c82','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','FP_events','module',89,0),
('31efe988-94a9-1fda-63e3-592564b0d6df','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Users','module',90,0),
('3290e8d9-82c1-1701-61dd-592564de30a4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','FP_events','module',90,0),
('32b52270-a828-0aab-71a3-5925644acba7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Invoices','module',90,0),
('33c32bee-5adb-b72d-bf7f-5925642084fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','FP_events','module',90,0),
('33fb84aa-0c4a-5298-eb81-59256450ca78','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Users','module',90,0),
('34073948-24b6-28c0-bc63-592564cc987c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Invoices','module',90,0),
('34bacbce-d5ca-e3f3-6676-592b9cb08b77','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','view','dp_founder_ul','module',90,0),
('351335c3-0ddb-0e87-21f5-59256428ecaa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','FP_events','module',90,0),
('3529cdd6-2d00-8878-0fa5-5925646587d9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Users','module',90,0),
('3569d016-56e4-f64e-ffdb-592564774947','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Invoices','module',90,0),
('3651fb1f-effc-94b1-dd55-59256479a5fd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','FP_events','module',90,0),
('370d1cbb-fd14-f408-ebab-592564a1d676','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Invoices','module',90,0),
('3713a454-b48d-7546-2b38-592b9c2d6f04','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','list','dp_founder_ul','module',90,0),
('3798bfef-339d-1062-60ed-59256449e812','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','FP_events','module',90,0),
('38090d87-acc7-397d-4c63-59256407e023','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Contacts','module',90,0),
('39194c6d-1c35-c53c-7f3b-592b9cb13af1','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','edit','dp_founder_ul','module',90,0),
('39718a70-206a-89ca-22aa-592564ecf20d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','FP_events','module',90,0),
('3abd5ba2-e9d7-2499-a551-59256444cb70','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','FP_events','module',90,0),
('3ac034b5-2355-f0c2-e454-5925648456fe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Invoices','module',90,0),
('3ca02bfb-bacb-2944-fe88-592564a9ff9c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Invoices','module',90,0),
('3e902a5b-9702-150f-4cfd-5926d2aef56a','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','access','dp_bkrv','module',89,0),
('3f4bf13d-b119-cabe-b775-59256410df39','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Opportunities','module',89,0),
('4076f279-cd3d-101c-63e2-592b9c984b99','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','delete','dp_founder_ul','module',90,0),
('4090aa9b-a492-9f62-4ff9-5925643b5152','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Opportunities','module',90,0),
('419033f6-7326-7ade-7646-5925648779be','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Maps','module',89,0),
('41b8e304-7e50-c095-e2cf-5925643c4d33','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Opportunities','module',90,0),
('4272d520-8637-4eb2-baa6-592b9cfb00a2','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','import','dp_founder_ul','module',90,0),
('42d95587-a278-289c-eb94-592564e075da','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Opportunities','module',90,0),
('44505817-5003-4aa2-b6cb-592564feeb1c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Maps','module',90,0),
('44720a37-a225-70d7-d33c-59256458ae0c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Opportunities','module',90,0),
('45278482-356e-a44c-da79-592b9cd44d36','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','export','dp_founder_ul','module',90,0),
('4578ec44-70b3-fa55-1cb9-5925648295b0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Opportunities','module',90,0),
('461ac14c-4a85-c045-86fa-5925640acc8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','FP_Event_Locations','module',89,0),
('4673f515-c8b3-fa4f-75a1-592564951def','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Project','module',89,0),
('4677a4e7-4f8d-39fc-8d21-59256431d9e0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Opportunities','module',90,0),
('4718eeb3-c4fb-614f-71ad-5925649ae43b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Maps','module',90,0),
('475610da-a141-488b-81e1-592b9c7ae62d','2017-05-29 03:58:19','2017-05-29 03:58:19','1','1','massupdate','dp_founder_ul','module',90,0),
('4786456b-0a15-6689-904e-5926d2b50cb1','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','view','dp_bkrv','module',90,0),
('478ed2f3-ff64-cf3e-7320-5925647c590d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','FP_Event_Locations','module',90,0),
('4803e562-2f2e-3871-489d-592564d25fec','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Project','module',90,0),
('48f02fb2-371d-dc51-33e8-59256426b897','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Maps','module',90,0),
('4911f675-7f10-ace8-9e62-5925649220b6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','FP_Event_Locations','module',90,0),
('498359df-ebb0-3b45-6ccd-5925643089fd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Project','module',90,0),
('49e4b481-b6bd-2b9d-61ca-5926d2b206df','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','list','dp_bkrv','module',90,0),
('4a678ea5-9b38-2bd7-fda5-5925644303af','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Opportunities','module',90,0),
('4a99b4c6-878b-d3fe-63d6-5925644eb0b5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','FP_Event_Locations','module',90,0),
('4ab7f61f-d638-5a4e-1177-5925643d151e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Maps','module',90,0),
('4abfa988-e469-35b5-f38e-59256434204e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Project','module',90,0),
('4bccc8ad-39e8-e9e6-c825-5926d2302b62','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','edit','dp_bkrv','module',90,0),
('4bf6dac8-fd03-c55c-ff6c-592564d17570','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','FP_Event_Locations','module',90,0),
('4c125b13-a179-0105-9c01-592564c12cde','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Project','module',90,0),
('4c4b9363-1c28-9982-4bbe-592564363399','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Maps','module',90,0),
('4d433b8a-2f4a-da18-0129-59256458329b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','FP_Event_Locations','module',90,0),
('4dd371b6-acd5-b07e-5a31-5926d2cdc50c','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','delete','dp_bkrv','module',90,0),
('4dfac029-9049-408d-2df4-592564a964be','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Project','module',90,0),
('4e051c7b-5060-d5e4-d988-592564778b88','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Maps','module',90,0),
('4ed693c1-d8af-17f2-2c8b-592564690fd5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','FP_Event_Locations','module',90,0),
('4f7774cc-cfe4-8c8d-b4a9-5925640c89cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Maps','module',90,0),
('4f99def4-72c1-f478-77a9-59256451b225','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Project','module',90,0),
('4f9b51e1-5a4b-dde2-23e7-59272d8b429a','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','access','dp_realty','module',89,0),
('4ff61581-2104-a4ed-fe44-5926d28a9f0f','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','import','dp_bkrv','module',90,0),
('4ff6dc67-2f3a-abf6-cc32-592564985ca4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','FP_Event_Locations','module',90,0),
('50675523-bbed-598e-d52d-592564554740','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Spots','module',89,0),
('50b85d74-3ef0-4d3a-e135-5925649cf51d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_PDF_Templates','module',89,0),
('50f3217a-b574-39ff-bf1e-592564d41ea3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Project','module',90,0),
('518d99c4-558b-351b-ec1b-592564b8e454','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Spots','module',90,0),
('520d7287-1b9d-5829-a93f-5926d220fa6f','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','export','dp_bkrv','module',90,0),
('52318172-cebb-4f78-7b54-592564813de3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_PDF_Templates','module',90,0),
('52c2e837-e4e9-b981-212f-592564bd6f1d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Spots','module',90,0),
('539f0a19-2e9f-00f4-4050-592564ce262d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','OutboundEmailAccounts','module',90,0),
('53c0c5ce-cd4e-eb95-33b9-5925644aecf5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_PDF_Templates','module',90,0),
('54087b0d-f496-c657-71ce-592564e2b168','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Spots','module',90,0),
('545a409e-6a2a-558d-af21-5926d26e8ac4','2017-05-25 12:46:45','2017-05-25 12:46:45','1','1','massupdate','dp_bkrv','module',90,0),
('552ba5f1-642d-7626-679e-59256471f0b2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_PDF_Templates','module',90,0),
('5587eb44-6152-9f3e-dbc8-5925647bde8f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Spots','module',90,0),
('568c15d0-5418-63c4-6f83-592564490323','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_PDF_Templates','module',90,0),
('56fa86f6-2a0d-8e91-c084-592564d07a81','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Spots','module',90,0),
('5800fe63-193a-7aa9-0a00-592564804c36','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_PDF_Templates','module',90,0),
('58446609-de3c-5851-a042-59272df93715','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','view','dp_realty','module',90,0),
('584fc1ef-4481-5017-8b01-592564552c42','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Spots','module',90,0),
('594005aa-2299-99d2-3ba1-5925643a7e4f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Contacts','module',90,0),
('59739056-8eb7-34d5-a28e-59256456f9b0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Spots','module',90,0),
('5991f5de-6979-f127-9099-592564f0a3f7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_PDF_Templates','module',90,0),
('5a6cb8f7-7a64-2561-7941-59272dcbd0fb','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','list','dp_realty','module',90,0),
('5d8889c9-6f9a-f091-be0b-592564b4403f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_PDF_Templates','module',90,0),
('5d9fe3df-96e1-45fc-171d-5925647f70fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOD_IndexEvent','module',89,0),
('5de47ae3-d6ee-012d-c786-59272d6b68f6','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','edit','dp_realty','module',90,0),
('5edff6d6-735a-a946-92d0-59256434c86f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOD_IndexEvent','module',90,0),
('5f2fde6b-f5d5-300e-3aac-5925641bb69c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','EmailTemplates','module',89,0),
('60086668-8a2b-0191-e750-59256463b988','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOD_IndexEvent','module',90,0),
('608cc0a5-a7f3-cfa2-44af-59272d36f1cd','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','delete','dp_realty','module',90,0),
('6091cb62-3981-f1c1-fa33-592564003b02','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','ProjectTask','module',89,0),
('60f6edde-afd7-e6df-71b6-5925642910a9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','EmailTemplates','module',90,0),
('610f9834-e450-d9d3-028e-592b0831978a','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','access','sro_svid_sro','module',89,0),
('6132421a-cbed-4500-8e64-592564dd0c93','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOD_IndexEvent','module',90,0),
('61c22bbe-611b-6673-1a18-59256403af7e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','ProjectTask','module',90,0),
('6242c377-b887-86dc-604e-592564cb8584','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOD_IndexEvent','module',90,0),
('624c6d7e-853c-9332-605d-592564f7f6d6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Markers','module',89,0),
('62739f95-df3e-6bf6-ae85-59256468c10f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','EmailTemplates','module',90,0),
('62c2f9e9-c3a2-94b1-94e1-59272d7eab87','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','import','dp_realty','module',90,0),
('62efa492-aa46-da6d-3545-59256453dbe6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','ProjectTask','module',90,0),
('63622169-091c-bff5-8096-592564f65d1d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOD_IndexEvent','module',90,0),
('6402f0ba-2c1d-fd22-a5f5-592564ed85bb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','ProjectTask','module',90,0),
('642439c1-b715-4471-27b5-5925648353a2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Markers','module',90,0),
('6432d85d-75b1-c298-6020-592564020d99','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','EmailTemplates','module',90,0),
('6481270c-1724-7422-8c07-59256477caf5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOD_IndexEvent','module',90,0),
('6531ca27-0669-56d6-f989-592564d84294','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','ProjectTask','module',90,0),
('655c8a63-2411-bc65-daba-59272dfa2ba9','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','export','dp_realty','module',90,0),
('659fb557-481f-7e9f-e8cf-592564ba8443','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Markers','module',90,0),
('65cc28c6-6bf3-2370-f957-592564bf312c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOD_IndexEvent','module',90,0),
('660dba79-8158-d326-0ccb-5925648fb74d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','EmailTemplates','module',90,0),
('664bc999-523b-a960-2689-592564a460d2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','ProjectTask','module',90,0),
('674e687d-1e4a-469e-5ed3-5925649f4ee9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','ProjectTask','module',90,0),
('6770ad0a-4a60-5e12-685e-592564d1fcc4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Markers','module',90,0),
('6792b1f9-7b21-dcae-147b-592b084b626c','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','view','sro_svid_sro','module',90,0),
('67ab466a-9366-27b7-a290-592564f11b19','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','EmailTemplates','module',90,0),
('6846f05d-3263-41a8-6406-592564f18f89','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','ProjectTask','module',90,0),
('686df4ba-5306-e303-1e2d-59272d957776','2017-05-25 19:15:17','2017-05-25 19:15:17','1','1','massupdate','dp_realty','module',90,0),
('68eaff61-686f-76b9-9d8f-592564b2b34b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Markers','module',90,0),
('6903eb61-be7c-e77a-3157-5925642fb47b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','EmailTemplates','module',90,0),
('6906cc52-71ba-1061-2ed0-592b086dee51','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','list','sro_svid_sro','module',90,0),
('69ac0e7f-e756-6db1-22f3-5925646df4a7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Bugs','module',90,0),
('6a5576b0-58d4-758d-58aa-592b085b0363','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','edit','sro_svid_sro','module',90,0),
('6a692618-ab50-f579-b565-59256412f910','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Markers','module',90,0),
('6a9f9837-5b1c-ff51-bb90-59256496105a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','EmailTemplates','module',90,0),
('6bb7e990-1a78-3f9f-5830-592564028086','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Markers','module',90,0),
('6bbe5e76-ddb8-17f7-c3cf-592b089ee0bd','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','delete','sro_svid_sro','module',90,0),
('6cf6b475-7a06-0985-ec43-592564128da5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Markers','module',90,0),
('6dab649e-4e0c-fca8-5242-592564fed239','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Product_Categories','module',89,0),
('6f18ede4-8148-63d2-c7c1-592564bdb0c1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Product_Categories','module',90,0),
('7028bee7-3248-fc92-78dc-592564fc9b11','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOD_Index','module',89,0),
('706cb269-fa43-50dd-0f6a-592b082455e2','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','import','sro_svid_sro','module',90,0),
('7074eac8-e178-1b90-e6b4-592564b79cdc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Product_Categories','module',90,0),
('711e5a2c-8abd-ffb9-266c-59256488bbae','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Notes','module',89,0),
('718a9cd4-880a-7da4-9f93-592564c5f57b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOD_Index','module',90,0),
('71af4945-a6d5-c8db-2622-592564c39397','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Product_Categories','module',90,0),
('724033ab-b4a7-b31c-0ad7-592b085e903b','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','export','sro_svid_sro','module',90,0),
('72617cc7-d088-32ed-9975-5925649e763e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Notes','module',90,0),
('72dbf649-7d1f-26f6-3337-592564007a74','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOD_Index','module',90,0),
('73338552-523e-a422-7ed6-5925644be58a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Product_Categories','module',90,0),
('739856ff-8f8f-3477-17e0-5925644ed1cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Notes','module',90,0),
('7430d855-a4ed-f680-52e4-5925643a6de4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOD_Index','module',90,0),
('74998f8a-19ae-187e-9e19-592564dac258','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Product_Categories','module',90,0),
('750b1fc9-e895-b03b-8951-592564afb3c2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Notes','module',90,0),
('75bbaaad-7827-6454-0595-5925649d732c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOD_Index','module',90,0),
('75f71ed0-5ae0-d152-c517-5925640f3fc2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Product_Categories','module',90,0),
('762074c9-7bb0-f3f1-a812-59256494357b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Notes','module',90,0),
('76a9d2ae-0e73-c4dc-c72e-592b083b760e','2017-05-28 17:26:32','2017-05-28 17:26:32','1','1','massupdate','sro_svid_sro','module',90,0),
('772630ec-8fb5-f9d2-2d12-5925648dc9cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOD_Index','module',90,0),
('773bec7c-9403-3ee0-839c-59256452d1af','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Notes','module',90,0),
('7755f8df-baec-3f94-11c8-592564cab0a4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','EAPM','module',89,0),
('77b2e06d-6a5b-7e18-3c38-5925642dbb19','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Product_Categories','module',90,0),
('7857cdc1-7615-7c24-0488-5925646f00e3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOD_Index','module',90,0),
('786e0443-0a04-19f4-fb59-5925642c15f9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Notes','module',90,0),
('791fdddd-0141-c6cc-def0-59256496af30','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','EAPM','module',90,0),
('798cc1cf-8565-a8c2-a258-59256454a1f4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Notes','module',90,0),
('799e87fc-93fd-0e29-6499-59256498b297','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOD_Index','module',90,0),
('7a7125f6-0b75-5019-da7b-592564eed389','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Areas','module',89,0),
('7a7aba15-8f2a-59b8-f69a-59256470a572','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','EAPM','module',90,0),
('7bca0e8d-9cf5-84e3-dabf-592564156643','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','EAPM','module',90,0),
('7c4b7014-5aa4-38a1-235f-592564f7358e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Campaigns','module',89,0),
('7c99b69b-1427-cbd6-5899-5925648529cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Areas','module',90,0),
('7d24bb26-88cf-556f-ddf1-59256448abc3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','EAPM','module',90,0),
('7d837f8d-3c93-7305-333f-592564a5b864','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Campaigns','module',90,0),
('7e5bb1e9-2251-aa52-53a6-592564bd0b2b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','EAPM','module',90,0),
('7e7c554d-c663-70f7-c369-592564badad4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Areas','module',90,0),
('7f89a846-56e8-d3ea-f5d3-592564c4e88c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Campaigns','module',90,0),
('7fc5a6fe-1514-4da6-9485-592564a3659c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','EAPM','module',90,0),
('80d0a7af-1d88-98f4-df95-592564047141','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Areas','module',90,0),
('80e001f9-97bb-ca7d-4e84-5925642a96cc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Bugs','module',90,0),
('80f61337-deb7-c246-daee-592564609465','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','EAPM','module',90,0),
('819b446e-f296-4043-6346-5925644b7b3f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Campaigns','module',90,0),
('8330d8ec-9dd2-7034-f9fd-59256439fb29','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Campaigns','module',90,0),
('836bcd67-9fb8-72eb-702f-592564ee157a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Products','module',89,0),
('83b6e320-891b-314f-6788-592564c32dfe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Areas','module',90,0),
('846b7bfe-39a5-d1f0-0584-592564a35f98','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Campaigns','module',90,0),
('8488260f-4b79-9ca5-b445-592564c2cf31','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Calls','module',89,0),
('84b4b2fc-7dea-e223-640b-592564ae97bd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Products','module',90,0),
('857dbad0-7b76-b8a9-1a54-592564f43c8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Areas','module',90,0),
('858abe37-2952-a449-fdb1-5925647bb1bc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Campaigns','module',90,0),
('85c16938-6029-c620-e135-59256438a294','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Calls','module',90,0),
('85c9b074-3b6a-e033-d244-592564c466a1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Products','module',90,0),
('86c1b182-51b9-ac54-c64c-592564f99600','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOP_Case_Events','module',89,0),
('86ca3522-c826-18ab-9799-592564b03dfe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Campaigns','module',90,0),
('86f48c68-cb76-090b-1b6d-59256445be37','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Products','module',90,0),
('880412ca-c9e0-e88a-7fa7-5925643130e1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Calls','module',90,0),
('882d4255-3e6c-0270-eeb2-5925645c718e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Products','module',90,0),
('8833d87a-9bbf-2796-f98b-592564359ac9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOP_Case_Events','module',90,0),
('8897957c-2d5c-5fb4-7f30-59256456bb76','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Areas','module',90,0),
('894cb07a-667c-f89e-2d4e-592564395de7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Products','module',90,0),
('89c40de8-033c-c9c9-40b7-592564aed98d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Calls','module',90,0),
('89cb6560-dda5-3c2b-97af-5925644f817e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOP_Case_Events','module',90,0),
('89fd6046-1985-d890-e42f-592b9c540b39','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','access','dp_founder_fl','module',89,0),
('8a274117-2c0f-328a-40c3-592564335c06','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Areas','module',90,0),
('8ad11ed4-6e92-27f9-2e81-592564817cc6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Products','module',90,0),
('8b5b6647-b8db-86ba-34c6-592564ac2aad','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Calls','module',90,0),
('8bdbcb74-f52c-8301-a74c-5925646b2e69','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOP_Case_Events','module',90,0),
('8c1ad23c-e66f-5300-c512-5925646e0eeb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Products','module',90,0),
('8cc57d35-4834-0079-ce2f-59256449ae59','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Calls','module',90,0),
('8e2c3825-ceef-5157-b639-592564212449','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Calls','module',90,0),
('8e9b63f4-dcad-fd85-c262-5925647f397a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOP_Case_Events','module',90,0),
('8f7fa86b-9be1-8398-e78c-592564234b9d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Calls','module',90,0),
('9035e82e-8c79-9576-60ce-59256498ee24','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOP_Case_Events','module',90,0),
('92416dfa-05ba-62ce-d5bc-592b9c18b6ba','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','view','dp_founder_fl','module',90,0),
('9273f407-98c3-86b4-75f3-592564fa6e78','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOP_Case_Events','module',90,0),
('92e3dc1b-dac6-c165-0834-5925643ebb85','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AM_ProjectTemplates','module',89,0),
('93fd6338-ebdb-c244-f360-59256473717e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOP_Case_Events','module',90,0),
('9410e7f9-c215-53b6-bd6d-592b9c62e6bd','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','list','dp_founder_fl','module',90,0),
('9442d13a-4cdb-2885-b927-5925641594fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AM_ProjectTemplates','module',90,0),
('95310256-0fa2-8b0c-48b7-592564a6f140','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Alerts','module',89,0),
('95641d65-a0a1-e7ea-c551-59256462edab','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AM_ProjectTemplates','module',90,0),
('95e450ed-7712-b50e-9db9-592b9c0c7936','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','edit','dp_founder_fl','module',90,0),
('96afbf57-6024-4d17-49a1-592564058860','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AM_ProjectTemplates','module',90,0),
('97b928fd-cba8-4088-bc37-592b9cb03b49','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','delete','dp_founder_fl','module',90,0),
('97de90d3-ee52-62e3-0aee-592564ccc78c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AM_ProjectTemplates','module',90,0),
('98900fa1-069a-2cf6-4045-5925640fde45','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','OutboundEmailAccounts','module',90,0),
('98ff6059-4b15-7ca5-72f4-592564e5aa56','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AM_ProjectTemplates','module',90,0),
('997652b5-ef93-72ed-1a88-592b9cd5e35d','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','import','dp_founder_fl','module',90,0),
('997d6ba6-3c16-b40c-da22-5925646d3e81','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','jjwg_Address_Cache','module',89,0),
('9a43ae71-e6e0-bd53-800d-59256408667c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AM_ProjectTemplates','module',90,0),
('9aeb33c6-aa31-82f4-3515-59256419e20b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','jjwg_Address_Cache','module',90,0),
('9b0fbc2b-7a87-a6dc-a988-592b9cfeb212','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','export','dp_founder_fl','module',90,0),
('9b6dab5a-dba0-f32b-c7cd-59256481b998','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AM_ProjectTemplates','module',90,0),
('9c8e15ac-e95f-94a8-3a1b-59256427e6cb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','jjwg_Address_Cache','module',90,0),
('9cccd982-742f-83df-749d-592b9c5155ba','2017-05-29 03:57:10','2017-05-29 03:57:10','1','1','massupdate','dp_founder_fl','module',90,0),
('9e02c754-e6e4-24f4-dbf1-592564607787','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','ProspectLists','module',89,0),
('9e6a31f8-1dbc-637f-42ed-5925646bcb8c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Emails','module',89,0),
('9f366d67-8cf5-a7dc-d646-592564bf0017','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','ProspectLists','module',90,0),
('9f7fe16d-9921-2140-9d95-5925641009f4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOP_Case_Updates','module',89,0),
('a0095f6f-cc35-cbf9-155e-592564c6a49f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Emails','module',90,0),
('a071b98a-e813-5a5e-c546-592564056454','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','ProspectLists','module',90,0),
('a09d6109-005a-b7c1-4300-5925642f0330','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOP_Case_Updates','module',90,0),
('a18ef381-b9e0-e600-9230-592564ffeafd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','ProspectLists','module',90,0),
('a1b95047-1e71-9594-d6fc-5925641cef1f','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOP_Case_Updates','module',90,0),
('a2655c4a-9abe-9d12-7845-5925643fa5da','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Emails','module',90,0),
('a2b6ae39-de64-0e4c-789e-5925640db8cc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','ProspectLists','module',90,0),
('a2d730cb-5018-919d-58f1-5925644eb25b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','jjwg_Address_Cache','module',90,0),
('a2df7bce-230e-f51f-efda-592564ffb0cc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOP_Case_Updates','module',90,0),
('a3b1049b-9170-ea78-09f5-59256432ffb1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Emails','module',90,0),
('a41861a2-5c5f-dd56-8346-5925641efb0b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOP_Case_Updates','module',90,0),
('a41c170c-cb90-e272-0ce5-592564db6f12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','ProspectLists','module',90,0),
('a4706533-e8ea-05c7-3836-5925649caa49','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','jjwg_Address_Cache','module',90,0),
('a4fd8eec-d5c0-306c-c68e-592564a73563','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Emails','module',90,0),
('a525197d-c8c7-11af-be34-592564331c33','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','ProspectLists','module',90,0),
('a579e34e-7b3c-a141-7c7f-592564deba53','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOP_Case_Updates','module',90,0),
('a61fe7b2-8b5b-0d26-f2f8-5925644b0aa5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','jjwg_Address_Cache','module',90,0),
('a626a4a5-22fb-7102-eeed-592564f29851','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','ProspectLists','module',90,0),
('a65da3d1-7bdb-7095-dfd2-5925645eb267','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Emails','module',90,0),
('a6b0bc39-90e3-5fe9-fbdc-592564e8aebf','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOP_Case_Updates','module',90,0),
('a761f461-99d3-2dc2-7803-5925643de90e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Emails','module',90,0),
('a7e82439-bd9b-b0ee-d60b-592564ded457','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','jjwg_Address_Cache','module',90,0),
('a7f773d9-2f38-5b94-170c-5925646f2724','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOP_Case_Updates','module',90,0),
('a815047a-a25d-6a67-ed5d-592564299580','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Alerts','module',90,0),
('a8e70f2c-c33e-55e2-9c2a-5925647f06ff','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Contracts','module',89,0),
('a8fa4880-38b1-d883-26d2-592564a81a92','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Emails','module',90,0),
('a937a342-208b-dd93-1afa-592564e1cd4c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Leads','module',89,0),
('a98bbdf5-93ae-4e76-4b59-5925647c38c6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','jjwg_Address_Cache','module',90,0),
('acdee2ef-da71-e239-b6ed-5925641ba071','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Leads','module',90,0),
('aef7bb67-e81b-7b38-8e21-5925647f77ef','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Leads','module',90,0),
('b04b51e9-217f-bf61-d2a2-59256436f552','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Leads','module',90,0),
('b182988b-6c00-7040-8e98-592564804e92','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Prospects','module',89,0),
('b22c13ef-95a3-e88e-c3ea-592564d06495','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOS_Quotes','module',89,0),
('b35d50c9-9573-ed56-2564-592564e5cb64','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Prospects','module',90,0),
('b3a3b3c7-5b46-b4ec-113b-592564bb8255','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Quotes','module',90,0),
('b40f274b-56bb-b84d-003b-59256484cf91','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Leads','module',90,0),
('b488b56d-07c7-573b-0e33-5925646c6428','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Prospects','module',90,0),
('b503e4e0-8ad9-e420-32f7-592824dafd8b','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','access','dp_license','module',89,0),
('b509c134-ea8a-5ee4-fb63-59256473781d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Quotes','module',90,0),
('b57dfad6-d1a8-4521-3e36-59256417d4e3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Leads','module',90,0),
('b58c80c8-20d1-eef5-10de-592564275ef0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOR_Reports','module',89,0),
('b609639b-b963-475d-9431-592564f766fe','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Prospects','module',90,0),
('b652beff-6f92-c2e1-1207-592564bb428a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOS_Quotes','module',90,0),
('b6edd723-8d8e-ea05-3a68-59256410dacf','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOR_Reports','module',90,0),
('b719c335-361d-5434-d1d5-59256405fce5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Leads','module',90,0),
('b7b87a63-3ace-21b2-2891-592564546b12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOS_Quotes','module',90,0),
('b81a61df-8b0d-c08f-ea62-592564184c31','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOR_Reports','module',90,0),
('b82bcf10-09ee-678e-6ea8-592564144a53','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Prospects','module',90,0),
('b89803a4-a709-19fc-6dac-5925640b706a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Leads','module',90,0),
('b940fbe9-1be8-5832-b408-5925644df2ea','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Prospects','module',90,0),
('b9525773-ebce-299e-a2b8-592564d902fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOR_Reports','module',90,0),
('ba0b2353-2687-3ba0-94f1-5925649eabd7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOS_Quotes','module',90,0),
('ba436fdf-f437-4df1-ced7-592564a021a3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Prospects','module',90,0),
('bb63626f-14a6-7db4-ceab-59256405a686','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOR_Reports','module',90,0),
('bb6baf92-b14e-d5e0-0f52-5925649277fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Prospects','module',90,0),
('bbdea725-c7de-f2bd-652d-592564c065a1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Calls_Reschedule','module',89,0),
('bc02a448-967a-0970-a4d0-59256458de20','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOS_Quotes','module',90,0),
('bc162da9-0dcb-1df8-4c1c-592824867fb1','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','view','dp_license','module',90,0),
('bc1a0642-70fb-bd58-f89f-59256483596c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Alerts','module',90,0),
('bcbc1548-6947-13f8-2018-592564d6aef3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOR_Reports','module',90,0),
('bd94a534-3319-c9c5-b47d-59282449fe15','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','list','dp_license','module',90,0),
('bde96f5e-b36d-b7e9-bb14-59256483588a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOS_Quotes','module',90,0),
('be42632d-5408-c7d3-06d9-5925648efbaa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOR_Reports','module',90,0),
('be9f8c89-8e4f-cea9-02d4-592564025250','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Meetings','module',89,0),
('bea8b4ff-e1db-0585-8996-592564cfb9f2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Calls_Reschedule','module',90,0),
('bf27e9ff-dae8-9e0b-c9c7-5928245babc6','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','edit','dp_license','module',90,0),
('bf9890e9-6469-37a3-cf58-5925645d9e33','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOR_Reports','module',90,0),
('bfcdf9d8-413e-466f-3472-592564f02c1c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Meetings','module',90,0),
('c0312370-8eda-7184-dc43-592564aa00dc','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Calls_Reschedule','module',90,0),
('c09277db-b273-117d-bc44-59282421474e','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','delete','dp_license','module',90,0),
('c0db855d-6257-0995-6527-592564bc0676','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Meetings','module',90,0),
('c191f75b-c9a0-ff99-9641-592564bf3577','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Calls_Reschedule','module',90,0),
('c218689c-8812-5bfd-5e8b-5928248f6571','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','import','dp_license','module',90,0),
('c237d749-bfc5-19a0-68b3-592564c18e14','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Meetings','module',90,0),
('c34a0a42-3243-18da-e2b6-592564875092','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOW_Processed','module',89,0),
('c37ac16e-68dd-95da-191b-592824ad8aaf','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','export','dp_license','module',90,0),
('c386652c-6ddb-7dae-de19-592564f60250','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Calls_Reschedule','module',90,0),
('c40870a5-e0f5-ceba-5bf5-592564d67e1a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Meetings','module',90,0),
('c4d16e3b-e3a8-2e8e-05b6-592824c52301','2017-05-26 12:51:17','2017-05-26 12:51:17','1','1','massupdate','dp_license','module',90,0),
('c4ffaa81-5029-0143-bba7-59256453e5b5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Calls_Reschedule','module',90,0),
('c54626ca-2205-923e-0d02-592564ef6ebf','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Meetings','module',90,0),
('c641ec1b-e63d-f4a7-b78a-5925645bb84a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Calls_Reschedule','module',90,0),
('c666478f-25c6-df9b-236e-592564c829d5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Meetings','module',90,0),
('c7a238f6-8063-6950-1ce6-592564919cd7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Calls_Reschedule','module',90,0),
('c7d72dc4-2238-e2bc-bdc1-5925648d5907','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Meetings','module',90,0),
('c9c73879-801f-2f3d-dc92-592564fb5ad7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','EmailMarketing','module',89,0),
('caaa0ff1-2662-d488-7bae-592564a4cc89','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOK_KnowledgeBase','module',89,0),
('cc63a273-5328-d30b-3699-592564290912','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','EmailMarketing','module',90,0),
('cd7f7d50-4795-8816-1331-592564b55f12','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','EmailMarketing','module',90,0),
('cd8b0646-d90a-ffe8-adb9-592564695e30','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Bugs','module',90,0),
('ce79e5d9-a75e-d0f3-4d9a-592564e39851','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Cases','module',89,0),
('ce945be8-3e14-8fac-5896-5925641deeb2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','EmailMarketing','module',90,0),
('cfc1a7db-59de-db29-8676-5925646dcc08','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','EmailMarketing','module',90,0),
('d0258c5b-6894-df16-51fd-5925641b8081','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Cases','module',90,0),
('d0c80d70-d9fc-3638-9e4a-592564349e7d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Alerts','module',90,0),
('d11e4709-20c5-5d80-ee86-59256403b831','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','EmailMarketing','module',90,0),
('d19ef571-500a-e7b8-f466-592564ea3726','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Tasks','module',89,0),
('d1a34f1d-0c3f-fa52-7115-59256466fa59','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AM_TaskTemplates','module',89,0),
('d1c102a3-2993-a192-d878-59256464b217','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Cases','module',90,0),
('d222ce7f-ce1e-a307-7622-592564d3f208','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','EmailMarketing','module',90,0),
('d22700c5-19bd-c1a0-af9e-59256406ac3d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','SecurityGroups','module',89,0),
('d321d382-fe5e-3613-273d-59256404e3b2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Tasks','module',90,0),
('d335fc39-b447-17be-60ea-592564b8803a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AM_TaskTemplates','module',90,0),
('d33c8c7c-53be-6906-4834-59256485a333','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Cases','module',90,0),
('d35d7c4e-762d-b7bd-5fc1-592564d8c42b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','EmailMarketing','module',90,0),
('d3f76523-7188-6078-cc8d-592564c2731b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','SecurityGroups','module',90,0),
('d452862e-a776-d7ed-0e3c-5925645d41cd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Tasks','module',90,0),
('d47fee2e-e684-ac40-2c42-592564b27d95','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Cases','module',90,0),
('d4e0d847-e5a5-0cbc-fced-5925643b47be','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOW_WorkFlow','module',89,0),
('d4ed85f3-c423-b7c8-e959-5925643851a7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AM_TaskTemplates','module',90,0),
('d57063b7-be97-b7eb-79ac-592564a4e5c4','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','SecurityGroups','module',90,0),
('d570e2e1-8b6d-e21d-f470-5925647611f7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Tasks','module',90,0),
('d5b1d0c6-eb5f-e00b-d1dd-592564f2c827','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Cases','module',90,0),
('d62c9b9c-e4d0-f67b-4924-5925648f8ee3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AM_TaskTemplates','module',90,0),
('d67021e7-4d95-b290-868e-5925642fc82a','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOW_WorkFlow','module',90,0),
('d6a41f93-7c0b-6692-5e19-592564852d5d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Tasks','module',90,0),
('d6c6750d-3aab-e4a8-14cf-592564086404','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','SecurityGroups','module',90,0),
('d76c5c58-816f-3fa7-43de-5925640460c9','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Cases','module',90,0),
('d79b21c4-db12-23c8-64bf-59256477f388','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AM_TaskTemplates','module',90,0),
('d7c4551e-7866-8a41-23a4-592564fe9a20','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Tasks','module',90,0),
('d80fd00d-bc92-bb06-ca91-592564db9aab','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','SecurityGroups','module',90,0),
('d8118dfd-6f8d-e88e-2972-5925648cfe92','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOW_WorkFlow','module',90,0),
('d8b31032-a0e5-a3c5-0a9e-59256448e044','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AM_TaskTemplates','module',90,0),
('d8dbbab2-bc85-9e73-df6b-592564a6f2c0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Cases','module',90,0),
('d9155b0a-5bfc-b1c4-a543-592564e4757d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','Tasks','module',90,0),
('d93c820e-6727-4b68-add5-59256405c0a2','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','SecurityGroups','module',90,0),
('d99a8f45-1436-f414-1b70-592564af912b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOW_WorkFlow','module',90,0),
('d9c81c10-63f7-0f13-7992-592564378318','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AM_TaskTemplates','module',90,0),
('d9f20532-f485-885f-b380-5925648dc9f5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOS_Contracts','module',90,0),
('da8680ef-4207-58ea-502a-5925649fa112','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','SecurityGroups','module',90,0),
('daa40ed7-4ada-a968-ecb6-5925643e4917','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','Tasks','module',90,0),
('db016c6f-af5c-1c6e-f594-5925649cb49b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AM_TaskTemplates','module',90,0),
('dbb378cd-5c36-e292-a504-592564c8043c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOW_WorkFlow','module',90,0),
('dbd49dbd-96cd-4810-973a-592564fd9d3c','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','SecurityGroups','module',90,0),
('dd2d0077-a1c6-01ed-e29c-5925645afd45','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOW_WorkFlow','module',90,0),
('de990503-546b-6054-ebfd-592564b70dcb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOK_KnowledgeBase','module',90,0),
('df2aca5e-22f4-7ef7-9bf8-592564e76887','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOW_WorkFlow','module',90,0),
('e09b4d5a-1560-54b2-7e13-592564d951d0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOW_WorkFlow','module',90,0),
('e646cbbe-5b4a-4a6a-3725-592564cd6f3b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOR_Scheduled_Reports','module',89,0),
('e7ce0228-c508-6a29-f5be-592564e519d5','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','Alerts','module',90,0),
('e7f5c4a6-95ab-641c-8791-59256401f007','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','OutboundEmailAccounts','module',89,0),
('e90e8f5c-24e2-9e17-5870-592564824993','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOR_Scheduled_Reports','module',90,0),
('e9a71ab8-82d1-c442-c5e1-592564277cba','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','OutboundEmailAccounts','module',90,0),
('ea888bf2-f049-b3cf-c210-59256408536d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOR_Scheduled_Reports','module',90,0),
('eb293405-926c-8af5-8ab6-592564ed89bd','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','OutboundEmailAccounts','module',90,0),
('ebb007d2-62e5-e849-60dd-592564e9f985','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Bugs','module',89,0),
('ebfd8757-8e2e-c9a1-29fa-59256458bdc6','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOR_Scheduled_Reports','module',90,0),
('ecca2d44-59d4-5ca5-e1b5-5925642e0a8b','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','OutboundEmailAccounts','module',90,0),
('ed2c78ab-59c5-d8ce-b665-59256457bb57','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Bugs','module',90,0),
('ed93055d-235f-ddf3-7c4f-592564e9c172','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','AOK_Knowledge_Base_Categories','module',89,0),
('eda1943d-c0f8-4675-b348-5925648e5bc1','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOR_Scheduled_Reports','module',90,0),
('ee508cbe-f9df-8732-1278-592564c5555d','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','OutboundEmailAccounts','module',90,0),
('eebea8f2-4149-fb32-9c88-5925641e6365','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOK_Knowledge_Base_Categories','module',90,0),
('eedfe052-473d-a0ce-a966-5925648b835e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Bugs','module',90,0),
('ef19df34-0607-a454-49e5-5925645c4d26','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOR_Scheduled_Reports','module',90,0),
('efce29cb-3824-bcf7-0a2c-592564a15273','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOK_Knowledge_Base_Categories','module',90,0),
('f01805df-9cb9-b299-3ecb-59256408b005','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','access','Contacts','module',89,0),
('f0a3bf62-de49-d960-d4fd-592564688794','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','export','AOR_Scheduled_Reports','module',90,0),
('f0b4d9b6-74bb-61e3-29d3-592564f57c61','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Bugs','module',90,0),
('f0e2787c-abef-d10a-cd0a-5925640f73ca','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','AOK_Knowledge_Base_Categories','module',90,0),
('f145b997-26c0-1299-7410-59256456ea78','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','Contacts','module',90,0),
('f2800537-834c-01b7-e1f9-59256448c13e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','Contacts','module',90,0),
('f2803842-58df-e514-6c6e-592564cce7b3','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','delete','AOK_Knowledge_Base_Categories','module',90,0),
('f29c3eab-b08c-bc8b-3290-59256455ae3e','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','massupdate','AOR_Scheduled_Reports','module',90,0),
('f37e5c31-3303-c6f4-ad42-592564225605','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','edit','Contacts','module',90,0),
('f3b9de43-1d56-2e5d-42e7-59256405f466','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','AOK_Knowledge_Base_Categories','module',90,0),
('f5190af2-3c36-026d-eb5c-592564a52931','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOK_KnowledgeBase','module',90,0),
('f73b0072-4b54-0452-feb9-592564555dad','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','view','AOW_Processed','module',90,0),
('fb0102f1-7242-0a4b-c308-592564b18034','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','list','AOS_Contracts','module',90,0),
('fba3006d-f61d-ae33-ed89-592564fc3525','2017-05-24 10:47:24','2017-05-24 10:47:24','1','','import','Alerts','module',90,0)	;
#	TC`acl_roles`utf8_general_ci	;
CREATE TABLE `acl_roles` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aclrole_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`acl_roles_actions`utf8_general_ci	;
CREATE TABLE `acl_roles_actions` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `action_id` varchar(36) DEFAULT NULL,
  `access_override` int(3) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acl_role_id` (`role_id`),
  KEY `idx_acl_action_id` (`action_id`),
  KEY `idx_aclrole_action` (`role_id`,`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`acl_roles_users`utf8_general_ci	;
CREATE TABLE `acl_roles_users` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aclrole_id` (`role_id`),
  KEY `idx_acluser_id` (`user_id`),
  KEY `idx_aclrole_user` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`address_book`utf8_general_ci	;
CREATE TABLE `address_book` (
  `assigned_user_id` char(36) NOT NULL,
  `bean` varchar(50) DEFAULT NULL,
  `bean_id` char(36) NOT NULL,
  KEY `ab_user_bean_idx` (`assigned_user_id`,`bean`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`alerts`utf8_general_ci	;
CREATE TABLE `alerts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `target_module` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url_redirect` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates`utf8_general_ci	;
CREATE TABLE `am_projecttemplates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Draft',
  `priority` varchar(100) DEFAULT 'High',
  `override_business_hours` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_audit`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_am_projecttemplates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_contacts_1_c`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_contacts_1_alt` (`am_projecttemplates_ida`,`contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_project_1_c`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_project_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_projecttemplates_project_1am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `am_projecttemplates_project_1project_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_project_1_ida1` (`am_projecttemplates_project_1am_projecttemplates_ida`),
  KEY `am_projecttemplates_project_1_alt` (`am_projecttemplates_project_1project_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_projecttemplates_users_1_c`utf8_general_ci	;
CREATE TABLE `am_projecttemplates_users_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `users_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_projecttemplates_users_1_alt` (`am_projecttemplates_ida`,`users_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_tasktemplates`utf8_general_ci	;
CREATE TABLE `am_tasktemplates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `priority` varchar(100) DEFAULT 'High',
  `percent_complete` int(255) DEFAULT '0',
  `predecessors` int(255) DEFAULT NULL,
  `milestone_flag` tinyint(1) DEFAULT '0',
  `relationship_type` varchar(100) DEFAULT 'FS',
  `task_number` int(255) DEFAULT NULL,
  `order_number` int(255) DEFAULT NULL,
  `estimated_effort` int(255) DEFAULT NULL,
  `utilization` varchar(100) DEFAULT '0',
  `duration` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_tasktemplates_am_projecttemplates_c`utf8_general_ci	;
CREATE TABLE `am_tasktemplates_am_projecttemplates_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `am_tasktemplates_am_projecttemplatesam_projecttemplates_ida` varchar(36) DEFAULT NULL,
  `am_tasktemplates_am_projecttemplatesam_tasktemplates_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `am_tasktemplates_am_projecttemplates_ida1` (`am_tasktemplates_am_projecttemplatesam_projecttemplates_ida`),
  KEY `am_tasktemplates_am_projecttemplates_alt` (`am_tasktemplates_am_projecttemplatesam_tasktemplates_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`am_tasktemplates_audit`utf8_general_ci	;
CREATE TABLE `am_tasktemplates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_am_tasktemplates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aobh_businesshours`utf8_general_ci	;
CREATE TABLE `aobh_businesshours` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `opening_hours` varchar(100) DEFAULT '1',
  `closing_hours` varchar(100) DEFAULT '1',
  `open` tinyint(1) DEFAULT NULL,
  `day` varchar(100) DEFAULT 'monday',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aod_index`utf8_general_ci	;
CREATE TABLE `aod_index` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `last_optimised` datetime DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`aod_index`utf8_general_ci	;
INSERT INTO `aod_index` VALUES 
('1','Index','2017-05-24 10:52:17','2017-05-24 10:52:17','1','1',\N,0,\N,\N,'modules/AOD_Index/Index/Index')	;
#	TC`aod_index_audit`utf8_general_ci	;
CREATE TABLE `aod_index_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aod_index_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aod_indexevent`utf8_general_ci	;
CREATE TABLE `aod_indexevent` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  `success` tinyint(1) DEFAULT '0',
  `record_id` char(36) DEFAULT NULL,
  `record_module` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_record_module` (`record_module`),
  KEY `idx_record_id` (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`aod_indexevent`utf8_general_ci	;
INSERT INTO `aod_indexevent` VALUES 
('108496bb-4fa1-1a59-6a78-5927e621c70b','Общество с ограниченной ответственностью «Эффективные технологии»','2017-05-26 08:26:49','2017-05-29 12:27:50','1','1',\N,0,'',\N,1,'f1c17d43-b29f-16ef-5774-5927e6b4501a','Accounts'),
('1ef5cc1d-e67d-8962-0225-5927e5aaa735','Семён Антонов','2017-05-26 08:23:21','2017-05-29 04:39:59','1','1',\N,0,'',\N,1,'e41e39af-5bdc-0b83-c659-5927e5a9adf7','Contacts'),
('575a9f17-74de-3459-4ecf-592bde3bc9a3','Общество с ограниченной ответственностью «Аста»','2017-05-29 08:41:04','2017-05-29 11:53:57','1','1',\N,0,'',\N,1,'2a8faeef-e265-daa3-6127-592bdec3ef7b','Accounts'),
('5fd345d1-5289-b282-bd25-592c13624ff1','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','2017-05-29 12:27:56','2017-05-29 12:27:56','1','1',\N,0,\N,\N,1,'530d26be-3d65-0f98-e3ce-592c13cd8158','Notes'),
('6747c645-dedb-78dd-c2e4-59272dca0930','443068, г. Самара, ул. Ново-Садовая, д. 106, оф. 613','2017-05-25 19:16:57','2017-05-25 19:21:26','1','1',\N,0,'',\N,1,'55092ca4-45ce-f10f-c85d-59272dbd7b35','dp_realty'),
('715cfdcd-3163-8148-4bc7-592c0fe6e575','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','2017-05-29 12:11:04','2017-05-29 12:11:04','1','1',\N,0,\N,\N,1,'5825988b-e9b6-a0bf-09b1-592c0f8b7bf9','Notes'),
('77960048-1922-5150-7b01-592be3afef89','Юрий Марянин','2017-05-29 09:00:55','2017-05-29 09:00:55','1','1',\N,0,\N,\N,1,'c8548377-e295-926c-28ff-592be34c26d7','Contacts'),
('9f0c5914-798b-3f08-6cb1-592c0be9c351','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','2017-05-29 11:54:38','2017-05-29 11:54:38','1','1',\N,0,\N,\N,1,'8a1a7600-d24c-a635-6013-592c0b1262af','Notes'),
('b8e9099d-16bc-5f9c-0d9b-592ba18bedbb','632107606114','2017-05-29 04:18:47','2017-05-29 04:25:45','1','1',\N,0,'',\N,1,'aa75ec99-cd50-76a4-2f02-592ba18917bd','dp_founder_fl'),
('ba903166-32cf-0594-00b2-592bd2b732af','Игорь Трофимычев','2017-05-29 07:49:28','2017-05-29 07:49:28','1','1',\N,0,\N,\N,1,'9f4c2908-47c8-e20c-5f36-592bd28fd104','Contacts'),
('d33cb93f-01f4-c838-89ba-5925713e42ae','Общество с ограниченной ответственностью «Солнечная долина»','2017-05-24 11:42:01','2017-05-29 08:15:21','1','1',\N,0,'',\N,1,'b9f49b4f-21dc-4a20-5646-592571b11c40','Accounts'),
('dd92d96c-96f4-a95d-2a55-5926d365a66d','Российский капитал','2017-05-25 12:54:05','2017-05-25 12:54:05','1','1',\N,0,\N,\N,1,'cc7ac549-b341-f38a-0bdc-5926d3163ea2','dp_bkrv')	;
#	TC`aod_indexevent_audit`utf8_general_ci	;
CREATE TABLE `aod_indexevent_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aod_indexevent_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledge_base_categories`utf8_general_ci	;
CREATE TABLE `aok_knowledge_base_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledge_base_categories_audit`utf8_general_ci	;
CREATE TABLE `aok_knowledge_base_categories_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aok_knowledge_base_categories_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledgebase`utf8_general_ci	;
CREATE TABLE `aok_knowledgebase` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Draft',
  `revision` varchar(255) DEFAULT NULL,
  `additional_info` text,
  `user_id_c` char(36) DEFAULT NULL,
  `user_id1_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledgebase_audit`utf8_general_ci	;
CREATE TABLE `aok_knowledgebase_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aok_knowledgebase_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aok_knowledgebase_categories`utf8_general_ci	;
CREATE TABLE `aok_knowledgebase_categories` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aok_knowledgebase_id` varchar(36) DEFAULT NULL,
  `aok_knowledge_base_categories_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aok_knowledgebase_categories_alt` (`aok_knowledgebase_id`,`aok_knowledge_base_categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_events`utf8_general_ci	;
CREATE TABLE `aop_case_events` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_events_audit`utf8_general_ci	;
CREATE TABLE `aop_case_events_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aop_case_events_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_updates`utf8_general_ci	;
CREATE TABLE `aop_case_updates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `internal` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aop_case_updates_audit`utf8_general_ci	;
CREATE TABLE `aop_case_updates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aop_case_updates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_charts`utf8_general_ci	;
CREATE TABLE `aor_charts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aor_report_id` char(36) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `x_field` int(11) DEFAULT NULL,
  `y_field` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_conditions`utf8_general_ci	;
CREATE TABLE `aor_conditions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aor_report_id` char(36) DEFAULT NULL,
  `condition_order` int(255) DEFAULT NULL,
  `logic_op` varchar(255) DEFAULT NULL,
  `parenthesis` varchar(255) DEFAULT NULL,
  `module_path` longtext,
  `field` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `value_type` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `parameter` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aor_conditions_index_report_id` (`aor_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_fields`utf8_general_ci	;
CREATE TABLE `aor_fields` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aor_report_id` char(36) DEFAULT NULL,
  `field_order` int(255) DEFAULT NULL,
  `module_path` longtext,
  `field` varchar(100) DEFAULT NULL,
  `display` tinyint(1) DEFAULT NULL,
  `link` tinyint(1) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `field_function` varchar(100) DEFAULT NULL,
  `sort_by` varchar(100) DEFAULT NULL,
  `format` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `sort_order` varchar(100) DEFAULT NULL,
  `group_by` tinyint(1) DEFAULT NULL,
  `group_order` varchar(100) DEFAULT NULL,
  `group_display` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aor_fields_index_report_id` (`aor_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_reports`utf8_general_ci	;
CREATE TABLE `aor_reports` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `report_module` varchar(100) DEFAULT NULL,
  `graphs_per_row` int(11) DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_reports_audit`utf8_general_ci	;
CREATE TABLE `aor_reports_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aor_reports_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aor_scheduled_reports`utf8_general_ci	;
CREATE TABLE `aor_scheduled_reports` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `schedule` varchar(100) DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `email_recipients` longtext,
  `aor_report_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_contracts`utf8_general_ci	;
CREATE TABLE `aos_contracts` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `reference_code` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `total_contract_value` decimal(26,6) DEFAULT NULL,
  `total_contract_value_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `customer_signed_date` date DEFAULT NULL,
  `company_signed_date` date DEFAULT NULL,
  `renewal_reminder_date` datetime DEFAULT NULL,
  `contract_type` varchar(100) DEFAULT 'Type',
  `contract_account_id` char(36) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `call_id` char(36) DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_contracts_audit`utf8_general_ci	;
CREATE TABLE `aos_contracts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_contracts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_contracts_documents`utf8_general_ci	;
CREATE TABLE `aos_contracts_documents` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_contracts_id` varchar(36) DEFAULT NULL,
  `documents_id` varchar(36) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_contracts_documents_alt` (`aos_contracts_id`,`documents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_invoices`utf8_general_ci	;
CREATE TABLE `aos_invoices` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `billing_account_id` char(36) DEFAULT NULL,
  `billing_contact_id` char(36) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `quote_number` int(11) DEFAULT NULL,
  `quote_date` date DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `template_ddown_c` text,
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_invoices_audit`utf8_general_ci	;
CREATE TABLE `aos_invoices_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_invoices_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_line_item_groups`utf8_general_ci	;
CREATE TABLE `aos_line_item_groups` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_line_item_groups_audit`utf8_general_ci	;
CREATE TABLE `aos_line_item_groups_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_line_item_groups_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_pdf_templates`utf8_general_ci	;
CREATE TABLE `aos_pdf_templates` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `type` varchar(100) DEFAULT NULL,
  `pdfheader` text,
  `pdffooter` text,
  `margin_left` int(255) DEFAULT '15',
  `margin_right` int(255) DEFAULT '15',
  `margin_top` int(255) DEFAULT '16',
  `margin_bottom` int(255) DEFAULT '16',
  `margin_header` int(255) DEFAULT '9',
  `margin_footer` int(255) DEFAULT '9',
  `page_size` varchar(100) DEFAULT NULL,
  `orientation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`aos_pdf_templates`utf8_general_ci	;
INSERT INTO `aos_pdf_templates` VALUES 
('72f147d5-888a-1986-5d4f-592c0436e1a4','2136 АНКЕТА ПРИНЦИПАЛА без открытия счета (с 15.09.15)','2017-05-29 11:24:29','2017-05-29 12:27:43','1','1','<p align=\"right\"> </p>\n<p> </p>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td width=\"295\">\n<p align=\"center\"><strong>Все пункты анкеты подлежат обязательному заполнению</strong></p>\n</td>\n</tr>\n</tbody>\n</table>\n<p align=\"center\"><strong> </strong></p>\n<p align=\"center\"><strong>АНКЕТА КЛИЕНТА - ЮРИДИЧЕСКОГО ЛИЦА </strong></p>\n<p align=\"center\"><strong> (ЗАЕМЩИКА/ ПРИНЦИПАЛА/ЗАЛОГОДАТЕЛЯ/ ПОРУЧИТЕЛЯ – нужное подчеркнуть)</strong></p>\n<p class=\"Iiiaeuiue\" align=\"center\"><strong> </strong></p>\n<table style=\"width: 741px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"top\" width=\"184\">\n<p><strong>Полное наименование организации</strong></p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"557\">\n<p>$accounts_name</p>\n<p><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"184\">\n<p><strong>Краткое наименование организации</strong></p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"557\">\n<p>$accounts_shname</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"184\">\n<p>Адрес юридического лица в соответствии с учредительными документами:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"557\">\n<p>$accounts_billing_address_postalcode $accounts_billing_address_country $accounts_ur_locality_fact $accounts_billing_address_state $accounts_ur_area_fact $accounts_billing_address_city $accounts_billing_address_street $accounts_ur_house $accounts_ur_structure</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"184\">\n<p>Адрес обособленного подразделения:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"557\">\n<p> </p>\n<p>Нет</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"184\">\n<p>Телефон, телефакс:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"557\">\n<p>$accounts_phone_office, $accounts_phone_alternate, $accounts_phone_fax</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"184\">\n<p>Страница в Интернете (адрес):</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"557\">\n<p>Нет</p>\n</td>\n</tr>\n<tr>\n<td rowspan=\"4\" valign=\"top\" width=\"184\">\n<p> </p>\n<p> </p>\n<p> </p>\n<p>Сведения о расчетных (валютных) счетах в банках</p>\n</td>\n<td valign=\"top\" width=\"222\">\n<p align=\"center\">Наименование банка</p>\n</td>\n<td valign=\"top\" width=\"182\">\n<p align=\"center\">Номер счета</p>\n</td>\n<td valign=\"top\" width=\"153\">\n<p align=\"center\">Наличие картотеки к счету (при наличии указать сумму и дату возникновения)</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"222\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"182\">\n<p>{=C43}</p>\n</td>\n<td valign=\"top\" width=\"153\">\n<p>Нет</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"222\">\n<p>{=C50}</p>\n</td>\n<td valign=\"top\" width=\"182\">\n<p>{=C47}</p>\n</td>\n<td valign=\"top\" width=\"153\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"222\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"182\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"153\">\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p align=\"center\"><strong><em>1. Учредительные и регистрационные данные об организации</em></strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>Дата регистрации организации:</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>{=C15}</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"5\" valign=\"top\" width=\"737\">\n<p>Основные идентификационные номера и коды:</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>ОГРН с указанием даты внесения в реестр</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>$accounts_ogrn, $accounts_date_gosreg</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>ИНН</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>$accounts_inn</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>КПП</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>$accounts_kpp</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>ОКПО</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>ОКВЭД (основной)</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>{=C12}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>Размер уставного капитала:</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>{=C151}</p>\n</td>\n</tr>\n<tr>\n<td rowspan=\"3\" valign=\"top\" width=\"174\">\n<p>Участники (акционеры) с указанием бенефициарного собственника:</p>\n</td>\n<td valign=\"top\" width=\"188\">\n<p align=\"center\">Полное наименование участника/акционера</p>\n<p align=\"center\">(Ф.И.О. - для физических лиц, резидент/нерезидент)</p>\n</td>\n<td valign=\"top\" width=\"156\">\n<p align=\"center\">ИНН, ОГРН, местонахождение (для юр. лиц) / реквизиты документа, удостоверяющего личность, адрес места жительства (для физ. лиц)</p>\n</td>\n<td valign=\"top\" width=\"88\">\n<p align=\"center\">Размер доли УК (кол-во акций), %</p>\n</td>\n<td valign=\"top\" width=\"130\">\n<p align=\"center\">Участие акционеров в управлении (активное/ не активное/ не участвуют)</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"188\">\n<p>{=C154} {=C155} {=C156} Резидент</p>\n</td>\n<td valign=\"top\" width=\"156\">\n<p>{=C157}</p>\n</td>\n<td valign=\"top\" width=\"88\">\n<p>{=C188}</p>\n</td>\n<td valign=\"top\" width=\"130\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"188\">\n<p>{=C193} {=C194} {=C195} Резидент</p>\n</td>\n<td valign=\"top\" width=\"156\">\n<p>{=C196}</p>\n</td>\n<td valign=\"top\" width=\"88\">\n<p>{=C227}</p>\n</td>\n<td valign=\"top\" width=\"130\">\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"5\" valign=\"top\" width=\"737\">\n<p><strong><em>Руководитель организации, заместители руководителя, главный бухгалтер, заместитель главного бухгалтера:</em></strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p align=\"center\"><strong><em>Должность</em></strong></p>\n</td>\n<td valign=\"top\" width=\"173\">\n<p align=\"center\"><strong><em>ФИО (полностью)</em></strong></p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"390\">\n<p align=\"center\"><strong><em>Реквизиты документа, удостоверяющего личность, адрес места жительства (регистрации, фактического места жительства)</em></strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>{=C59}</p>\n</td>\n<td valign=\"top\" width=\"173\">\n<p>{=C60} {=C61} {=C62}</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"390\">\n<p>{=C82} {=C81} {=C82} {=C83} {=C84} {=C85} {=C86} {=C87} {=C88} {=C89} {=C90}</p>\n<p>{=C91} {=C92} {=C93} {=C94} {=C95} {=C96} {=C97} {=C98} {=C99} {=C100} {=C101}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>{=C105}</p>\n</td>\n<td valign=\"top\" width=\"173\">\n<p>{=C106} {=C107} {=C108}</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"390\">\n<p>{=C126} {=C127} {=C128} {=C129} {=C130} {=C131} {=C132} {=C133} {=C134} {=C135} {=C136}</p>\n<p>{=C137} {=C138} {=C139} {=C140} {=C141} {=C142} {=C143} {=C144} {=C145} {=C146} {=C147}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"173\">\n<p> </p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"390\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"173\">\n<p> </p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"390\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td rowspan=\"5\" valign=\"top\" width=\"174\">\n<p>Участие в других организациях и/или совместная деятельность с другими организациями:</p>\n</td>\n<td colspan=\"2\" valign=\"top\" width=\"206\">\n<p align=\"center\">наименование организации, ИНН, ОГРН</p>\n</td>\n<td valign=\"top\" width=\"181\">\n<p align=\"center\">вид деятельности</p>\n</td>\n<td valign=\"top\" width=\"176\">\n<p align=\"center\">Величина уставного капитала/ доля участия организации</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"206\">\n<p>Нет</p>\n</td>\n<td valign=\"top\" width=\"181\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"176\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"206\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"181\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"176\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"206\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"181\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"176\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"206\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"181\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"176\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>Вхождение организации в Группу компаний/Холдинг (в том числе неформальный)</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>Нет</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"174\">\n<p>Численность работников</p>\n<p> </p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"563\">\n<p>Всего работников: ____</p>\n<p>Фонд оплаты труда: ________________________________ рублей.</p>\n</td>\n</tr>\n<tr>\n<td width=\"174\"> </td>\n<td width=\"173\"> </td>\n<td width=\"33\"> </td>\n<td width=\"181\"> </td>\n<td width=\"176\"> </td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"4\" width=\"737\">\n<p align=\"center\"><strong><em>2. Общие сведения о деятельности организации</em></strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p>Основные виды деятельности (в том числе лицензируемые с указанием наличия лицензий/свидетельств СРО):</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"491\">\n<p>{=C12}</p>\n</td>\n</tr>\n<tr>\n<td width=\"246\">\n<p>Отнесение организации к отрасли:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"491\">\n<p><input type=\"checkbox\" />   Торговля   <input type=\"checkbox\" />   Транспорт     <input type=\"checkbox\" />   Финансовая деятельность   <input type=\"checkbox\" />  Промышленность</p>\n<p><input type=\"checkbox\" />   Строительство  <input type=\"checkbox\" />   ВПК  <input type=\"checkbox\" checked=\"checked\" />   Иная (указать) {=C12}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p>Данные о регионах деятельности организации (с указанием наименования региона и доли в общем объеме реализации):</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"491\">\n<p>Российская Федерация, Самарская область 63</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p>Продолжительность работы на рынке по основному виду деятельности:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"491\">\n<p>С {=C15}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p>Наличие / отсутствие сезонности продаж с указанием периодов % изменения объемов реализации:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"491\">\n<p>Отсутствует</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p><strong><em>Работа предприятия по государственным контрактам</em></strong></p>\n</td>\n<td valign=\"top\" width=\"166\">\n<p align=\"center\">201_</p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p align=\"center\">201_ (предыдущий год)</p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p align=\"center\">Текущий год</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p>Сколько процентов составляют госконтракты в общем объеме выручки(%)</p>\n</td>\n<td valign=\"top\" width=\"166\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p>Количество заключенных госконтрактов</p>\n</td>\n<td valign=\"top\" width=\"166\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"246\">\n<p> Общий объем заключенных госконтрактов (тыс. рублей)</p>\n</td>\n<td valign=\"top\" width=\"166\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"163\">\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p align=\"center\"><strong><em>3. Сведения об имуществе организации, находящемся в собственности  и/или в аренде/субаренде</em></strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p><strong>Сведения о недвижимом имуществе организации, находящейся в собственности и/или в аренде/субаренде</strong></p>\n</td>\n</tr>\n<tr>\n<td width=\"78\">\n<p align=\"center\">Тип объекта (жилое, нежилое, помещение, офис, склад и т.д.)</p>\n</td>\n<td width=\"191\">\n<p align=\"center\">Адрес местонахождения</p>\n</td>\n<td width=\"62\">\n<p align=\"center\">Площадь (кв. м.)</p>\n</td>\n<td valign=\"top\" width=\"198\">\n<p align=\"center\">№ и Дата Свидетельства о регистрации права собственности  <em>(если собственность) или </em></p>\n<p align=\"center\">№ и Дата Договора аренды/субаренды <em>(если аренда</em><em>)</em></p>\n</td>\n<td width=\"208\">\n<p align=\"center\">Примечание</p>\n<p align=\"center\"><em>При собственности недвижимости </em>– указать использование я (сдача в аренду, использование по собственному назначению и т.д.)</p>\n<p align=\"center\"><em>При аренде/субаренде недвижимости</em> - указать арендодателя и срок аренды</p>\n</td>\n</tr>\n<tr>\n<td width=\"78\">\n<p>{=C54}</p>\n</td>\n<td width=\"191\">\n<p align=\"center\">{=C51}</p>\n</td>\n<td width=\"62\">\n<p>{=C53}</p>\n</td>\n<td width=\"198\">\n<p align=\"center\">{=C55} {=C56} {=C57}</p>\n</td>\n<td width=\"208\">\n<p align=\"center\">Аренда до</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"16\" valign=\"top\" width=\"737\">\n<p align=\"center\"><strong><em>4. Финансовые показатели</em></strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"16\" valign=\"top\" width=\"737\">\n<p><strong>Сведения о действующих кредитах банков на дату составления Анкеты:</strong></p>\n</td>\n</tr>\n<tr>\n<td width=\"113\">\n<p align=\"center\">Наименование Банка-кредитора</p>\n</td>\n<td colspan=\"3\" width=\"85\">\n<p align=\"center\">Сумма кредита по Договору</p>\n</td>\n<td width=\"104\">\n<p align=\"center\">Сумма задолженности на дату заполнения Анкеты</p>\n</td>\n<td colspan=\"3\" width=\"48\">\n<p align=\"center\">% ставка</p>\n</td>\n<td width=\"76\">\n<p align=\"center\">Дата выдачи</p>\n</td>\n<td colspan=\"3\" width=\"76\">\n<p align=\"center\">Дата возврата</p>\n</td>\n<td colspan=\"3\" width=\"132\">\n<p align=\"center\">Обеспечение (с указанием залогодателя)</p>\n</td>\n<td width=\"104\">\n<p align=\"center\">Наличие просроченных платежей</p>\n</td>\n</tr>\n<tr>\n<td width=\"113\">\n<p align=\"center\">Нет</p>\n</td>\n<td colspan=\"3\" width=\"85\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"48\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"132\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td width=\"113\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"85\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"48\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"132\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td width=\"113\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"85\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"48\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"132\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td width=\"113\">\n<p>Итого</p>\n</td>\n<td colspan=\"3\" width=\"85\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"48\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"76\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"132\">\n<p align=\"center\"> </p>\n</td>\n<td width=\"104\">\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"16\" width=\"737\">\n<p><strong>Заёмные средства (кроме банков) на дату составления Анкеты:</strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p align=\"center\">Организация/физическое лицо</p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p align=\"center\">Сумма предоставленных средств</p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p align=\"center\">Остаток на дату составления Анкеты</p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\">Дата предоставления</p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p align=\"center\">Дата погашения</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p align=\"center\">Нет</p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"> </p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p>Итого</p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p> </p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p> </p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p> </p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"16\" valign=\"top\" width=\"737\">\n<p><strong>Полученные гарантии на дату составления Анкеты:</strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" valign=\"top\" width=\"170\">\n<p align=\"center\">Наименование Банка-гаранта</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"149\">\n<p align=\"center\">Наименование бенефициара</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"149\">\n<p align=\"center\">Сумма гарантии</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"136\">\n<p align=\"center\">Срок действия</p>\n</td>\n<td colspan=\"2\" valign=\"top\" width=\"133\">\n<p align=\"center\">Предмет гарантии</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p align=\"center\"><strong>Нет</strong></p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"3\" width=\"170\">\n<p>Итого</p>\n</td>\n<td colspan=\"3\" width=\"149\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"149\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"2\" width=\"133\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"16\" valign=\"top\" width=\"737\">\n<p><strong>Выданные поручительства, предоставленные залоги в обеспечение исполнения обязательств третьими лицами на дату составления Анкеты:</strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" width=\"169\">\n<p align=\"center\">Вид предоставленного обеспечения</p>\n</td>\n<td colspan=\"5\" width=\"170\">\n<p align=\"center\">За кого предоставлено обеспечение</p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\">В пользу кого</p>\n</td>\n<td colspan=\"2\" width=\"101\">\n<p align=\"center\">Сумма обеспечения</p>\n</td>\n<td colspan=\"3\" width=\"161\">\n<p align=\"center\">Дата окончания обязательства</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" width=\"169\">\n<p align=\"center\"><strong>Нет</strong></p>\n</td>\n<td colspan=\"5\" width=\"170\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"2\" width=\"101\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"3\" width=\"161\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" width=\"169\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"5\" width=\"170\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"4\" width=\"136\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"2\" width=\"101\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td colspan=\"3\" width=\"161\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td width=\"113\"> </td>\n<td width=\"56\"> </td>\n<td width=\"1\"> </td>\n<td width=\"28\"> </td>\n<td width=\"104\"> </td>\n<td width=\"18\"> </td>\n<td width=\"20\"> </td>\n<td width=\"10\"> </td>\n<td width=\"76\"> </td>\n<td width=\"44\"> </td>\n<td width=\"6\"> </td>\n<td width=\"26\"> </td>\n<td width=\"75\"> </td>\n<td width=\"29\"> </td>\n<td width=\"29\"> </td>\n<td width=\"104\"> </td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"4\" valign=\"top\" width=\"737\">\n<p><strong>Инвестиционная деятельность – финансовые вложения, ценные бумаги, уставный капитал других организаций, представление другим организациям займов:</strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"198\">\n<p align=\"center\">Форма инвестиций</p>\n</td>\n<td valign=\"top\" width=\"321\">\n<p align=\"center\">Наименование объекта инвестирования</p>\n</td>\n<td valign=\"top\" width=\"110\">\n<p align=\"center\">Балансовая стоимость, тыс.руб.</p>\n</td>\n<td valign=\"top\" width=\"107\">\n<p align=\"center\">Рыночная стоимость, тыс.руб.</p>\n</td>\n</tr>\n<tr>\n<td width=\"198\">\n<p align=\"center\"><strong>Нет</strong></p>\n</td>\n<td width=\"321\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td width=\"110\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td width=\"107\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td width=\"198\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td width=\"321\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td width=\"110\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n<td width=\"107\">\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p align=\"center\"><strong><em>6. Прочие сведения об организации</em></strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"250\">\n<p>Наличие задолженности по оплате труда</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"487\">\n<p> <input type=\"checkbox\" />   Текущая задолженность. С указанием суммы _________________</p>\n<p> <input type=\"checkbox\" />   Просроченная задолженность. С указанием суммы _________________</p>\n<p> <input type=\"checkbox\" checked=\"checked\" />   Отсутствие задолженности</p>\n</td>\n</tr>\n<tr>\n<td rowspan=\"3\" valign=\"top\" width=\"250\">\n<p>Наличие просроченной задолженности по налогам и сборам (в случае наличия)</p>\n</td>\n<td colspan=\"2\" valign=\"top\" width=\"172\">\n<p align=\"center\">Вид налога</p>\n</td>\n<td valign=\"top\" width=\"186\">\n<p align=\"center\">Сумма задолженности, в рублях</p>\n</td>\n<td valign=\"top\" width=\"129\">\n<p align=\"center\">Дата возникновения</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"172\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"186\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"129\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"172\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"186\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"129\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"250\">\n<p>Сведения об аресте расчетных и текущих валютных счетов (с указанием банка и суммы):</p>\n</td>\n<td colspan=\"4\" width=\"487\">\n<p>Нет</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"250\">\n<p><strong>Наличие выгодоприобретателя</strong>(лицо, к выгоде которого действует клиент, в том числе на основании агентского договора, договоров поручения, комиссии и доверительного управления, при проведении операций с денежными средствами и иным имуществом)</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"487\">\n<p> </p>\n<p><input type=\"checkbox\" /> Да* (имеется)                             <input type=\"checkbox\" checked=\"checked\" /> Нет (отсутствует)</p>\n<p><input type=\"checkbox\" /> юридическое лицо</p>\n<p><input type=\"checkbox\" /> индивидуальный предприниматель</p>\n<p><input type=\"checkbox\" /> физическое лицо</p>\n<p> </p>\n<p>* Требуется заполнение сведений о выгодоприобретателе</p>\n<p> </p>\n</td>\n</tr>\n<tr>\n<td width=\"250\">\n<p><strong>Наличие бенефициарного владельца</strong></p>\n<p>(физическое лицо, которое в конечном счете прямо или косвенно (через третьих лиц) владеет (имеет преобладающее участие более 25 процентов в капитале) юридическим лицом либо имеет возможность контролировать действия клиента)</p>\n</td>\n<td colspan=\"4\" valign=\"top\" width=\"487\">\n<p> </p>\n<p><input type=\"checkbox\" checked=\"checked\" /> Да* (имеется)       </p>\n<p> </p>\n<p> Нет (отсутствует)  </p>\n<p> </p>\n<p>* Требуется заполнение сведений о бенефициарном владельце</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p align=\"center\"><strong>Сведения</strong></p>\n<p align=\"center\"><strong>о бенефициарном владельце</strong></p>\n<p> </p>\n<table style=\"width: 720px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"top\" width=\"369\">\n<p>Бенефициарный владелец – физическое лицо, которое в конечном счете прямо или косвенно (через третьих лиц) владеет (имеет преобладающее участие более 25 процентов в капитале) юридическим лицом либо имеет возможность контролировать действия клиента </p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p align=\"center\">Основания:</p>\n<table style=\"width: 274px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"28\">\n<p> <input type=\"checkbox\" /></p>\n</td>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"246\">\n<p><input type=\"checkbox\" checked=\"checked\" /> владение прямо или косвенно</p>\n<p><input type=\"checkbox\" /> более 25% в УК клиента</p>\n</td>\n</tr>\n<tr>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"28\">\n<p> </p>\n</td>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"246\">\n<p><input type=\"checkbox\" />Возможность контролировать действия клиента</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p align=\"center\"> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p><strong> </strong></p>\n<table style=\"width: 720px;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">1.</p>\n</td>\n<td valign=\"top\" width=\"321\">\n<p>Фамилия, имя и отчество (если иное не вытекает из закона или национального обычая)</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C154} {=C155} {=C156}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">2.</p>\n</td>\n<td valign=\"top\" width=\"321\">\n<p>Дата рождения</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C185}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">3.</p>\n</td>\n<td valign=\"top\" width=\"321\">\n<p>Место рождения</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C186}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">4.</p>\n</td>\n<td valign=\"top\" width=\"321\">\n<p>Гражданство (подданство)</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>РФ</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">5.</p>\n</td>\n<td width=\"321\">\n<p>Реквизиты документа удостоверяющего личность:</p>\n<ul>\n<li>наименование документа,</li>\n<li>серия  и  номер,</li>\n<li>орган, выдавший  документ,</li>\n<li>дата   выдачи документа,</li>\n<li>код подразделения (если имеется).     </li>\n</ul>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C180} {=C181} {=C182} {=C183} к\\п {=C184}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">6.</p>\n</td>\n<td width=\"321\">\n<p>Данные миграционной карты иностранного гражданина или лица без гражданства:</p>\n<ul>\n<li>номер карты,</li>\n<li>дата начала срока пребывания и дата окончания срока пребывания</li>\n</ul>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>Нет</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">7.</p>\n</td>\n<td width=\"321\">\n<p>Данные документа, подтверждающего право иностранного гражданина или лица без гражданства  на пребывание (проживание) в РФ (если имеется)</p>\n<ul>\n<li>вид на жительство</li>\n<li>виза</li>\n<li>разрешение на временное проживание</li>\n</ul>\n<p>(иной подтверждающий документ)</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p> </p>\n<table style=\"width: 266px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"266\">\n<div>\n<p>Нет</p>\n</div>\n<p align=\"center\"><em>(наименование)</em></p>\n<p>Серия (если имеется)____________, №____________________________</p>\n<p> </p>\n<p>Действует</p>\n<p>с «______»______________20______г.</p>\n<p>по «______»________________20____г.</p>\n<p> </p>\n<p>Выдан_________________________</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p align=\"center\"> </p>\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">8.</p>\n</td>\n<td width=\"321\">\n<p>Адрес места жительства (регистрации)</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C159} {=C160} {=C161} {=C162} {=C163} {=C164} {=C165} {=C166} {=C167} {=C168}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">9.</p>\n</td>\n<td width=\"321\">\n<p>Адрес фактического места жительства</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C159} {=C160} {=C161} {=C162} {=C163} {=C164} {=C165} {=C166} {=C167} {=C168}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">10.</p>\n</td>\n<td width=\"321\">\n<p>Адрес места пребывания</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C159} {=C160} {=C161} {=C162} {=C163} {=C164} {=C165} {=C166} {=C167} {=C168}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">11.</p>\n</td>\n<td width=\"321\">\n<p>Номера контактных телефонов</p>\n<p>(при наличии)</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C190} {=C191}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">12.</p>\n</td>\n<td width=\"321\">\n<p>Идентификационный номер налогоплательщика (если имеется)</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<p>{=C157}</p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"47\">\n<p align=\"right\">13.</p>\n</td>\n<td width=\"321\">\n<p> Является ли бенефициарный владелец ПДЛ, лицом, связанным с ПДЛ</p>\n</td>\n<td valign=\"top\" width=\"352\">\n<table style=\"width: 274px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"28\">\n<p> </p>\n</td>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"246\">\n<p><input type=\"checkbox\" /> ДА</p>\n</td>\n</tr>\n<tr>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"28\">\n<p> <input type=\"checkbox\" /></p>\n</td>\n<td valign=\"bottom\" nowrap=\"nowrap\" width=\"246\">\n<p><input type=\"checkbox\" checked=\"checked\" /> НЕТ</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<p><strong>            </strong>Помимо данных, указанных в настоящем документе, иных сведений о бенефициарном владельце не имею. Достоверность вышеуказанной информации подтверждаю.</p>\n<p> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"5\" valign=\"top\" width=\"737\">\n<p align=\"center\"><strong>ЗАПОЛНЯЕТСЯ РАБОТНИКОМ БАНКА</strong></p>\n<p>Обстоятельства и причины невозможности выявления бенефициарного владельца клиента:</p>\n<div>\n<p> </p>\n</div>\n<div>\n<p> </p>\n<p> </p>\n<p>                                      </p>\n</div>\n<p>Отметка Банка:</p>\n<p> </p>\n<div>\n<p> </p>\n</div>\n<div>\n<p> </p>\n</div>\n<p>Работник Банка, проводивший процедуру идентификации</p>\n<p>_________________________                         ________________/_____________________/    </p>\n<p> (Должность)                                                                  (подпись)                                      (Ф.И.О.)</p>\n<p align=\"center\">«____»___________20__.</p>\n<p align=\"center\"> </p>\n<p align=\"center\"> </p>\n<p align=\"center\"> </p>\n</td>\n</tr>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p align=\"center\"><strong> </strong></p>\n<p align=\"center\"><strong>Цели установления и предполагаемый характер деловых отношений с Банком</strong></p>\n</td>\n</tr>\n<tr>\n<td colspan=\"5\" width=\"737\">\n<p><input type=\"checkbox\" checked=\"checked\" /> краткосрочный характер (менее 6 месяцев) среднесрочный характер (до 1-го года) долгосрочный характер (1 год и более)</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" width=\"340\">\n<p><input type=\"checkbox\" /> безналичные расчеты в рублях</p>\n<p><input type=\"checkbox\" /> покупка/продажа валюты</p>\n<p><input type=\"checkbox\" /> международные расчеты</p>\n<p><input type=\"checkbox\" /> прием наличных денег в кассу банка</p>\n<p><input type=\"checkbox\" /> выдача наличных денег по чеку</p>\n<p><input type=\"checkbox\" /> инкассация/доставка денежной наличности</p>\n<p><input type=\"checkbox\" /> система «Клиент-Банк»</p>\n<p><input type=\"checkbox\" /> размещение средств в депозит</p>\n<p> </p>\n</td>\n<td colspan=\"3\" width=\"397\">\n<p><input type=\"checkbox\" /> неснижаемый остаток на счете</p>\n<p><input type=\"checkbox\" /> ценные бумаги КБ «Экономикс-Банк» (ООО)</p>\n<p><input type=\"checkbox\" /> кредитование</p>\n<p><input type=\"checkbox\" /> лизинг</p>\n<p><input type=\"checkbox\" /> «зарплатный» проект</p>\n<p><input type=\"checkbox\" /> эквайринг</p>\n<p><input type=\"checkbox\" />            документарные операции (гарантии, аккредитивы, инкассо)</p>\n<p>иное (указать) __________________________________</p>\n</td>\n</tr>\n<tr>\n<td width=\"250\"> </td>\n<td width=\"90\"> </td>\n<td width=\"82\"> </td>\n<td width=\"186\"> </td>\n<td width=\"129\"> </td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<p>  </p>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td valign=\"top\" width=\"737\">\n<p align=\"center\"><strong>Цели финансово-хозяйственной деятельности</strong></p>\n<p align=\"center\"><strong> </strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"737\">\n<p><input type=\"checkbox\" checked=\"checked\" />    получение доходов от основной деятельности;</p>\n<p><input type=\"checkbox\" /> осуществление финансовых сделок (кредиты, инвестиции, депозиты);</p>\n<p><input type=\"checkbox\" /> оплата расходов, связанных с основной деятельностью ( в том числе оплата услуг/товаров, расходов хозяйственного характера, заработная плата, налоги и др.);</p>\n<p><input type=\"checkbox\" /> иное.</p>\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<table style=\"width: 737px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"4\" width=\"737\">\n<p><strong>Информация о наличии текущих судебных разбирательств в отношении организации/собственников бизнеса/аффилированных компаний: Нет</strong></p>\n</td>\n</tr>\n<tr>\n<td width=\"94\">\n<p> </p>\n</td>\n<td valign=\"top\" width=\"104\">\n<p align=\"center\"><em>Сумма иска (общая сумма исковых требований), руб.</em></p>\n</td>\n<td valign=\"top\" width=\"224\">\n<p align=\"center\"><em>Краткое содержание искового требования</em></p>\n</td>\n<td valign=\"top\" width=\"315\">\n<p align=\"center\"><em>Дата начала судебного процесса/ Стадии судебного процесса /Решение суда/Обеспечительные меры, наложенные судом</em></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"94\">\n<p>Организация как ответчик</p>\n</td>\n<td width=\"104\">\n<p> </p>\n</td>\n<td width=\"224\">\n<p> </p>\n</td>\n<td width=\"315\">\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"94\">\n<p>Организация как истец</p>\n</td>\n<td width=\"104\">\n<p> </p>\n</td>\n<td width=\"224\">\n<p> </p>\n</td>\n<td width=\"315\">\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> <strong> </strong></p>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"737\">\n<p align=\"center\"><strong>Сведения о деловой репутации</strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"586\">\n<p>Имеются ли отзывы о юридическом лице других клиентов КБ «Экономикс-Банк» (ООО)</p>\n</td>\n<td valign=\"top\" width=\"151\">\n<p><input type=\"checkbox\" /> Да</p>\n<p><input type=\"checkbox\" checked=\"checked\" /> Нет</p>\n<p> </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"586\">\n<p>Имеются ли отзывы о юридическом лице от сторонних кредитных организаций, в которых юридическое лицо ранее находилось на обслуживании</p>\n</td>\n<td valign=\"top\" width=\"151\">\n<p><input type=\"checkbox\" /> Да</p>\n<p><input type=\"checkbox\" checked=\"checked\" /> Нет</p>\n<p> </p>\n</td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<p><strong>Дополнительная информация: </strong>Отсутствует</p>\n<p> </p>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\n<tbody>\n<tr>\n<td colspan=\"4\" valign=\"top\" width=\"752\">\n<p><strong><em>Контактное лицо для работы с Банком:</em></strong></p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"92\">\n<p>Ф.И.О. </p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"659\">\n<p>$assigned_user_name_first_name $assigned_user_name_last_name </p>\n</td>\n</tr>\n<tr>\n<td valign=\"top\" width=\"92\">\n<p>Должность:</p>\n</td>\n<td colspan=\"3\" valign=\"top\" width=\"659\">\n<p>Тендерный специалист</p>\n</td>\n</tr>\n<tr>\n<td colspan=\"2\" valign=\"top\" width=\"250\">\n<p>Тел.: $assigned_user_name_phone_mobile</p>\n</td>\n<td valign=\"top\" width=\"251\">\n<p>Факс:</p>\n</td>\n<td valign=\"top\" width=\"251\">\n<p>e-mail: $assigned_user_name_email1</p>\n</td>\n</tr>\n<tr>\n<td width=\"94\"> </td>\n<td width=\"144\"> </td>\n<td width=\"233\"> </td>\n<td width=\"235\"> </td>\n</tr>\n</tbody>\n</table>\n<p> </p>\n<p>$accounts_name, именуемое(ый) далее так же организация, обязуется обеспечить предоставление (передачу) физическими лицами, уполномоченными организацией, на заключение договора(ов) с КБ «Экономикс-Банк» (ООО), далее так же Банк, предоставление Банку и/или получение от Банка документов и информации об исполнении организацией заключенного(ных) с Банком договора(ов), согласия на обработку (включая автоматизированную обработку) их персональных данных в соответствии с Федеральным законом от 27.07.2006 № 152-ФЗ «О персональных данных», а также, на передачу КБ «Экономикс-Банк» (ООО) их персональных данных по запросам правоохранительных, налоговых, судебных органов и иных лиц в соответствии с законодательством Российской Федерации, на передачу персональных данных и/или информации о неисполнении и/или ненадлежащем исполнении организацией своих обязательств по заключенному(ым) с КБ «Экономикс-Банк» (ООО) договору(ам) третьим лицам с целью рассмотрения вопросов по заключению с организацией договора(ов), исполнению организацией обязательств по заключенному(ым) договору(ам), по взысканию с организации задолженности в рамках заключенных с организацией договоров, формирования истории обращений организации за кредитом  в Банк (кредитной истории в КБ «Экономикс-Банк» (ООО)), а так же выполнения КБ «Экономикс-Банк» (ООО) требований законодательства Российской Федераций и заключенного(ых) договора(ов).</p>\n<p>Настоящим $accounts_name, обязуется уведомить своих представителей – физических лиц, выгодоприобретателей – физических лиц, о начале обработки (в том числе автоматизированной) их персональных данных в КБ «Экономикс-Банк» (ООО) с даты предоставления соответствующей информации (персональных данных) о физических лицах в соответствии с Федеральным законом от 27.07.2006 № 152 – ФЗ «О персональных данных». Обработка персональных данных в КБ «Экономикс-Банк» (ООО) включает сбор, запись, систематизацию, накопление, хранение, уточнение (обновление, изменение), извлечение, использование, передачу (распространение, предоставление, доступ), обезличивание, блокирование, удаление, уничтожение персональных данных.</p>\n<p>Обработка персональных данных распространяется на персональные данные, которые стали известны (получены) Банком при заключении и/или исполнении договора(ов).</p>\n<p>Настоящим подтверждаем, что все указанные в анкете сведения являются полными, соответствуют действительности и могут быть подтверждены документально. Обязуемся немедленно информировать Банк обо всех изменениях сведений, приведенных в настоящей анкете, или существенных изменениях финансового состояния компании после подачи анкеты. Нам известно, что неизвещение или несвоевременное извещение о таких изменениях может явиться основанием для отказа в предоставлении кредитного продукта.</p>\n<p>Мы не возражаем против проверки в любое время всех сведений, содержащихся в настоящей анкете. Обнаружение скрытой или ложной информации является достаточным условием для отказа в предоставлении кредитного продукта.</p>\n<p>Лица, подписавшие настоящую анкету, действуют в пределах своих полномочий.</p>\n<p>Банк оставляет за собой право:</p>\n<p>1. Осуществлять обработку, в том числе автоматизированную, персональных данных представителей организации – физических лиц, передачу их персональных данных по запросам правоохранительных, налоговых, судебных органов, а так же передачу иным лицам в соответствии с законодательством Российской Федерации, на передачу персональных данных и /или информации об исполнении (неисполнении и/или ненадлежащем исполнении) организацией свих обязательств по заключенному(ным) с КБ «Экономикс-Банк» (ООО) договору(ам) третьим лицам, с целью рассмотрения вопросов по заключению с организацией договора(ов), исполнению организацией обязательств по заключенному(ым) с Банком договору(ам), по взысканию с организации задолженности в рамках заключенных с организацией договоров, формирования истории обращений организации за кредитом (кредитной истории в КБ «Экономикс-Банк» (ООО)), а так же выполнения КБ «Экономикс-Банк» (ООО) требований законодательства Российской Федераций и заключенного(ых) договора(ов). Настоящее право Банка действует до достижения цели обработки персональных данных. По достижении указанной цели Банк прекращает обработку персональных данных представителей организации, если иное не предусмотрено законодательством Российской Федерации. Организация вправе направить Банку заявление в письменном виде о прекращении обработки персональных данных представителей, в случаях предусмотренных законодательством Российской Федерации.</p>\n<p>2. Осуществлять проверку достоверности и полноты любой сообщаемой информации.</p>\n<p>3. Хранения копий предоставленных документов и оригиналов заявления и анкеты, даже если кредит (банковская гарантия) не будет предоставлен(а), соответствующий договор не будет заключен.  Принятие Банком Заявления к рассмотрению, а также возможные расходы организации (на оформление необходимых для получения кредита (банковской гарантии)/заключения договоров обеспечения документов, за проведение экспертизы и т.п.) не являются обязательством Банка предоставить кредит (банковскую гарантию) или возместить понесенные организацией издержки.</p>\n<p>           </p>\n<p>Настоящим, предоставляем свое        СОГЛАСИЕ                НЕСОГЛАСИЕ</p>\n<p>на получение КБ «Экономикс-Банк» (ООО) кредитного(ых) отчета(ов) из Бюро кредитных историй / Центрального каталога кредитных историй, для рассмотрения вопроса КБ «Экономикс-Банк» (ООО) о выдаче кредита/предоставлении банковской гарантии в соответствии с поданной заявкой на условиях, определенных Федеральным законом «О кредитных историях» №218-ФЗ от 30 декабря 2004 года.</p>\n<p> </p>\n<p>Дата «____» __________________ 2016 года</p>\n<p> </p>\n<p> </p>\n<p><strong>Руководитель                        ______________________________        {=C60} {=C61} {=C62}</strong></p>\n<p><strong>  </strong></p>\n<p><strong>Главный бухгалтер              ______________________________        {=C106} {=C107} {=C108}                                </strong></p>\n<p><strong>     М.П.</strong></p>',0,'1',1,'Accounts',\N,\N,15,15,16,16,9,9,'A4','Portrait')	;
#	TC`aos_pdf_templates_audit`utf8_general_ci	;
CREATE TABLE `aos_pdf_templates_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_pdf_templates_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`aos_pdf_templates_audit`utf8_general_ci	;
INSERT INTO `aos_pdf_templates_audit` VALUES 
('1db5ab95-c2ab-51f0-8d8e-592c046a2035','72f147d5-888a-1986-5d4f-592c0436e1a4','2017-05-29 11:24:35','1','type','enum','AOS_Quotes','Accounts',\N,\N)	;
#	TC`aos_product_categories`utf8_general_ci	;
CREATE TABLE `aos_product_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_parent` tinyint(1) DEFAULT '0',
  `parent_category_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_product_categories_audit`utf8_general_ci	;
CREATE TABLE `aos_product_categories_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_product_categories_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products`utf8_general_ci	;
CREATE TABLE `aos_products` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `maincode` varchar(100) DEFAULT 'XXXX',
  `part_number` varchar(25) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT 'Good',
  `cost` decimal(26,6) DEFAULT NULL,
  `cost_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `price` decimal(26,6) DEFAULT NULL,
  `price_usdollar` decimal(26,6) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `aos_product_category_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products_audit`utf8_general_ci	;
CREATE TABLE `aos_products_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_products_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products_quotes`utf8_general_ci	;
CREATE TABLE `aos_products_quotes` (
  `id` char(36) NOT NULL,
  `name` text,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `part_number` varchar(255) DEFAULT NULL,
  `item_description` text,
  `number` int(11) DEFAULT NULL,
  `product_qty` decimal(18,4) DEFAULT NULL,
  `product_cost_price` decimal(26,6) DEFAULT NULL,
  `product_cost_price_usdollar` decimal(26,6) DEFAULT NULL,
  `product_list_price` decimal(26,6) DEFAULT NULL,
  `product_list_price_usdollar` decimal(26,6) DEFAULT NULL,
  `product_discount` decimal(26,6) DEFAULT NULL,
  `product_discount_usdollar` decimal(26,6) DEFAULT NULL,
  `product_discount_amount` decimal(26,6) DEFAULT NULL,
  `product_discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount` varchar(255) DEFAULT 'Percentage',
  `product_unit_price` decimal(26,6) DEFAULT NULL,
  `product_unit_price_usdollar` decimal(26,6) DEFAULT NULL,
  `vat_amt` decimal(26,6) DEFAULT NULL,
  `vat_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `product_total_price` decimal(26,6) DEFAULT NULL,
  `product_total_price_usdollar` decimal(26,6) DEFAULT NULL,
  `vat` varchar(100) DEFAULT '5.0',
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `product_id` char(36) DEFAULT NULL,
  `group_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aospq_par_del` (`parent_id`,`parent_type`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_products_quotes_audit`utf8_general_ci	;
CREATE TABLE `aos_products_quotes_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_products_quotes_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes`utf8_general_ci	;
CREATE TABLE `aos_quotes` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `approval_issue` text,
  `billing_account_id` char(36) DEFAULT NULL,
  `billing_contact_id` char(36) DEFAULT NULL,
  `billing_address_street` varchar(150) DEFAULT NULL,
  `billing_address_city` varchar(100) DEFAULT NULL,
  `billing_address_state` varchar(100) DEFAULT NULL,
  `billing_address_postalcode` varchar(20) DEFAULT NULL,
  `billing_address_country` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(150) DEFAULT NULL,
  `shipping_address_city` varchar(100) DEFAULT NULL,
  `shipping_address_state` varchar(100) DEFAULT NULL,
  `shipping_address_postalcode` varchar(20) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `expiration` date DEFAULT NULL,
  `number` int(11) NOT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `template_ddown_c` text,
  `total_amt` decimal(26,6) DEFAULT NULL,
  `total_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `subtotal_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `discount_amount` decimal(26,6) DEFAULT NULL,
  `discount_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `tax_amount` decimal(26,6) DEFAULT NULL,
  `tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_amount` decimal(26,6) DEFAULT NULL,
  `shipping_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `shipping_tax` varchar(100) DEFAULT NULL,
  `shipping_tax_amt` decimal(26,6) DEFAULT NULL,
  `shipping_tax_amt_usdollar` decimal(26,6) DEFAULT NULL,
  `total_amount` decimal(26,6) DEFAULT NULL,
  `total_amount_usdollar` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `stage` varchar(100) DEFAULT 'Draft',
  `term` varchar(100) DEFAULT NULL,
  `terms_c` text,
  `approval_status` varchar(100) DEFAULT NULL,
  `invoice_status` varchar(100) DEFAULT 'Not Invoiced',
  `subtotal_tax_amount` decimal(26,6) DEFAULT NULL,
  `subtotal_tax_amount_usdollar` decimal(26,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_aos_invoices_c`utf8_general_ci	;
CREATE TABLE `aos_quotes_aos_invoices_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_quotes77d9_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes6b83nvoices_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_aos_invoices_alt` (`aos_quotes77d9_quotes_ida`,`aos_quotes6b83nvoices_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_audit`utf8_general_ci	;
CREATE TABLE `aos_quotes_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aos_quotes_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_os_contracts_c`utf8_general_ci	;
CREATE TABLE `aos_quotes_os_contracts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_quotese81e_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes4dc0ntracts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_aos_contracts_alt` (`aos_quotese81e_quotes_ida`,`aos_quotes4dc0ntracts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aos_quotes_project_c`utf8_general_ci	;
CREATE TABLE `aos_quotes_project_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `aos_quotes1112_quotes_ida` varchar(36) DEFAULT NULL,
  `aos_quotes7207project_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aos_quotes_project_alt` (`aos_quotes1112_quotes_ida`,`aos_quotes7207project_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_actions`utf8_general_ci	;
CREATE TABLE `aow_actions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aow_workflow_id` char(36) DEFAULT NULL,
  `action_order` int(255) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `parameters` longtext,
  PRIMARY KEY (`id`),
  KEY `aow_action_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_conditions`utf8_general_ci	;
CREATE TABLE `aow_conditions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aow_workflow_id` char(36) DEFAULT NULL,
  `condition_order` int(255) DEFAULT NULL,
  `module_path` longtext,
  `field` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aow_conditions_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_processed`utf8_general_ci	;
CREATE TABLE `aow_processed` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `aow_workflow_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  KEY `aow_processed_index_workflow` (`aow_workflow_id`,`status`,`parent_id`,`deleted`),
  KEY `aow_processed_index_status` (`status`),
  KEY `aow_processed_index_workflow_id` (`aow_workflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_processed_aow_actions`utf8_general_ci	;
CREATE TABLE `aow_processed_aow_actions` (
  `id` varchar(36) NOT NULL,
  `aow_processed_id` varchar(36) DEFAULT NULL,
  `aow_action_id` varchar(36) DEFAULT NULL,
  `status` varchar(36) DEFAULT 'Pending',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aow_processed_aow_actions` (`aow_processed_id`,`aow_action_id`),
  KEY `idx_actid_del_freid` (`aow_action_id`,`deleted`,`aow_processed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_workflow`utf8_general_ci	;
CREATE TABLE `aow_workflow` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `flow_module` varchar(100) DEFAULT NULL,
  `flow_run_on` varchar(100) DEFAULT '0',
  `status` varchar(100) DEFAULT 'Active',
  `run_when` varchar(100) DEFAULT 'Always',
  `multiple_runs` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `aow_workflow_index_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`aow_workflow_audit`utf8_general_ci	;
CREATE TABLE `aow_workflow_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_aow_workflow_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`bugs`utf8_general_ci	;
CREATE TABLE `bugs` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `bug_number` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  `resolution` varchar(255) DEFAULT NULL,
  `work_log` text,
  `found_in_release` varchar(255) DEFAULT NULL,
  `fixed_in_release` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `product_category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bugsnumk` (`bug_number`),
  KEY `bug_number` (`bug_number`),
  KEY `idx_bug_name` (`name`),
  KEY `idx_bugs_assigned_user` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`bugs_audit`utf8_general_ci	;
CREATE TABLE `bugs_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_bugs_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls`utf8_general_ci	;
CREATE TABLE `calls` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `duration_hours` int(2) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planned',
  `direction` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT '-1',
  `email_reminder_time` int(11) DEFAULT '-1',
  `email_reminder_sent` tinyint(1) DEFAULT '0',
  `outlook_id` varchar(255) DEFAULT NULL,
  `repeat_type` varchar(36) DEFAULT NULL,
  `repeat_interval` int(3) DEFAULT '1',
  `repeat_dow` varchar(7) DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_count` int(7) DEFAULT NULL,
  `repeat_parent_id` char(36) DEFAULT NULL,
  `recurring_source` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_call_name` (`name`),
  KEY `idx_status` (`status`),
  KEY `idx_calls_date_start` (`date_start`),
  KEY `idx_calls_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_calls_assigned_del` (`deleted`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_contacts`utf8_general_ci	;
CREATE TABLE `calls_contacts` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_call_call` (`call_id`),
  KEY `idx_con_call_con` (`contact_id`),
  KEY `idx_call_contact` (`call_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_leads`utf8_general_ci	;
CREATE TABLE `calls_leads` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `lead_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lead_call_call` (`call_id`),
  KEY `idx_lead_call_lead` (`lead_id`),
  KEY `idx_call_lead` (`call_id`,`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_reschedule`utf8_general_ci	;
CREATE TABLE `calls_reschedule` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `call_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_reschedule_audit`utf8_general_ci	;
CREATE TABLE `calls_reschedule_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_calls_reschedule_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`calls_users`utf8_general_ci	;
CREATE TABLE `calls_users` (
  `id` varchar(36) NOT NULL,
  `call_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usr_call_call` (`call_id`),
  KEY `idx_usr_call_usr` (`user_id`),
  KEY `idx_call_users` (`call_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaign_log`utf8_general_ci	;
CREATE TABLE `campaign_log` (
  `id` char(36) NOT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `target_tracker_key` varchar(36) DEFAULT NULL,
  `target_id` varchar(36) DEFAULT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `activity_type` varchar(100) DEFAULT NULL,
  `activity_date` datetime DEFAULT NULL,
  `related_id` varchar(36) DEFAULT NULL,
  `related_type` varchar(100) DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `hits` int(11) DEFAULT '0',
  `list_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `more_information` varchar(100) DEFAULT NULL,
  `marketing_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_camp_tracker` (`target_tracker_key`),
  KEY `idx_camp_campaign_id` (`campaign_id`),
  KEY `idx_camp_more_info` (`more_information`),
  KEY `idx_target_id` (`target_id`),
  KEY `idx_target_id_deleted` (`target_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaign_trkrs`utf8_general_ci	;
CREATE TABLE `campaign_trkrs` (
  `id` char(36) NOT NULL,
  `tracker_name` varchar(30) DEFAULT NULL,
  `tracker_url` varchar(255) DEFAULT 'http://',
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` char(36) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `is_optout` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `campaign_tracker_key_idx` (`tracker_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaigns`utf8_general_ci	;
CREATE TABLE `campaigns` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_count` int(11) DEFAULT '0',
  `refer_url` varchar(255) DEFAULT 'http://',
  `tracker_text` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `impressions` int(11) DEFAULT '0',
  `currency_id` char(36) DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `expected_cost` double DEFAULT NULL,
  `actual_cost` double DEFAULT NULL,
  `expected_revenue` double DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `objective` text,
  `content` text,
  `frequency` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `camp_auto_tracker_key` (`tracker_key`),
  KEY `idx_campaign_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`campaigns_audit`utf8_general_ci	;
CREATE TABLE `campaigns_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_campaigns_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases`utf8_general_ci	;
CREATE TABLE `cases` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `case_number` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  `resolution` text,
  `work_log` text,
  `account_id` char(36) DEFAULT NULL,
  `state` varchar(100) DEFAULT 'Open',
  `contact_created_by_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `casesnumk` (`case_number`),
  KEY `case_number` (`case_number`),
  KEY `idx_case_name` (`name`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_cases_stat_del` (`assigned_user_id`,`status`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases_audit`utf8_general_ci	;
CREATE TABLE `cases_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_cases_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases_bugs`utf8_general_ci	;
CREATE TABLE `cases_bugs` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cas_bug_cas` (`case_id`),
  KEY `idx_cas_bug_bug` (`bug_id`),
  KEY `idx_case_bug` (`case_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cases_cstm`utf8_general_ci	;
CREATE TABLE `cases_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`config`utf8_general_ci	;
CREATE TABLE `config` (
  `category` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `value` text,
  KEY `idx_config_cat` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`config`utf8_general_ci	;
INSERT INTO `config` VALUES 
('notify','fromaddress','web@finexpert.pro'),
('notify','fromname','ФинЭксперт'),
('notify','send_by_default','1'),
('notify','on','1'),
('notify','send_from_assigning_user','0'),
('info','sugar_version','6.5.24'),
('MySettings','tab','YTo0MTp7czo0OiJIb21lIjtzOjQ6IkhvbWUiO3M6ODoiQWNjb3VudHMiO3M6ODoiQWNjb3VudHMiO3M6ODoiQ29udGFjdHMiO3M6ODoiQ29udGFjdHMiO3M6MTM6Ik9wcG9ydHVuaXRpZXMiO3M6MTM6Ik9wcG9ydHVuaXRpZXMiO3M6NToiTGVhZHMiO3M6NToiTGVhZHMiO3M6MTA6IkFPU19RdW90ZXMiO3M6MTA6IkFPU19RdW90ZXMiO3M6ODoiQ2FsZW5kYXIiO3M6ODoiQ2FsZW5kYXIiO3M6OToiRG9jdW1lbnRzIjtzOjk6IkRvY3VtZW50cyI7czo2OiJFbWFpbHMiO3M6NjoiRW1haWxzIjtzOjU6IlNwb3RzIjtzOjU6IlNwb3RzIjtzOjk6IkNhbXBhaWducyI7czo5OiJDYW1wYWlnbnMiO3M6NToiQ2FsbHMiO3M6NToiQ2FsbHMiO3M6ODoiTWVldGluZ3MiO3M6ODoiTWVldGluZ3MiO3M6NToiVGFza3MiO3M6NToiVGFza3MiO3M6NToiTm90ZXMiO3M6NToiTm90ZXMiO3M6MTI6IkFPU19JbnZvaWNlcyI7czoxMjoiQU9TX0ludm9pY2VzIjtzOjEzOiJBT1NfQ29udHJhY3RzIjtzOjEzOiJBT1NfQ29udHJhY3RzIjtzOjU6IkNhc2VzIjtzOjU6IkNhc2VzIjtzOjk6IlByb3NwZWN0cyI7czo5OiJQcm9zcGVjdHMiO3M6MTM6IlByb3NwZWN0TGlzdHMiO3M6MTM6IlByb3NwZWN0TGlzdHMiO3M6NzoiUHJvamVjdCI7czo3OiJQcm9qZWN0IjtzOjE5OiJBTV9Qcm9qZWN0VGVtcGxhdGVzIjtzOjE5OiJBTV9Qcm9qZWN0VGVtcGxhdGVzIjtzOjk6IkZQX2V2ZW50cyI7czo5OiJGUF9ldmVudHMiO3M6MTg6IkZQX0V2ZW50X0xvY2F0aW9ucyI7czoxODoiRlBfRXZlbnRfTG9jYXRpb25zIjtzOjEyOiJBT1NfUHJvZHVjdHMiO3M6MTI6IkFPU19Qcm9kdWN0cyI7czoyMjoiQU9TX1Byb2R1Y3RfQ2F0ZWdvcmllcyI7czoyMjoiQU9TX1Byb2R1Y3RfQ2F0ZWdvcmllcyI7czoxNzoiQU9TX1BERl9UZW1wbGF0ZXMiO3M6MTc6IkFPU19QREZfVGVtcGxhdGVzIjtzOjk6Impqd2dfTWFwcyI7czo5OiJqandnX01hcHMiO3M6MTI6Impqd2dfTWFya2VycyI7czoxMjoiamp3Z19NYXJrZXJzIjtzOjEwOiJqandnX0FyZWFzIjtzOjEwOiJqandnX0FyZWFzIjtzOjE4OiJqandnX0FkZHJlc3NfQ2FjaGUiO3M6MTg6Impqd2dfQWRkcmVzc19DYWNoZSI7czoxMToiQU9SX1JlcG9ydHMiO3M6MTE6IkFPUl9SZXBvcnRzIjtzOjEyOiJBT1dfV29ya0Zsb3ciO3M6MTI6IkFPV19Xb3JrRmxvdyI7czoxNzoiQU9LX0tub3dsZWRnZUJhc2UiO3M6MTc6IkFPS19Lbm93bGVkZ2VCYXNlIjtzOjI5OiJBT0tfS25vd2xlZGdlX0Jhc2VfQ2F0ZWdvcmllcyI7czoyOToiQU9LX0tub3dsZWRnZV9CYXNlX0NhdGVnb3JpZXMiO3M6NzoiZHBfYmtydiI7czo3OiJkcF9ia3J2IjtzOjk6ImRwX3JlYWx0eSI7czo5OiJkcF9yZWFsdHkiO3M6MTA6ImRwX2xpY2Vuc2UiO3M6MTA6ImRwX2xpY2Vuc2UiO3M6MTI6InNyb19zdmlkX3NybyI7czoxMjoic3JvX3N2aWRfc3JvIjtzOjEzOiJkcF9mb3VuZGVyX2ZsIjtzOjEzOiJkcF9mb3VuZGVyX2ZsIjtzOjEzOiJkcF9mb3VuZGVyX3VsIjtzOjEzOiJkcF9mb3VuZGVyX3VsIjt9'),
('portal','on','0'),
('tracker','Tracker','1'),
('system','skypeout_on','1'),
('sugarfeed','enabled','1'),
('sugarfeed','module_UserFeed','1'),
('sugarfeed','module_Contacts','1'),
('sugarfeed','module_Leads','1'),
('sugarfeed','module_Opportunities','1'),
('sugarfeed','module_Cases','1'),
('Update','CheckUpdates','manual'),
('system','name','SuiteCRM'),
('system','adminwizard','1'),
('notify','allow_default_outbound','0')	;
#	TC`contacts`utf8_general_ci	;
CREATE TABLE `contacts` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `lead_source` varchar(255) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `joomla_account_id` varchar(255) DEFAULT NULL,
  `portal_account_disabled` tinyint(1) DEFAULT NULL,
  `portal_user_type` varchar(100) DEFAULT 'Single',
  PRIMARY KEY (`id`),
  KEY `idx_cont_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_contacts_del_last` (`deleted`,`last_name`),
  KEY `idx_cont_del_reports` (`deleted`,`reports_to_id`,`last_name`),
  KEY `idx_reports_to_id` (`reports_to_id`),
  KEY `idx_del_id_user` (`deleted`,`id`,`assigned_user_id`),
  KEY `idx_cont_assigned` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`contacts`utf8_general_ci	;
INSERT INTO `contacts` VALUES 
('9f4c2908-47c8-e20c-5f36-592bd28fd104','2017-05-29 07:49:28','2017-05-29 07:49:28','1','1','',0,'1','','Игорь','Трофимычев','631900026560',\N,'',0,\N,'','',\N,'','Студеный овраг, просека 10','Самара','','443031','Российская Федерация','','','','','',\N,\N,'','',\N,'',\N,\N,'Single'),
('c8548377-e295-926c-28ff-592be34c26d7','2017-05-29 09:00:55','2017-05-29 09:00:55','1','1','',0,'1','','Юрий','Марянин','631899107028',\N,'',0,\N,'','',\N,'','','','','','','','','','','',\N,\N,'','',\N,'',\N,\N,'Single'),
('e41e39af-5bdc-0b83-c659-5927e5a9adf7','2017-05-26 08:23:20','2017-05-29 04:39:59','1','1',\N,0,'1',\N,'Семён','Антонов','632107606114',\N,\N,0,\N,'+79879556095','+7(846)205-60-95',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,'',\N,'',\N,0,'Single')	;
#	TC`contacts_audit`utf8_general_ci	;
CREATE TABLE `contacts_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_contacts_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`contacts_bugs`utf8_general_ci	;
CREATE TABLE `contacts_bugs` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_bug_con` (`contact_id`),
  KEY `idx_con_bug_bug` (`bug_id`),
  KEY `idx_contact_bug` (`contact_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`contacts_cases`utf8_general_ci	;
CREATE TABLE `contacts_cases` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_case_con` (`contact_id`),
  KEY `idx_con_case_case` (`case_id`),
  KEY `idx_contacts_cases` (`contact_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`contacts_cstm`utf8_general_ci	;
CREATE TABLE `contacts_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  `patr_c` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`contacts_cstm`utf8_general_ci	;
INSERT INTO `contacts_cstm` VALUES 
('9f4c2908-47c8-e20c-5f36-592bd28fd104',0.00000000,0.00000000,\N,\N,'Николаевич'),
('c8548377-e295-926c-28ff-592be34c26d7',0.00000000,0.00000000,\N,\N,'Александрович'),
('e41e39af-5bdc-0b83-c659-5927e5a9adf7',0.00000000,0.00000000,'','','Геннадьевич')	;
#	TC`contacts_users`utf8_general_ci	;
CREATE TABLE `contacts_users` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_users_con` (`contact_id`),
  KEY `idx_con_users_user` (`user_id`),
  KEY `idx_contacts_users` (`contact_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cron_remove_documents`utf8_general_ci	;
CREATE TABLE `cron_remove_documents` (
  `id` varchar(36) NOT NULL,
  `bean_id` varchar(36) DEFAULT NULL,
  `module` varchar(25) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cron_remove_document_bean_id` (`bean_id`),
  KEY `idx_cron_remove_document_stamp` (`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`currencies`utf8_general_ci	;
CREATE TABLE `currencies` (
  `id` char(36) NOT NULL,
  `name` varchar(36) DEFAULT NULL,
  `symbol` varchar(36) DEFAULT NULL,
  `iso4217` varchar(3) DEFAULT NULL,
  `conversion_rate` double DEFAULT '0',
  `status` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`custom_fields`utf8_general_ci	;
CREATE TABLE `custom_fields` (
  `bean_id` varchar(36) DEFAULT NULL,
  `set_num` int(11) DEFAULT '0',
  `field0` varchar(255) DEFAULT NULL,
  `field1` varchar(255) DEFAULT NULL,
  `field2` varchar(255) DEFAULT NULL,
  `field3` varchar(255) DEFAULT NULL,
  `field4` varchar(255) DEFAULT NULL,
  `field5` varchar(255) DEFAULT NULL,
  `field6` varchar(255) DEFAULT NULL,
  `field7` varchar(255) DEFAULT NULL,
  `field8` varchar(255) DEFAULT NULL,
  `field9` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  KEY `idx_beanid_set_num` (`bean_id`,`set_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`document_revisions`utf8_general_ci	;
CREATE TABLE `document_revisions` (
  `id` varchar(36) NOT NULL,
  `change_log` varchar(255) DEFAULT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `doc_id` varchar(100) DEFAULT NULL,
  `doc_type` varchar(100) DEFAULT NULL,
  `doc_url` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `file_ext` varchar(100) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `revision` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentrevision_mimetype` (`file_mime_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents`utf8_general_ci	;
CREATE TABLE `documents` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `document_name` varchar(255) DEFAULT NULL,
  `doc_id` varchar(100) DEFAULT NULL,
  `doc_type` varchar(100) DEFAULT 'Sugar',
  `doc_url` varchar(255) DEFAULT NULL,
  `active_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `subcategory_id` varchar(100) DEFAULT NULL,
  `status_id` varchar(100) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  `related_doc_id` char(36) DEFAULT NULL,
  `related_doc_rev_id` char(36) DEFAULT NULL,
  `is_template` tinyint(1) DEFAULT '0',
  `template_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_doc_cat` (`category_id`,`subcategory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_accounts`utf8_general_ci	;
CREATE TABLE `documents_accounts` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_accounts_account_id` (`account_id`,`document_id`),
  KEY `documents_accounts_document_id` (`document_id`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_bugs`utf8_general_ci	;
CREATE TABLE `documents_bugs` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_bugs_bug_id` (`bug_id`,`document_id`),
  KEY `documents_bugs_document_id` (`document_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_cases`utf8_general_ci	;
CREATE TABLE `documents_cases` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_cases_case_id` (`case_id`,`document_id`),
  KEY `documents_cases_document_id` (`document_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_contacts`utf8_general_ci	;
CREATE TABLE `documents_contacts` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_contacts_contact_id` (`contact_id`,`document_id`),
  KEY `documents_contacts_document_id` (`document_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`documents_opportunities`utf8_general_ci	;
CREATE TABLE `documents_opportunities` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `document_id` varchar(36) DEFAULT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_docu_opps_oppo_id` (`opportunity_id`,`document_id`),
  KEY `idx_docu_oppo_docu_id` (`document_id`,`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_bkrv`utf8_general_ci	;
CREATE TABLE `dp_bkrv` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `rsch` varchar(25) DEFAULT NULL,
  `krch` varchar(20) DEFAULT NULL,
  `bik_bank` varchar(9) DEFAULT NULL,
  `inn_bank` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_bkrv`utf8_general_ci	;
INSERT INTO `dp_bkrv` VALUES 
('cc7ac549-b341-f38a-0bdc-5926d3163ea2','Российский капитал','2017-05-25 12:54:05','2017-05-25 12:54:05','1','1','',0,'1','239845698374658973645','8443534','8345693','82764538')	;
#	TC`dp_bkrv_accounts_c`utf8_general_ci	;
CREATE TABLE `dp_bkrv_accounts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `dp_bkrv_accountsaccounts_ida` varchar(36) DEFAULT NULL,
  `dp_bkrv_accountsdp_bkrv_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_bkrv_accounts_ida1` (`dp_bkrv_accountsaccounts_ida`),
  KEY `dp_bkrv_accounts_alt` (`dp_bkrv_accountsdp_bkrv_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_bkrv_accounts_c`utf8_general_ci	;
INSERT INTO `dp_bkrv_accounts_c` VALUES 
('ce33ed69-8e6e-6754-e112-5926d37e962c','2017-05-25 12:54:05',0,'b9f49b4f-21dc-4a20-5646-592571b11c40','cc7ac549-b341-f38a-0bdc-5926d3163ea2')	;
#	TC`dp_bkrv_audit`utf8_general_ci	;
CREATE TABLE `dp_bkrv_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_bkrv_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_founder_fl`utf8_general_ci	;
CREATE TABLE `dp_founder_fl` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_founder_fl`utf8_general_ci	;
INSERT INTO `dp_founder_fl` VALUES 
('aa75ec99-cd50-76a4-2f02-592ba18917bd','632107606114','2017-05-29 04:18:47','2017-05-29 04:25:45','1','1',\N,0,'1')	;
#	TC`dp_founder_fl_audit`utf8_general_ci	;
CREATE TABLE `dp_founder_fl_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_founder_fl_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_founder_fl_contacts_1_c`utf8_general_ci	;
CREATE TABLE `dp_founder_fl_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `dp_founder_fl_contacts_1dp_founder_fl_ida` varchar(36) DEFAULT NULL,
  `dp_founder_fl_contacts_1contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_founder_fl_contacts_1_ida1` (`dp_founder_fl_contacts_1dp_founder_fl_ida`),
  KEY `dp_founder_fl_contacts_1_idb2` (`dp_founder_fl_contacts_1contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_founder_fl_contacts_1_c`utf8_general_ci	;
INSERT INTO `dp_founder_fl_contacts_1_c` VALUES 
('6cfe21cf-a327-b942-48fe-592ba228106f','2017-05-29 04:25:45',0,'aa75ec99-cd50-76a4-2f02-592ba18917bd','e41e39af-5bdc-0b83-c659-5927e5a9adf7')	;
#	TC`dp_founder_fl_cstm`utf8_general_ci	;
CREATE TABLE `dp_founder_fl_cstm` (
  `id_c` char(36) NOT NULL,
  `fl_share_size_cur_c` decimal(4,2) DEFAULT NULL,
  `fl_size_perc_c` decimal(4,2) DEFAULT NULL,
  `contact_id_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_founder_fl_cstm`utf8_general_ci	;
INSERT INTO `dp_founder_fl_cstm` VALUES 
('aa75ec99-cd50-76a4-2f02-592ba18917bd',\N,\N,'')	;
#	TC`dp_founder_ul`utf8_general_ci	;
CREATE TABLE `dp_founder_ul` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_founder_ul_accounts_1_c`utf8_general_ci	;
CREATE TABLE `dp_founder_ul_accounts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `dp_founder_ul_accounts_1dp_founder_ul_ida` varchar(36) DEFAULT NULL,
  `dp_founder_ul_accounts_1accounts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_founder_ul_accounts_1_ida1` (`dp_founder_ul_accounts_1dp_founder_ul_ida`),
  KEY `dp_founder_ul_accounts_1_idb2` (`dp_founder_ul_accounts_1accounts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_founder_ul_audit`utf8_general_ci	;
CREATE TABLE `dp_founder_ul_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_founder_ul_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_founder_ul_cstm`utf8_general_ci	;
CREATE TABLE `dp_founder_ul_cstm` (
  `id_c` char(36) NOT NULL,
  `ul_share_size_cur_c` decimal(4,2) DEFAULT NULL,
  `ul_size_perc_c` decimal(4,2) DEFAULT NULL,
  `account_id_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_license`utf8_general_ci	;
CREATE TABLE `dp_license` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_license_audit`utf8_general_ci	;
CREATE TABLE `dp_license_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_license_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_license_cstm`utf8_general_ci	;
CREATE TABLE `dp_license_cstm` (
  `id_c` char(36) NOT NULL,
  `num_license_c` varchar(20) DEFAULT NULL,
  `date_license_c` date DEFAULT NULL,
  `bywhom_license_c` varchar(100) DEFAULT NULL,
  `account_id_c` char(36) DEFAULT NULL,
  `srok_work_license_c` date DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`dp_realty`utf8_general_ci	;
CREATE TABLE `dp_realty` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status_nedv` varchar(100) DEFAULT NULL,
  `area_nedv` int(10) DEFAULT NULL,
  `target_nedv` varchar(100) DEFAULT NULL,
  `num_svid_nedv` varchar(30) DEFAULT NULL,
  `date_reg_nedv` date DEFAULT NULL,
  `num_dogovor_arend` varchar(20) DEFAULT NULL,
  `date_reg_dogovor_arend` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_realty`utf8_general_ci	;
INSERT INTO `dp_realty` VALUES 
('55092ca4-45ce-f10f-c85d-59272dbd7b35','443068, г. Самара, ул. Ново-Садовая, д. 106, оф. 613','2017-05-25 19:16:57','2017-05-25 19:21:26','1','1',\N,0,'1','arenda',53,'office',\N,\N,\N,\N)	;
#	TC`dp_realty_accounts_c`utf8_general_ci	;
CREATE TABLE `dp_realty_accounts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `dp_realty_accountsaccounts_ida` varchar(36) DEFAULT NULL,
  `dp_realty_accountsdp_realty_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_realty_accounts_ida1` (`dp_realty_accountsaccounts_ida`),
  KEY `dp_realty_accounts_alt` (`dp_realty_accountsdp_realty_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`dp_realty_accounts_c`utf8_general_ci	;
INSERT INTO `dp_realty_accounts_c` VALUES 
('57169c46-7045-9182-e365-59272db8b573','2017-05-25 19:16:57',0,'b9f49b4f-21dc-4a20-5646-592571b11c40','55092ca4-45ce-f10f-c85d-59272dbd7b35')	;
#	TC`dp_realty_audit`utf8_general_ci	;
CREATE TABLE `dp_realty_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_dp_realty_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`eapm`utf8_general_ci	;
CREATE TABLE `eapm` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `application` varchar(100) DEFAULT 'webex',
  `api_data` text,
  `consumer_key` varchar(255) DEFAULT NULL,
  `consumer_secret` varchar(255) DEFAULT NULL,
  `oauth_token` varchar(255) DEFAULT NULL,
  `oauth_secret` varchar(255) DEFAULT NULL,
  `validated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_active` (`assigned_user_id`,`application`,`validated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_addr_bean_rel`utf8_general_ci	;
CREATE TABLE `email_addr_bean_rel` (
  `id` char(36) NOT NULL,
  `email_address_id` char(36) NOT NULL,
  `bean_id` char(36) NOT NULL,
  `bean_module` varchar(100) DEFAULT NULL,
  `primary_address` tinyint(1) DEFAULT '0',
  `reply_to_address` tinyint(1) DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_email_address_id` (`email_address_id`),
  KEY `idx_bean_id` (`bean_id`,`bean_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`email_addr_bean_rel`utf8_general_ci	;
INSERT INTO `email_addr_bean_rel` VALUES 
('2d536e55-b78f-7d76-5acb-5928032fbae8','2d63584a-c431-7ee0-9d12-5928039316ff','f1c17d43-b29f-16ef-5774-5927e6b4501a','Accounts',1,0,'2017-05-26 10:29:49','2017-05-26 10:29:49',1),
('2f424982-e72a-fbe1-664e-592803abe908','ae470cfc-302b-46c8-8425-592564a4429a','f1c17d43-b29f-16ef-5774-5927e6b4501a','Accounts',0,0,'2017-05-26 10:29:49','2017-05-26 10:29:49',1),
('ae332e3a-16b6-cc09-37f9-5925648d9340','ae470cfc-302b-46c8-8425-592564a4429a','1','Users',1,0,'2017-05-24 10:47:24','2017-05-24 10:47:24',0)	;
#	TC`email_addresses`utf8_general_ci	;
CREATE TABLE `email_addresses` (
  `id` char(36) NOT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `email_address_caps` varchar(255) DEFAULT NULL,
  `invalid_email` tinyint(1) DEFAULT '0',
  `opt_out` tinyint(1) DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ea_caps_opt_out_invalid` (`email_address_caps`,`opt_out`,`invalid_email`),
  KEY `idx_ea_opt_out_invalid` (`email_address`,`opt_out`,`invalid_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`email_addresses`utf8_general_ci	;
INSERT INTO `email_addresses` VALUES 
('2d63584a-c431-7ee0-9d12-5928039316ff','info@fksrf.pro','INFO@FKSRF.PRO',0,0,'2017-05-26 10:29:49','2017-05-26 10:29:49',0),
('ae470cfc-302b-46c8-8425-592564a4429a','web@fksrf.pro','WEB@FKSRF.PRO',0,0,'2017-05-24 10:47:24','2017-05-24 10:47:24',0)	;
#	TC`email_cache`utf8_general_ci	;
CREATE TABLE `email_cache` (
  `ie_id` char(36) DEFAULT NULL,
  `mbox` varchar(60) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `fromaddr` varchar(100) DEFAULT NULL,
  `toaddr` varchar(255) DEFAULT NULL,
  `senddate` datetime DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `mailsize` int(10) unsigned DEFAULT NULL,
  `imap_uid` int(10) unsigned DEFAULT NULL,
  `msgno` int(10) unsigned DEFAULT NULL,
  `recent` tinyint(4) DEFAULT NULL,
  `flagged` tinyint(4) DEFAULT NULL,
  `answered` tinyint(4) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `seen` tinyint(4) DEFAULT NULL,
  `draft` tinyint(4) DEFAULT NULL,
  KEY `idx_ie_id` (`ie_id`),
  KEY `idx_mail_date` (`ie_id`,`mbox`,`senddate`),
  KEY `idx_mail_from` (`ie_id`,`mbox`,`fromaddr`),
  KEY `idx_mail_subj` (`subject`),
  KEY `idx_mail_to` (`toaddr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_marketing`utf8_general_ci	;
CREATE TABLE `email_marketing` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `from_name` varchar(100) DEFAULT NULL,
  `from_addr` varchar(100) DEFAULT NULL,
  `reply_to_name` varchar(100) DEFAULT NULL,
  `reply_to_addr` varchar(100) DEFAULT NULL,
  `inbound_email_id` varchar(36) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `template_id` char(36) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `outbound_email_id` char(36) DEFAULT NULL,
  `all_prospect_lists` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emmkt_name` (`name`),
  KEY `idx_emmkit_del` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_marketing_prospect_lists`utf8_general_ci	;
CREATE TABLE `email_marketing_prospect_lists` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `email_marketing_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `email_mp_prospects` (`email_marketing_id`,`prospect_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`email_templates`utf8_general_ci	;
CREATE TABLE `email_templates` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `published` varchar(3) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `body_html` text,
  `deleted` tinyint(1) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `text_only` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_template_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`email_templates`utf8_general_ci	;
INSERT INTO `email_templates` VALUES 
('bff53f0a-2eb5-3f4c-41e7-592564cebbf8','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','System-generated password email','This template is used when the System Administrator sends a new password to a user.','New account information','\nHere is your account username and temporary password:\nUsername : $contact_user_user_name\nPassword : $contact_user_user_hash\n\n$config_site_url\n\nAfter you log in using the above password, you may be required to reset the password to one of your own choice.','<div><table width=\"550\"><tbody><tr><td><p>Here is your account username and temporary password:</p><p>Username : $contact_user_user_name </p><p>Password : $contact_user_user_hash </p><br /><p>$config_site_url</p><br /><p>After you log in using the above password, you may be required to reset the password to one of your own choice.</p>   </td>         </tr><tr><td></td>         </tr></tbody></table></div>',0,\N,0,\N),
('c28d3d07-a18f-eb2d-ddcd-592564f26138','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Forgot Password email','This template is used to send a user a link to click to reset the user\'s account password.','Reset your account password','\nYou recently requested on $contact_user_pwd_last_changed to be able to reset your account password.\n\nClick on the link below to reset your password:\n\n$contact_user_link_guid','<div><table width=\"550\"><tbody><tr><td><p>You recently requested on $contact_user_pwd_last_changed to be able to reset your account password. </p><p>Click on the link below to reset your password:</p><p> $contact_user_link_guid </p>  </td>         </tr><tr><td></td>         </tr></tbody></table></div>',0,\N,0,\N),
('dc4ad7b4-d6ac-7727-02d4-59256490e1fa','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Case Closure','Template for informing a contact that their case has been closed.','$acase_name [CASE:$acase_case_number] closed','Hi $contact_first_name $contact_last_name,\n\n					   Your case $acase_name (# $acase_case_number) has been closed on $acase_date_entered\n					   Status:				$acase_status\n					   Reference:			$acase_case_number\n					   Resolution:			$acase_resolution','<p> Hi $contact_first_name $contact_last_name,</p>\n					    <p>Your case $acase_name (# $acase_case_number) has been closed on $acase_date_entered</p>\n					    <table border=\"0\"><tbody><tr><td>Status</td><td>$acase_status</td></tr><tr><td>Reference</td><td>$acase_case_number</td></tr><tr><td>Resolution</td><td>$acase_resolution</td></tr></tbody></table>',0,\N,\N,\N),
('ded79ede-3f16-4286-5758-5925648b6ab7','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Joomla Account Creation','Template used when informing a contact that they\'ve been given an account on the joomla portal.','Support Portal Account Created','Hi $contact_name,\n					   An account has been created for you at $portal_address.\n					   You may login using this email address and the password $joomla_pass','<p>Hi $contact_name,</p>\n					    <p>An account has been created for you at <a href=\"$portal_address\">$portal_address</a>.</p>\n					    <p>You may login using this email address and the password $joomla_pass</p>',0,\N,\N,\N),
('e1851900-1e03-5229-0560-592564416186','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Case Creation','Template to send to a contact when a case is received from them.','$acase_name [CASE:$acase_case_number]','Hi $contact_first_name $contact_last_name,\n\n					   We\'ve received your case $acase_name (# $acase_case_number) on $acase_date_entered\n					   Status:		$acase_status\n					   Reference:	$acase_case_number\n					   Description:	$acase_description','<p> Hi $contact_first_name $contact_last_name,</p>\n					    <p>We\'ve received your case $acase_name (# $acase_case_number) on $acase_date_entered</p>\n					    <table border=\"0\"><tbody><tr><td>Status</td><td>$acase_status</td></tr><tr><td>Reference</td><td>$acase_case_number</td></tr><tr><td>Description</td><td>$acase_description</td></tr></tbody></table>',0,\N,\N,\N),
('e4b8b10c-83f4-a8bb-8fce-5925647324c0','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','Contact Case Update','Template to send to a contact when their case is updated.','$acase_name update [CASE:$acase_case_number]','Hi $user_first_name $user_last_name,\n\n					   You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:\n					       $contact_first_name $contact_last_name, said:\n					               $aop_case_updates_description','<p>Hi $contact_first_name $contact_last_name,</p>\n					    <p> </p>\n					    <p>You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:</p>\n					    <p><strong>$user_first_name $user_last_name said:</strong></p>\n					    <p style=\"padding-left:30px;\">$aop_case_updates_description</p>',0,\N,\N,\N),
('e7729ed9-9530-cd0e-4868-5925644484bb','2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','off','User Case Update','Email template to send to a Sugar user when their case is updated.','$acase_name (# $acase_case_number) update','Hi $user_first_name $user_last_name,\n\n					   You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:\n					       $contact_first_name $contact_last_name, said:\n					               $aop_case_updates_description\n                        You may review this Case at:\n                            $sugarurl/index.php?module=Cases&action=DetailView&record=$acase_id;','<p>Hi $user_first_name $user_last_name,</p>\n					   <p> </p>\n					   <p>You\'ve had an update to your case $acase_name (# $acase_case_number) on $aop_case_updates_date_entered:</p>\n					   <p><strong>$contact_first_name $contact_last_name, said:</strong></p>\n					   <p style=\"padding-left:30px;\">$aop_case_updates_description</p>\n					   <p>You may review this Case at: $sugarurl/index.php?module=Cases&action=DetailView&record=$acase_id;</p>\n					   ',0,\N,\N,\N),
('ecd98b03-0523-3d10-dc13-592564de2f8e','2013-05-24 14:31:45','2017-05-24 10:47:24','1','1','off','Event Invite Template','Default event invite template.','You have been invited to $fp_events_name','Dear $contact_name,\r\nYou have been invited to $fp_events_name on $fp_events_date_start to $fp_events_date_end\r\n$fp_events_description\r\nYours Sincerely,\r\n','\n<p>Dear $contact_name,</p>\n<p>You have been invited to $fp_events_name on $fp_events_date_start to $fp_events_date_end</p>\n<p>$fp_events_description</p>\n<p>If you would like to accept this invititation please click accept.</p>\n<p> $fp_events_link or $fp_events_link_declined</p>\n<p>Yours Sincerely,</p>\n',0,\N,\N,'email')	;
#	TC`emailman`utf8_general_ci	;
CREATE TABLE `emailman` (
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` char(36) DEFAULT NULL,
  `marketing_id` char(36) DEFAULT NULL,
  `list_id` char(36) DEFAULT NULL,
  `send_date_time` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `in_queue` tinyint(1) DEFAULT '0',
  `in_queue_date` datetime DEFAULT NULL,
  `send_attempts` int(11) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  `related_id` char(36) DEFAULT NULL,
  `related_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eman_list` (`list_id`,`user_id`,`deleted`),
  KEY `idx_eman_campaign_id` (`campaign_id`),
  KEY `idx_eman_relid_reltype_id` (`related_id`,`related_type`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails`utf8_general_ci	;
CREATE TABLE `emails` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `flagged` tinyint(1) DEFAULT NULL,
  `reply_to_status` tinyint(1) DEFAULT NULL,
  `intent` varchar(100) DEFAULT 'pick',
  `mailbox_id` char(36) DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_name` (`name`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_email_parent_id` (`parent_id`),
  KEY `idx_email_assigned` (`assigned_user_id`,`type`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails_beans`utf8_general_ci	;
CREATE TABLE `emails_beans` (
  `id` char(36) NOT NULL,
  `email_id` char(36) DEFAULT NULL,
  `bean_id` char(36) DEFAULT NULL,
  `bean_module` varchar(100) DEFAULT NULL,
  `campaign_data` text,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_emails_beans_bean_id` (`bean_id`),
  KEY `idx_emails_beans_email_bean` (`email_id`,`bean_id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails_email_addr_rel`utf8_general_ci	;
CREATE TABLE `emails_email_addr_rel` (
  `id` char(36) NOT NULL,
  `email_id` char(36) NOT NULL,
  `address_type` varchar(4) DEFAULT NULL,
  `email_address_id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eearl_email_id` (`email_id`,`address_type`),
  KEY `idx_eearl_address_id` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`emails_text`utf8_general_ci	;
CREATE TABLE `emails_text` (
  `email_id` char(36) NOT NULL,
  `from_addr` varchar(255) DEFAULT NULL,
  `reply_to_addr` varchar(255) DEFAULT NULL,
  `to_addrs` text,
  `cc_addrs` text,
  `bcc_addrs` text,
  `description` longtext,
  `description_html` longtext,
  `raw_source` longtext,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `emails_textfromaddr` (`from_addr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`favorites`utf8_general_ci	;
CREATE TABLE `favorites` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fields_meta_data`utf8_general_ci	;
CREATE TABLE `fields_meta_data` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `vname` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `help` varchar(255) DEFAULT NULL,
  `custom_module` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `len` int(11) DEFAULT NULL,
  `required` tinyint(1) DEFAULT '0',
  `default_value` varchar(255) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `audited` tinyint(1) DEFAULT '0',
  `massupdate` tinyint(1) DEFAULT '0',
  `duplicate_merge` smallint(6) DEFAULT '0',
  `reportable` tinyint(1) DEFAULT '1',
  `importable` varchar(255) DEFAULT NULL,
  `ext1` varchar(255) DEFAULT NULL,
  `ext2` varchar(255) DEFAULT NULL,
  `ext3` varchar(255) DEFAULT NULL,
  `ext4` text,
  PRIMARY KEY (`id`),
  KEY `idx_meta_id_del` (`id`,`deleted`),
  KEY `idx_meta_cm_del` (`custom_module`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`fields_meta_data`utf8_general_ci	;
INSERT INTO `fields_meta_data` VALUES 
('Accountscontact_id_c','contact_id_c','LBL_EIO_KONTR_CONTACT_ID','','','Accounts','id',36,0,\N,'2017-05-29 07:58:29',0,0,0,0,0,'true','','','',''),
('Accountseio_kontr_c','eio_kontr_c','LBL_EIO_KONTR','','','Accounts','relate',255,0,\N,'2017-05-29 07:58:29',0,0,0,0,1,'true','','Contacts','contact_id_c',''),
('Accountsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Accounts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Accountsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Accounts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Accountsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Accounts','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Accountsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Accounts','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Casesjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Cases','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Casesjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Cases','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Casesjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Cases','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Casesjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Cases','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Contactsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Contacts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Contactsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Contacts','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Contactsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Contacts','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Contactsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Contacts','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Contactspatr_c','patr_c','LBL_PATR','','','Contacts','varchar',100,0,'','2017-05-26 08:12:11',0,0,0,0,1,'true','','','',''),
('dp_founder_flcontact_id_c','contact_id_c','LBL_LINK_CONTACT_CONTACT_ID','','','dp_founder_fl','id',36,0,\N,'2017-05-29 04:07:28',0,0,0,0,0,'true','','','',''),
('dp_founder_flfl_share_size_cur_c','fl_share_size_cur_c','LBL_FL_SHARE_SIZE_CUR',\N,\N,'dp_founder_fl','decimal',4,0,\N,'2017-05-29 04:04:06',0,0,0,0,1,'true','2',\N,\N,\N),
('dp_founder_flfl_size_perc_c','fl_size_perc_c','LBL_FL_SIZE_PERC','','','dp_founder_fl','decimal',4,0,'','2017-05-29 04:03:54',0,0,0,0,1,'true','2','','',''),
('dp_founder_fllink_contact_c','link_contact_c','LBL_LINK_CONTACT','','','dp_founder_fl','relate',255,0,\N,'2017-05-29 04:07:28',0,0,0,0,1,'true','','Contacts','contact_id_c',''),
('dp_founder_ulaccount_id_c','account_id_c','LBL_LINK_KONTR_ACCOUNT_ID','','','dp_founder_ul','id',36,0,\N,'2017-05-29 04:08:10',0,0,0,0,0,'true','','','',''),
('dp_founder_ullink_kontr_c','link_kontr_c','LBL_LINK_KONTR','','','dp_founder_ul','relate',255,0,\N,'2017-05-29 04:08:10',0,0,0,0,1,'true','','Accounts','account_id_c',''),
('dp_founder_ulul_share_size_cur_c','ul_share_size_cur_c','LBL_UL_SHARE_SIZE_CUR','','','dp_founder_ul','decimal',4,0,'','2017-05-29 04:04:49',0,0,0,0,1,'true','2','','',''),
('dp_founder_ulul_size_perc_c','ul_size_perc_c','LBL_UL_SIZE_PERC','','','dp_founder_ul','decimal',4,0,'','2017-05-29 04:05:12',0,0,0,0,1,'true','2','','',''),
('dp_licenseaccount_id_c','account_id_c','LBL_LICENSE_FOR_ACCOUNT_ID','','','dp_license','id',36,0,\N,'2017-05-26 13:04:34',0,0,0,0,0,'true','','','',''),
('dp_licensebywhom_license_c','bywhom_license_c','LBL_BYWHOM_LICENSE','','','dp_license','varchar',100,0,'','2017-05-26 12:57:25',0,0,0,0,1,'true','','','',''),
('dp_licensedate_license_c','date_license_c','LBL_DATE_LICENSE','','','dp_license','date',\N,0,'','2017-05-26 12:56:49',0,0,0,0,1,'true','','','',''),
('dp_licenselicense_for_c','license_for_c','LBL_LICENSE_FOR','','','dp_license','relate',255,0,\N,'2017-05-26 13:04:34',0,0,0,0,1,'true','','Accounts','account_id_c',''),
('dp_licensenum_license_c','num_license_c','LBL_NUM_LICENSE','','','dp_license','varchar',20,0,'','2017-05-26 12:56:31',0,0,0,0,1,'true','','','',''),
('dp_licensesrok_work_license_c','srok_work_license_c','LBL_SROK_WORK_LICENSE','','','dp_license','date',\N,0,'-1 day','2017-05-28 17:16:26',0,0,0,0,1,'true','','','',''),
('Leadsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Leads','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Leadsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Leads','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Leadsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Leads','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Leadsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Leads','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Meetingsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Meetings','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Meetingsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Meetings','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Meetingsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Meetings','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Meetingsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Meetings','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Opportunitiesjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Opportunities','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Opportunitiesjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Opportunities','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Opportunitiesjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Opportunities','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Opportunitiesjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Opportunities','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Projectjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Project','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Projectjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Project','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Projectjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Project','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Projectjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Project','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Prospectsjjwg_maps_address_c','jjwg_maps_address_c','LBL_JJWG_MAPS_ADDRESS','Address','Address','Prospects','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Prospectsjjwg_maps_geocode_status_c','jjwg_maps_geocode_status_c','LBL_JJWG_MAPS_GEOCODE_STATUS','Geocode Status','Geocode Status','Prospects','varchar',255,0,\N,'2017-05-24 10:47:24',0,0,0,0,1,'true',\N,'','',''),
('Prospectsjjwg_maps_lat_c','jjwg_maps_lat_c','LBL_JJWG_MAPS_LAT','','Latitude','Prospects','float',10,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('Prospectsjjwg_maps_lng_c','jjwg_maps_lng_c','LBL_JJWG_MAPS_LNG','','Longitude','Prospects','float',11,0,'0.00000000','2017-05-24 10:47:24',0,0,0,0,1,'true','8','','',''),
('sro_svid_sroaccount_id_c','account_id_c','LBL_SRO_FOR_ACCOUNT_ID','','','sro_svid_sro','id',36,0,\N,'2017-05-28 17:32:42',0,0,0,0,0,'true','','','',''),
('sro_svid_srobywhom_sro_c','bywhom_sro_c','LBL_BYWHOM_SRO','','','sro_svid_sro','varchar',150,0,'','2017-05-28 17:29:17',0,0,0,0,1,'true','','','',''),
('sro_svid_srodate_sro_c','date_sro_c','LBL_DATE_SRO',\N,\N,'sro_svid_sro','date',\N,0,\N,'2017-05-28 17:29:37',0,0,0,0,1,'true',\N,\N,\N,\N),
('sro_svid_sronum_sro_c','num_sro_c','LBL_NUM_SRO','','','sro_svid_sro','varchar',80,0,'','2017-05-28 17:28:09',0,0,0,0,1,'true','','','',''),
('sro_svid_srosrok_work_sro_c','srok_work_sro_c','LBL_SROK_WORK_SRO','','','sro_svid_sro','date',\N,0,'-1 day','2017-05-28 17:30:08',0,0,0,0,1,'true','','','',''),
('sro_svid_srosro_for_c','sro_for_c','LBL_SRO_FOR','','','sro_svid_sro','relate',255,0,\N,'2017-05-28 17:32:42',0,0,0,0,1,'true','','Accounts','account_id_c','')	;
#	TC`folders`utf8_general_ci	;
CREATE TABLE `folders` (
  `id` char(36) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `folder_type` varchar(25) DEFAULT NULL,
  `parent_folder` char(36) DEFAULT NULL,
  `has_child` tinyint(1) DEFAULT '0',
  `is_group` tinyint(1) DEFAULT '0',
  `is_dynamic` tinyint(1) DEFAULT '0',
  `dynamic_query` text,
  `assign_to_id` char(36) DEFAULT NULL,
  `created_by` char(36) NOT NULL,
  `modified_by` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_folder` (`parent_folder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`folders_rel`utf8_general_ci	;
CREATE TABLE `folders_rel` (
  `id` char(36) NOT NULL,
  `folder_id` char(36) NOT NULL,
  `polymorphic_module` varchar(25) DEFAULT NULL,
  `polymorphic_id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_poly_module_poly_id` (`polymorphic_module`,`polymorphic_id`),
  KEY `idx_fr_id_deleted_poly` (`folder_id`,`deleted`,`polymorphic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`folders_subscriptions`utf8_general_ci	;
CREATE TABLE `folders_subscriptions` (
  `id` char(36) NOT NULL,
  `folder_id` char(36) NOT NULL,
  `assigned_user_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder_id_assigned_user_id` (`folder_id`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_event_locations`utf8_general_ci	;
CREATE TABLE `fp_event_locations` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `address_postalcode` varchar(20) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `capacity` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_event_locations_audit`utf8_general_ci	;
CREATE TABLE `fp_event_locations_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_fp_event_locations_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_event_locations_fp_events_1_c`utf8_general_ci	;
CREATE TABLE `fp_event_locations_fp_events_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_event_locations_fp_events_1fp_event_locations_ida` varchar(36) DEFAULT NULL,
  `fp_event_locations_fp_events_1fp_events_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_event_locations_fp_events_1_ida1` (`fp_event_locations_fp_events_1fp_event_locations_ida`),
  KEY `fp_event_locations_fp_events_1_alt` (`fp_event_locations_fp_events_1fp_events_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events`utf8_general_ci	;
CREATE TABLE `fp_events` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `duration_hours` int(3) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `budget` decimal(26,6) DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `invite_templates` varchar(100) DEFAULT NULL,
  `accept_redirect` varchar(255) DEFAULT NULL,
  `decline_redirect` varchar(255) DEFAULT NULL,
  `activity_status_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_audit`utf8_general_ci	;
CREATE TABLE `fp_events_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_fp_events_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_contacts_c`utf8_general_ci	;
CREATE TABLE `fp_events_contacts_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_contactsfp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_contactscontacts_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fp_events_contacts_alt` (`fp_events_contactsfp_events_ida`,`fp_events_contactscontacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_fp_event_delegates_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_fp_event_delegates_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_fp_event_delegates_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_fp_event_delegates_1fp_event_delegates_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_events_fp_event_delegates_1_ida1` (`fp_events_fp_event_delegates_1fp_events_ida`),
  KEY `fp_events_fp_event_delegates_1_alt` (`fp_events_fp_event_delegates_1fp_event_delegates_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_fp_event_locations_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_fp_event_locations_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_fp_event_locations_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_fp_event_locations_1fp_event_locations_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fp_events_fp_event_locations_1_alt` (`fp_events_fp_event_locations_1fp_events_ida`,`fp_events_fp_event_locations_1fp_event_locations_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_leads_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_leads_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_leads_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_leads_1leads_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fp_events_leads_1_alt` (`fp_events_leads_1fp_events_ida`,`fp_events_leads_1leads_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`fp_events_prospects_1_c`utf8_general_ci	;
CREATE TABLE `fp_events_prospects_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `fp_events_prospects_1fp_events_ida` varchar(36) DEFAULT NULL,
  `fp_events_prospects_1prospects_idb` varchar(36) DEFAULT NULL,
  `invite_status` varchar(25) DEFAULT 'Not Invited',
  `accept_status` varchar(25) DEFAULT 'No Response',
  `email_responded` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fp_events_prospects_1_alt` (`fp_events_prospects_1fp_events_ida`,`fp_events_prospects_1prospects_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`import_maps`utf8_general_ci	;
CREATE TABLE `import_maps` (
  `id` char(36) NOT NULL,
  `name` varchar(254) DEFAULT NULL,
  `source` varchar(36) DEFAULT NULL,
  `enclosure` varchar(1) DEFAULT ' ',
  `delimiter` varchar(1) DEFAULT ',',
  `module` varchar(36) DEFAULT NULL,
  `content` text,
  `default_values` text,
  `has_header` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `is_published` varchar(3) DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `idx_owner_module_name` (`assigned_user_id`,`module`,`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`inbound_email`utf8_general_ci	;
CREATE TABLE `inbound_email` (
  `id` varchar(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Active',
  `server_url` varchar(100) DEFAULT NULL,
  `email_user` varchar(100) DEFAULT NULL,
  `email_password` varchar(100) DEFAULT NULL,
  `port` int(5) DEFAULT NULL,
  `service` varchar(50) DEFAULT NULL,
  `mailbox` text,
  `delete_seen` tinyint(1) DEFAULT '0',
  `mailbox_type` varchar(10) DEFAULT NULL,
  `template_id` char(36) DEFAULT NULL,
  `stored_options` text,
  `group_id` char(36) DEFAULT NULL,
  `is_personal` tinyint(1) DEFAULT '0',
  `groupfolder_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`inbound_email_autoreply`utf8_general_ci	;
CREATE TABLE `inbound_email_autoreply` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `autoreplied_to` varchar(100) DEFAULT NULL,
  `ie_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ie_autoreplied_to` (`autoreplied_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`inbound_email_cache_ts`utf8_general_ci	;
CREATE TABLE `inbound_email_cache_ts` (
  `id` varchar(255) NOT NULL,
  `ie_timestamp` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_address_cache`utf8_general_ci	;
CREATE TABLE `jjwg_address_cache` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `lat` float(10,8) DEFAULT NULL,
  `lng` float(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_address_cache_audit`utf8_general_ci	;
CREATE TABLE `jjwg_address_cache_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_address_cache_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_areas`utf8_general_ci	;
CREATE TABLE `jjwg_areas` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `coordinates` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_areas_audit`utf8_general_ci	;
CREATE TABLE `jjwg_areas_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_areas_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps`utf8_general_ci	;
CREATE TABLE `jjwg_maps` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `distance` float(9,4) DEFAULT NULL,
  `unit_type` varchar(100) DEFAULT 'mi',
  `module_type` varchar(100) DEFAULT 'Accounts',
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps_audit`utf8_general_ci	;
CREATE TABLE `jjwg_maps_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_maps_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps_jjwg_areas_c`utf8_general_ci	;
CREATE TABLE `jjwg_maps_jjwg_areas_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `jjwg_maps_5304wg_maps_ida` varchar(36) DEFAULT NULL,
  `jjwg_maps_41f2g_areas_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjwg_maps_jjwg_areas_alt` (`jjwg_maps_5304wg_maps_ida`,`jjwg_maps_41f2g_areas_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_maps_jjwg_markers_c`utf8_general_ci	;
CREATE TABLE `jjwg_maps_jjwg_markers_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `jjwg_maps_b229wg_maps_ida` varchar(36) DEFAULT NULL,
  `jjwg_maps_2e31markers_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjwg_maps_jjwg_markers_alt` (`jjwg_maps_b229wg_maps_ida`,`jjwg_maps_2e31markers_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_markers`utf8_general_ci	;
CREATE TABLE `jjwg_markers` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `jjwg_maps_lat` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_lng` float(11,8) DEFAULT '0.00000000',
  `marker_image` varchar(100) DEFAULT 'company',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`jjwg_markers_audit`utf8_general_ci	;
CREATE TABLE `jjwg_markers_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_jjwg_markers_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`job_queue`utf8_general_ci	;
CREATE TABLE `job_queue` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `scheduler_id` char(36) DEFAULT NULL,
  `execute_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `resolution` varchar(20) DEFAULT NULL,
  `message` text,
  `target` varchar(255) DEFAULT NULL,
  `data` text,
  `requeue` tinyint(1) DEFAULT '0',
  `retry_count` tinyint(4) DEFAULT NULL,
  `failure_count` tinyint(4) DEFAULT NULL,
  `job_delay` int(11) DEFAULT NULL,
  `client` varchar(255) DEFAULT NULL,
  `percent_complete` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status_scheduler` (`status`,`scheduler_id`),
  KEY `idx_status_time` (`status`,`execute_time`,`date_entered`),
  KEY `idx_status_entered` (`status`,`date_entered`),
  KEY `idx_status_modified` (`status`,`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`leads`utf8_general_ci	;
CREATE TABLE `leads` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `converted` tinyint(1) DEFAULT '0',
  `refered_by` varchar(100) DEFAULT NULL,
  `lead_source` varchar(100) DEFAULT NULL,
  `lead_source_description` text,
  `status` varchar(100) DEFAULT NULL,
  `status_description` text,
  `reports_to_id` char(36) DEFAULT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `account_description` text,
  `contact_id` char(36) DEFAULT NULL,
  `account_id` char(36) DEFAULT NULL,
  `opportunity_id` char(36) DEFAULT NULL,
  `opportunity_name` varchar(255) DEFAULT NULL,
  `opportunity_amount` varchar(50) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `portal_name` varchar(255) DEFAULT NULL,
  `portal_app` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lead_acct_name_first` (`account_name`,`deleted`),
  KEY `idx_lead_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_lead_del_stat` (`last_name`,`status`,`deleted`,`first_name`),
  KEY `idx_lead_opp_del` (`opportunity_id`,`deleted`),
  KEY `idx_leads_acct_del` (`account_id`,`deleted`),
  KEY `idx_del_user` (`deleted`,`assigned_user_id`),
  KEY `idx_lead_assigned` (`assigned_user_id`),
  KEY `idx_lead_contact` (`contact_id`),
  KEY `idx_reports_to` (`reports_to_id`),
  KEY `idx_lead_phone_work` (`phone_work`),
  KEY `idx_leads_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`leads_audit`utf8_general_ci	;
CREATE TABLE `leads_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_leads_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`leads_cstm`utf8_general_ci	;
CREATE TABLE `leads_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`linked_documents`utf8_general_ci	;
CREATE TABLE `linked_documents` (
  `id` varchar(36) NOT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `parent_type` varchar(25) DEFAULT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `document_revision_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_document` (`parent_type`,`parent_id`,`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings`utf8_general_ci	;
CREATE TABLE `meetings` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `join_url` varchar(200) DEFAULT NULL,
  `host_url` varchar(400) DEFAULT NULL,
  `displayed_url` varchar(400) DEFAULT NULL,
  `creator` varchar(50) DEFAULT NULL,
  `external_id` varchar(50) DEFAULT NULL,
  `duration_hours` int(3) DEFAULT NULL,
  `duration_minutes` int(2) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `parent_type` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Planned',
  `type` varchar(255) DEFAULT 'Sugar',
  `parent_id` char(36) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT '-1',
  `email_reminder_time` int(11) DEFAULT '-1',
  `email_reminder_sent` tinyint(1) DEFAULT '0',
  `outlook_id` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT '0',
  `repeat_type` varchar(36) DEFAULT NULL,
  `repeat_interval` int(3) DEFAULT '1',
  `repeat_dow` varchar(7) DEFAULT NULL,
  `repeat_until` date DEFAULT NULL,
  `repeat_count` int(7) DEFAULT NULL,
  `repeat_parent_id` char(36) DEFAULT NULL,
  `recurring_source` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mtg_name` (`name`),
  KEY `idx_meet_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_meet_stat_del` (`assigned_user_id`,`status`,`deleted`),
  KEY `idx_meet_date_start` (`date_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_contacts`utf8_general_ci	;
CREATE TABLE `meetings_contacts` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_mtg_mtg` (`meeting_id`),
  KEY `idx_con_mtg_con` (`contact_id`),
  KEY `idx_meeting_contact` (`meeting_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_cstm`utf8_general_ci	;
CREATE TABLE `meetings_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_leads`utf8_general_ci	;
CREATE TABLE `meetings_leads` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `lead_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lead_meeting_meeting` (`meeting_id`),
  KEY `idx_lead_meeting_lead` (`lead_id`),
  KEY `idx_meeting_lead` (`meeting_id`,`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`meetings_users`utf8_general_ci	;
CREATE TABLE `meetings_users` (
  `id` varchar(36) NOT NULL,
  `meeting_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `required` varchar(1) DEFAULT '1',
  `accept_status` varchar(25) DEFAULT 'none',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usr_mtg_mtg` (`meeting_id`),
  KEY `idx_usr_mtg_usr` (`user_id`),
  KEY `idx_meeting_users` (`meeting_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`notes`utf8_general_ci	;
CREATE TABLE `notes` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `file_mime_type` varchar(100) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `portal_flag` tinyint(1) DEFAULT NULL,
  `embed_flag` tinyint(1) DEFAULT '0',
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_note_name` (`name`),
  KEY `idx_notes_parent` (`parent_id`,`parent_type`),
  KEY `idx_note_contact` (`contact_id`),
  KEY `idx_notes_assigned_del` (`deleted`,`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`notes`utf8_general_ci	;
INSERT INTO `notes` VALUES 
(\N,'530d26be-3d65-0f98-e3ce-592c13cd8158','2017-05-29 12:27:56','2017-05-29 12:27:56','1','1','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','application/pdf','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','Accounts','f1c17d43-b29f-16ef-5774-5927e6b4501a',\N,0,0,\N,0),
(\N,'5825988b-e9b6-a0bf-09b1-592c0f8b7bf9','2017-05-29 12:11:04','2017-05-29 12:11:04','1','1','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','application/pdf','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','Accounts','f1c17d43-b29f-16ef-5774-5927e6b4501a',\N,0,0,\N,0),
(\N,'8a1a7600-d24c-a635-6013-592c0b1262af','2017-05-29 11:54:37','2017-05-29 11:54:37','1','1','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','application/pdf','2136_АНКЕТА_ПРИНЦИПАЛА_без_открытия_счета_(с_15.09.15).pdf','Accounts','f1c17d43-b29f-16ef-5774-5927e6b4501a',\N,0,0,\N,0)	;
#	TC`oauth_consumer`utf8_general_ci	;
CREATE TABLE `oauth_consumer` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `c_key` varchar(255) DEFAULT NULL,
  `c_secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ckey` (`c_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`oauth_nonce`utf8_general_ci	;
CREATE TABLE `oauth_nonce` (
  `conskey` varchar(32) NOT NULL,
  `nonce` varchar(32) NOT NULL,
  `nonce_ts` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`conskey`,`nonce`),
  KEY `oauth_nonce_keyts` (`conskey`,`nonce_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`oauth_tokens`utf8_general_ci	;
CREATE TABLE `oauth_tokens` (
  `id` char(36) NOT NULL,
  `secret` varchar(32) DEFAULT NULL,
  `tstate` varchar(1) DEFAULT NULL,
  `consumer` char(36) NOT NULL,
  `token_ts` bigint(20) DEFAULT NULL,
  `verify` varchar(32) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `callback_url` varchar(255) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`,`deleted`),
  KEY `oauth_state_ts` (`tstate`,`token_ts`),
  KEY `constoken_key` (`consumer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities`utf8_general_ci	;
CREATE TABLE `opportunities` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `opportunity_type` varchar(255) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  `lead_source` varchar(50) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `amount_usdollar` double DEFAULT NULL,
  `currency_id` char(36) DEFAULT NULL,
  `date_closed` date DEFAULT NULL,
  `next_step` varchar(100) DEFAULT NULL,
  `sales_stage` varchar(255) DEFAULT NULL,
  `probability` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_opp_name` (`name`),
  KEY `idx_opp_assigned` (`assigned_user_id`),
  KEY `idx_opp_id_deleted` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities_audit`utf8_general_ci	;
CREATE TABLE `opportunities_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_opportunities_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities_contacts`utf8_general_ci	;
CREATE TABLE `opportunities_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `contact_role` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_con_opp_con` (`contact_id`),
  KEY `idx_con_opp_opp` (`opportunity_id`),
  KEY `idx_opportunities_contacts` (`opportunity_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`opportunities_cstm`utf8_general_ci	;
CREATE TABLE `opportunities_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`outbound_email`utf8_general_ci	;
CREATE TABLE `outbound_email` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(15) DEFAULT 'user',
  `user_id` char(36) NOT NULL,
  `mail_sendtype` varchar(8) DEFAULT 'smtp',
  `mail_smtptype` varchar(20) DEFAULT 'other',
  `mail_smtpserver` varchar(100) DEFAULT NULL,
  `mail_smtpport` int(5) DEFAULT '0',
  `mail_smtpuser` varchar(100) DEFAULT NULL,
  `mail_smtppass` varchar(100) DEFAULT NULL,
  `mail_smtpauth_req` tinyint(1) DEFAULT '0',
  `mail_smtpssl` varchar(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`outbound_email`utf8_general_ci	;
INSERT INTO `outbound_email` VALUES 
('3f24d894-100d-909a-9e1d-592564482917','system','system','1','SMTP','other','smtp.yandex.ru',465,'web@finexpert.pro','1xeVJp9NemB1pAqKjO/pSg==',1,'1',\N,\N,\N,\N,0,\N)	;
#	TC`outbound_email_audit`utf8_general_ci	;
CREATE TABLE `outbound_email_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_outbound_email_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project`utf8_general_ci	;
CREATE TABLE `project` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `estimated_start_date` date DEFAULT NULL,
  `estimated_end_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `override_business_hours` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_contacts_1_c`utf8_general_ci	;
CREATE TABLE `project_contacts_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `project_contacts_1project_ida` varchar(36) DEFAULT NULL,
  `project_contacts_1contacts_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_contacts_1_alt` (`project_contacts_1project_ida`,`project_contacts_1contacts_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_cstm`utf8_general_ci	;
CREATE TABLE `project_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_task`utf8_general_ci	;
CREATE TABLE `project_task` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `project_id` char(36) NOT NULL,
  `project_task_id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `relationship_type` varchar(255) DEFAULT NULL,
  `description` text,
  `predecessors` text,
  `date_start` date DEFAULT NULL,
  `time_start` int(11) DEFAULT NULL,
  `time_finish` int(11) DEFAULT NULL,
  `date_finish` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_unit` text,
  `actual_duration` int(11) DEFAULT NULL,
  `percent_complete` int(11) DEFAULT NULL,
  `date_due` date DEFAULT NULL,
  `time_due` time DEFAULT NULL,
  `parent_task_id` int(11) DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `milestone_flag` tinyint(1) DEFAULT NULL,
  `order_number` int(11) DEFAULT '1',
  `task_number` int(11) DEFAULT NULL,
  `estimated_effort` int(11) DEFAULT NULL,
  `actual_effort` int(11) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `utilization` int(11) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_task_audit`utf8_general_ci	;
CREATE TABLE `project_task_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_project_task_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`project_users_1_c`utf8_general_ci	;
CREATE TABLE `project_users_1_c` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `project_users_1project_ida` varchar(36) DEFAULT NULL,
  `project_users_1users_idb` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_users_1_alt` (`project_users_1project_ida`,`project_users_1users_idb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_accounts`utf8_general_ci	;
CREATE TABLE `projects_accounts` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_acct_proj` (`project_id`),
  KEY `idx_proj_acct_acct` (`account_id`),
  KEY `projects_accounts_alt` (`project_id`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_bugs`utf8_general_ci	;
CREATE TABLE `projects_bugs` (
  `id` varchar(36) NOT NULL,
  `bug_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_bug_proj` (`project_id`),
  KEY `idx_proj_bug_bug` (`bug_id`),
  KEY `projects_bugs_alt` (`project_id`,`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_cases`utf8_general_ci	;
CREATE TABLE `projects_cases` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_case_proj` (`project_id`),
  KEY `idx_proj_case_case` (`case_id`),
  KEY `projects_cases_alt` (`project_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_contacts`utf8_general_ci	;
CREATE TABLE `projects_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_con_proj` (`project_id`),
  KEY `idx_proj_con_con` (`contact_id`),
  KEY `projects_contacts_alt` (`project_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_opportunities`utf8_general_ci	;
CREATE TABLE `projects_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_opp_proj` (`project_id`),
  KEY `idx_proj_opp_opp` (`opportunity_id`),
  KEY `projects_opportunities_alt` (`project_id`,`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`projects_products`utf8_general_ci	;
CREATE TABLE `projects_products` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) DEFAULT NULL,
  `project_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_proj_prod_project` (`project_id`),
  KEY `idx_proj_prod_product` (`product_id`),
  KEY `projects_products_alt` (`project_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospect_list_campaigns`utf8_general_ci	;
CREATE TABLE `prospect_list_campaigns` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `campaign_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pro_id` (`prospect_list_id`),
  KEY `idx_cam_id` (`campaign_id`),
  KEY `idx_prospect_list_campaigns` (`prospect_list_id`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospect_lists`utf8_general_ci	;
CREATE TABLE `prospect_lists` (
  `assigned_user_id` char(36) DEFAULT NULL,
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `list_type` varchar(100) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `description` text,
  `domain_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_prospect_list_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospect_lists_prospects`utf8_general_ci	;
CREATE TABLE `prospect_lists_prospects` (
  `id` varchar(36) NOT NULL,
  `prospect_list_id` varchar(36) DEFAULT NULL,
  `related_id` varchar(36) DEFAULT NULL,
  `related_type` varchar(25) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_plp_pro_id` (`prospect_list_id`),
  KEY `idx_plp_rel_id` (`related_id`,`related_type`,`prospect_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospects`utf8_general_ci	;
CREATE TABLE `prospects` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `salutation` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `do_not_call` tinyint(1) DEFAULT '0',
  `phone_home` varchar(100) DEFAULT NULL,
  `phone_mobile` varchar(100) DEFAULT NULL,
  `phone_work` varchar(100) DEFAULT NULL,
  `phone_other` varchar(100) DEFAULT NULL,
  `phone_fax` varchar(100) DEFAULT NULL,
  `primary_address_street` varchar(150) DEFAULT NULL,
  `primary_address_city` varchar(100) DEFAULT NULL,
  `primary_address_state` varchar(100) DEFAULT NULL,
  `primary_address_postalcode` varchar(20) DEFAULT NULL,
  `primary_address_country` varchar(255) DEFAULT NULL,
  `alt_address_street` varchar(150) DEFAULT NULL,
  `alt_address_city` varchar(100) DEFAULT NULL,
  `alt_address_state` varchar(100) DEFAULT NULL,
  `alt_address_postalcode` varchar(20) DEFAULT NULL,
  `alt_address_country` varchar(255) DEFAULT NULL,
  `assistant` varchar(75) DEFAULT NULL,
  `assistant_phone` varchar(100) DEFAULT NULL,
  `tracker_key` int(11) NOT NULL AUTO_INCREMENT,
  `birthdate` date DEFAULT NULL,
  `lead_id` char(36) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `campaign_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prospect_auto_tracker_key` (`tracker_key`),
  KEY `idx_prospects_last_first` (`last_name`,`first_name`,`deleted`),
  KEY `idx_prospecs_del_last` (`last_name`,`deleted`),
  KEY `idx_prospects_id_del` (`id`,`deleted`),
  KEY `idx_prospects_assigned` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`prospects_cstm`utf8_general_ci	;
CREATE TABLE `prospects_cstm` (
  `id_c` char(36) NOT NULL,
  `jjwg_maps_lng_c` float(11,8) DEFAULT '0.00000000',
  `jjwg_maps_lat_c` float(10,8) DEFAULT '0.00000000',
  `jjwg_maps_geocode_status_c` varchar(255) DEFAULT NULL,
  `jjwg_maps_address_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`relationships`utf8_general_ci	;
CREATE TABLE `relationships` (
  `id` char(36) NOT NULL,
  `relationship_name` varchar(150) DEFAULT NULL,
  `lhs_module` varchar(100) DEFAULT NULL,
  `lhs_table` varchar(64) DEFAULT NULL,
  `lhs_key` varchar(64) DEFAULT NULL,
  `rhs_module` varchar(100) DEFAULT NULL,
  `rhs_table` varchar(64) DEFAULT NULL,
  `rhs_key` varchar(64) DEFAULT NULL,
  `join_table` varchar(64) DEFAULT NULL,
  `join_key_lhs` varchar(64) DEFAULT NULL,
  `join_key_rhs` varchar(64) DEFAULT NULL,
  `relationship_type` varchar(64) DEFAULT NULL,
  `relationship_role_column` varchar(64) DEFAULT NULL,
  `relationship_role_column_value` varchar(50) DEFAULT NULL,
  `reverse` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rel_name` (`relationship_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`relationships`utf8_general_ci	;
INSERT INTO `relationships` VALUES 
('103ca17e-643f-2874-0b89-592bf9ec0fe1','reminders_modified_user','Users','users','id','Reminders','reminders','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('109c8a50-cd98-1d32-f551-592bf97c2677','project_tasks_created_by','Users','users','id','ProjectTask','project_task','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('10d30c05-a1c9-1d1c-6572-592bf9e20cce','accounts_bugs','Accounts','accounts','id','Bugs','bugs','id','accounts_bugs','account_id','bug_id','many-to-many',\N,\N,0,0),
('12085abe-f310-0bea-bec6-592bf9e0e0a0','accounts_contacts','Accounts','accounts','id','Contacts','contacts','id','accounts_contacts','account_id','contact_id','many-to-many',\N,\N,0,0),
('1256fed6-a4f2-7b65-fcf3-592bf97282e5','reminders_created_by','Users','users','id','Reminders','reminders','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('12d9f23b-0f98-a485-8976-592bf95bef30','accounts_opportunities','Accounts','accounts','id','Opportunities','opportunities','id','accounts_opportunities','account_id','opportunity_id','many-to-many',\N,\N,0,0),
('13b1e89e-121f-3b27-8e4d-592bf9fae2ad','calls_contacts','Calls','calls','id','Contacts','contacts','id','calls_contacts','call_id','contact_id','many-to-many',\N,\N,0,0),
('13f6f5d2-5dcd-9cfb-ebb5-592bf956755a','campaigns_modified_user','Users','users','id','Campaigns','campaigns','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('13fee90c-cdad-4413-2f11-592bf9ee8680','reminders_assigned_user','Users','users','id','Reminders','reminders','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('152d06c1-f98f-299c-8b97-592bf94eb379','calls_users','Calls','calls','id','Users','users','id','calls_users','call_id','user_id','many-to-many',\N,\N,0,0),
('153f7995-e3c3-a4d3-52af-592bf9d9a017','campaigns_created_by','Users','users','id','Campaigns','campaigns','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('16453b78-f876-106b-bd21-592bf99dda63','calls_leads','Calls','calls','id','Leads','leads','id','calls_leads','call_id','lead_id','many-to-many',\N,\N,0,0),
('1647e2f4-45ed-db7d-0b88-592bf95e9ca7','campaigns_assigned_user','Users','users','id','Campaigns','campaigns','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1697cbcd-3a6e-d8fc-820e-592bf9c90cdc','reminders_invitees_modified_user','Users','users','id','Reminders_Invitees','reminders_invitees','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('17197df7-1dcd-7daa-4e84-592bf9a1e621','securitygroups_campaigns','SecurityGroups','securitygroups','id','Campaigns','campaigns','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Campaigns',0,0),
('171991f9-b677-97b5-ac62-592bf966a116','cases_bugs','Cases','cases','id','Bugs','bugs','id','cases_bugs','case_id','bug_id','many-to-many',\N,\N,0,0),
('17e66c2a-2e4b-3649-7e9a-592bf9611a63','reminders_invitees_created_by','Users','users','id','Reminders_Invitees','reminders_invitees','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1826580e-c796-c220-cc08-592bf94dfb15','campaign_accounts','Campaigns','campaigns','id','Accounts','accounts','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('183ebacf-8db0-0efa-0ea8-592bf9413a1c','contacts_bugs','Contacts','contacts','id','Bugs','bugs','id','contacts_bugs','contact_id','bug_id','many-to-many',\N,\N,0,0),
('18b3c688-799f-2640-ec4a-592bf9c32452','reminders_invitees_assigned_user','Users','users','id','Reminders_Invitees','reminders_invitees','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('18fa5d77-18fe-f9d1-06f7-592bf9aae5cc','campaign_contacts','Campaigns','campaigns','id','Contacts','contacts','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('191c8479-7724-0692-1306-592bf9c3e743','contacts_cases','Contacts','contacts','id','Cases','cases','id','contacts_cases','contact_id','case_id','many-to-many',\N,\N,0,0),
('19d7d29f-760f-a649-cde6-592bf9e26e4e','contacts_users','Contacts','contacts','id','Users','users','id','contacts_users','contact_id','user_id','many-to-many',\N,\N,0,0),
('19f2e7f2-a006-c765-4e9e-592bf94cb237','campaign_leads','Campaigns','campaigns','id','Leads','leads','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1a700835-099b-e590-8899-592bf9b5657a','projects_emails','Project','project','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('1abff6bb-b335-f113-85a1-592bf92915da','emails_bugs_rel','Emails','emails','id','Bugs','bugs','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Bugs',0,0),
('1ae1e69c-efe3-5662-e52e-592bf99c627e','campaign_prospects','Campaigns','campaigns','id','Prospects','prospects','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1b4b0fcc-46d1-faf1-23fd-592bf96cd2c8','fp_events_modified_user','Users','users','id','FP_events','fp_events','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1b872cd9-8319-03d3-ce00-592bf97204b7','emails_cases_rel','Emails','emails','id','Cases','cases','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Cases',0,0),
('1be5a44c-5d8b-0e28-543d-592bf925b22a','campaign_opportunities','Campaigns','campaigns','id','Opportunities','opportunities','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1c50e242-a93d-13d4-6df0-592bf93b161b','fp_events_created_by','Users','users','id','FP_events','fp_events','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1c56ed63-0959-497c-3d93-592bf9ff725f','emails_opportunities_rel','Emails','emails','id','Opportunities','opportunities','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Opportunities',0,0),
('1c977bca-95c7-d41f-72c6-592bf9339286','campaign_email_marketing','Campaigns','campaigns','id','EmailMarketing','email_marketing','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1ca50986-68c7-a0a2-a785-592bf9fb13ea','favorites_assigned_user','Users','users','id','Favorites','favorites','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1d009be8-7ca8-da15-d909-592bf968f35f','emails_tasks_rel','Emails','emails','id','Tasks','tasks','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Tasks',0,0),
('1d13e447-6545-7879-f4bd-592bf96adca4','fp_events_assigned_user','Users','users','id','FP_events','fp_events','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1d53e1ae-647f-d46e-f402-592bf9211e43','campaign_emailman','Campaigns','campaigns','id','EmailMan','emailman','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1e013d0d-5432-c50d-ed5a-592bf9c13e67','campaign_campaignlog','Campaigns','campaigns','id','CampaignLog','campaign_log','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1e0aae11-2887-d914-0b0f-592bf9bda8d1','securitygroups_fp_events','SecurityGroups','securitygroups','id','FP_events','fp_events','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','FP_events',0,0),
('1ed8f83b-dbbd-a1bd-1945-592bf99421b6','campaign_assigned_user','Users','users','id','Campaigns','campaigns','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1f98b9e6-b16d-cda7-badd-592bf953207e','campaign_modified_user','Users','users','id','Campaigns','campaigns','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('1fa8be9b-f0c5-ec96-719d-592bf9219bcd','emails_users_rel','Emails','emails','id','Users','users','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Users',0,0),
('206b5cc8-ade4-836b-89b2-592bf9bfb4c4','emails_project_task_rel','Emails','emails','id','ProjectTask','project_task','id','emails_beans','email_id','bean_id','many-to-many','bean_module','ProjectTask',0,0),
('20e70a68-1fc4-b69e-3c1d-592bf9984e08','fp_event_locations_modified_user','Users','users','id','FP_Event_Locations','fp_event_locations','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2124e523-ce03-0b64-3108-592bf96990cf','emails_projects_rel','Emails','emails','id','Project','project','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Project',0,0),
('21c1c96e-9ae1-417c-ab52-592bf9b35b4d','emails_prospects_rel','Emails','emails','id','Prospects','prospects','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Prospects',0,0),
('21dd477d-88c2-f2f1-9f61-592bf9b86a07','fp_event_locations_created_by','Users','users','id','FP_Event_Locations','fp_event_locations','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2281dc77-5ce3-4028-f373-592bf9ff8558','meetings_contacts','Meetings','meetings','id','Contacts','contacts','id','meetings_contacts','meeting_id','contact_id','many-to-many',\N,\N,0,0),
('2297f635-d1d8-24ba-8b4f-592bf9da4bac','fp_event_locations_assigned_user','Users','users','id','FP_Event_Locations','fp_event_locations','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('22f323f6-3a8f-665c-5e46-592bf9ff1a09','prospectlists_assigned_user','Users','users','id','prospectlists','prospect_lists','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('233ed7d7-44a4-bd54-aa93-592bf905e5c3','meetings_users','Meetings','meetings','id','Users','users','id','meetings_users','meeting_id','user_id','many-to-many',\N,\N,0,0),
('2359fa90-3397-380c-499a-592bf9632ac4','securitygroups_fp_event_locations','SecurityGroups','securitygroups','id','FP_Event_Locations','fp_event_locations','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','FP_Event_Locations',0,0),
('23800447-f42a-1eb4-bb7a-592bf9d8bce2','projects_meetings','Project','project','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('23f94476-11ad-a945-cbe5-592bf98c0497','securitygroups_prospectlists','SecurityGroups','securitygroups','id','ProspectLists','prospect_lists','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProspectLists',0,0),
('23fc846a-7158-7eee-66f4-592bf9481145','meetings_leads','Meetings','meetings','id','Leads','leads','id','meetings_leads','meeting_id','lead_id','many-to-many',\N,\N,0,0),
('24b1c982-b36b-38fb-44a0-592bf99bfd76','opportunities_contacts','Opportunities','opportunities','id','Contacts','contacts','id','opportunities_contacts','opportunity_id','contact_id','many-to-many',\N,\N,0,0),
('24fed6aa-c45a-ca2a-97c9-592bf966fb7c','optimistic_locking',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,0,0),
('255e6303-974e-d27c-aa1a-592bf970299e','prospect_list_campaigns','ProspectLists','prospect_lists','id','Campaigns','campaigns','id','prospect_list_campaigns','prospect_list_id','campaign_id','many-to-many',\N,\N,0,0),
('25e67990-f9e2-4c7e-56a7-592bf9d161fb','unified_search',\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,\N,0,0),
('26131a11-0468-a54d-dd9f-592bf906e0b1','prospect_list_contacts','ProspectLists','prospect_lists','id','Contacts','contacts','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Contacts',0,0),
('26c9fa51-a229-6b38-16fd-592bf90b998b','prospect_list_prospects','ProspectLists','prospect_lists','id','Prospects','prospects','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Prospects',0,0),
('27760c85-c53f-3392-9ea9-592bf918e9b9','projects_project_tasks','Project','project','id','ProjectTask','project_task','project_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('27889196-19cd-685a-3792-592bf9849932','prospects_modified_user','Users','users','id','Prospects','prospects','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2794fb22-c8db-9877-107c-592bf92c117d','prospect_list_leads','ProspectLists','prospect_lists','id','Leads','leads','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Leads',0,0),
('28391f5b-2f64-8c46-2d42-592bf9652501','prospect_list_users','ProspectLists','prospect_lists','id','Users','users','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Users',0,0),
('28516760-99fe-7421-1670-592bf9cc2615','aod_indexevent_modified_user','Users','users','id','AOD_IndexEvent','aod_indexevent','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('28af9def-8247-b554-edda-592bf9c0a94e','prospects_created_by','Users','users','id','Prospects','prospects','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('28e94ced-3676-039b-4f4d-592bf9eda26f','prospect_list_accounts','ProspectLists','prospect_lists','id','Accounts','accounts','id','prospect_lists_prospects','prospect_list_id','related_id','many-to-many','related_type','Accounts',0,0),
('2952ba4b-87d7-7b5d-0acf-592bf9c5bb15','aod_indexevent_created_by','Users','users','id','AOD_IndexEvent','aod_indexevent','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('297b1add-864c-2749-9bb7-592bf988aa0e','prospects_assigned_user','Users','users','id','Prospects','prospects','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('29bc209f-3c18-e8c8-c538-592bf9348f75','roles_users','Roles','roles','id','Users','users','id','roles_users','role_id','user_id','many-to-many',\N,\N,0,0),
('2a20c34a-cb53-bd4c-2b60-592bf9f41c5f','securitygroups_prospects','SecurityGroups','securitygroups','id','Prospects','prospects','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Prospects',0,0),
('2a6ddc2a-c264-28ca-d9b1-592bf9a0bdff','projects_bugs','Project','project','id','Bugs','bugs','id','projects_bugs','project_id','bug_id','many-to-many',\N,\N,0,0),
('2ae27e2a-f2cc-d431-9327-592bf9f9045b','prospects_email_addresses','Prospects','prospects','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Prospects',0,0),
('2afb17ef-3ca5-d68a-75bf-592bf90e20ef','aod_indexevent_assigned_user','Users','users','id','AOD_IndexEvent','aod_indexevent','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('2b17f450-39ab-1d97-6c49-592bf9bed1b8','projects_cases','Project','project','id','Cases','cases','id','projects_cases','project_id','case_id','many-to-many',\N,\N,0,0),
('2ba2421f-1d9e-5c07-9150-592bf96c648c','prospects_email_addresses_primary','Prospects','prospects','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('2bf03da8-0c53-4f02-32eb-592bf9b29810','projects_accounts','Project','project','id','Accounts','accounts','id','projects_accounts','project_id','account_id','many-to-many',\N,\N,0,0),
('2c7a5476-b364-8a5d-84e8-592bf9e9904a','prospect_tasks','Prospects','prospects','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('2cc8249a-3016-1dea-c773-592bf930448a','projects_contacts','Project','project','id','Contacts','contacts','id','projects_contacts','project_id','contact_id','many-to-many',\N,\N,0,0),
('2d39a5f3-7ea5-8eb6-af9c-592bf97db325','prospect_notes','Prospects','prospects','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('2d819731-ab6a-3bf2-6e3d-592bf9287e0e','projects_opportunities','Project','project','id','Opportunities','opportunities','id','projects_opportunities','project_id','opportunity_id','many-to-many',\N,\N,0,0),
('2dfcffb0-3550-ee79-01b4-592bf9248286','prospect_meetings','Prospects','prospects','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('2e3aea3d-6340-64fd-04e5-592bf931cbb7','acl_roles_actions','ACLRoles','acl_roles','id','ACLActions','acl_actions','id','acl_roles_actions','role_id','action_id','many-to-many',\N,\N,0,0),
('2ebcad98-5aa5-0baa-6dda-592bf95ebb16','prospect_calls','Prospects','prospects','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('2f826a61-e370-1b1d-74ef-592bf9d1f772','prospect_emails','Prospects','prospects','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('2fa30a63-5044-39ca-5e5e-592bf9b545d6','acl_roles_users','ACLRoles','acl_roles','id','Users','users','id','acl_roles_users','role_id','user_id','many-to-many',\N,\N,0,0),
('30531cf4-5420-75c7-3122-592bf9fef50d','prospect_campaign_log','Prospects','prospects','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Prospects',0,0),
('306c83f0-8bb4-4c1b-8760-592bf96a7dce','email_marketing_prospect_lists','EmailMarketing','email_marketing','id','ProspectLists','prospect_lists','id','email_marketing_prospect_lists','email_marketing_id','prospect_list_id','many-to-many',\N,\N,0,0),
('312b732a-fb95-a849-e813-592bf9d5877f','leads_documents','Leads','leads','id','Documents','documents','id','linked_documents','parent_id','document_id','many-to-many','parent_type','Leads',0,0),
('31cbebb2-1732-9477-ca25-592bf94506e3','email_template_email_marketings','EmailTemplates','email_templates','id','EmailMarketing','email_marketing','template_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('31d6359d-52ec-0183-fefb-592bf9e540df','aod_index_modified_user','Users','users','id','AOD_Index','aod_index','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('31f470d3-e240-9fa2-e6cb-592bf9437ada','documents_accounts','Documents','documents','id','Accounts','accounts','id','documents_accounts','document_id','account_id','many-to-many',\N,\N,0,0),
('32d4afdc-dd4b-820e-6ac9-592bf9571a45','documents_contacts','Documents','documents','id','Contacts','contacts','id','documents_contacts','document_id','contact_id','many-to-many',\N,\N,0,0),
('3341cc7e-ff6b-5521-d36c-592bf903d472','campaign_campaigntrakers','Campaigns','campaigns','id','CampaignTrackers','campaign_trkrs','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('33b25c8c-7216-9d64-0235-592bf925cd8c','documents_opportunities','Documents','documents','id','Opportunities','opportunities','id','documents_opportunities','document_id','opportunity_id','many-to-many',\N,\N,0,0),
('33eb0dd6-091d-2125-3ec2-592bf9a5ee75','projects_assigned_user','Users','users','id','Project','project','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('349d2b24-51ec-b9a0-5357-592bf96d86b3','documents_cases','Documents','documents','id','Cases','cases','id','documents_cases','document_id','case_id','many-to-many',\N,\N,0,0),
('357412ab-3c31-eb39-9e31-592bf9a89fac','documents_bugs','Documents','documents','id','Bugs','bugs','id','documents_bugs','document_id','bug_id','many-to-many',\N,\N,0,0),
('35fa5277-0024-570b-cfb2-592bf9fe4cca','aod_index_created_by','Users','users','id','AOD_Index','aod_index','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('36c96720-5b88-bd18-f569-592bf9f3ae97','aod_index_assigned_user','Users','users','id','AOD_Index','aod_index','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('37494aac-01e5-db59-0706-592bf9475101','aok_knowledgebase_categories','AOK_KnowledgeBase','aok_knowledgebase','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','id','aok_knowledgebase_categories','aok_knowledgebase_id','aok_knowledge_base_categories_id','many-to-many',\N,\N,0,0),
('37aee9c1-587a-4efe-21a9-592bf997cbc8','schedulers_created_by_rel','Users','users','id','Schedulers','schedulers','created_by',\N,\N,\N,'one-to-one',\N,\N,0,0),
('38abd375-f028-a4d3-3118-592bf99fd6fd','aop_case_events_modified_user','Users','users','id','AOP_Case_Events','aop_case_events','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('38e7a6b5-b2fc-f481-1ca4-592bf933da5b','schedulers_modified_user_id_rel','Users','users','id','Schedulers','schedulers','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('397f1db9-4fd1-1414-2610-592bf9fa919e','aop_case_events_created_by','Users','users','id','AOP_Case_Events','aop_case_events','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('39ee9210-b066-1851-1511-592bf9b13308','schedulers_jobs_rel','Schedulers','schedulers','id','SchedulersJobs','job_queue','scheduler_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3a209942-5021-7205-e13f-592bf92ea5ed','aop_case_events_assigned_user','Users','users','id','AOP_Case_Events','aop_case_events','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3a2b40a4-6481-f81b-0100-592bf9c9566f','am_projecttemplates_project_1','AM_ProjectTemplates','am_projecttemplates','id','Project','project','id','am_projecttemplates_project_1_c','am_projecttemplates_project_1am_projecttemplates_ida','am_projecttemplates_project_1project_idb','many-to-many',\N,\N,0,0),
('3ad0a2a8-a3f1-f57a-1d99-592bf9cdc1ff','cases_aop_case_events','Cases','cases','id','AOP_Case_Events','aop_case_events','case_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3aeccbf5-9500-391f-07d4-592bf9a6b941','am_projecttemplates_contacts_1','AM_ProjectTemplates','am_projecttemplates','id','Contacts','contacts','id','am_projecttemplates_contacts_1_c','am_projecttemplates_ida','contacts_idb','many-to-many',\N,\N,0,0),
('3b40a2de-d59a-b5f6-1b5a-592bf98e46d3','schedulersjobs_assigned_user','Users','users','id','SchedulersJobs','job_queue','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3bc20604-710d-d559-e123-592bf9711e14','am_projecttemplates_users_1','AM_ProjectTemplates','am_projecttemplates','id','Users','users','id','am_projecttemplates_users_1_c','am_projecttemplates_ida','users_idb','many-to-many',\N,\N,0,0),
('3c906387-3d33-ebb1-43da-592bf99eab2c','am_tasktemplates_am_projecttemplates','AM_ProjectTemplates','am_projecttemplates','id','AM_TaskTemplates','am_tasktemplates','id','am_tasktemplates_am_projecttemplates_c','am_tasktemplates_am_projecttemplatesam_projecttemplates_ida','am_tasktemplates_am_projecttemplatesam_tasktemplates_idb','many-to-many',\N,\N,0,0),
('3d1f7aa7-b703-446a-1f4e-592bf9b099fb','aop_case_updates_modified_user','Users','users','id','AOP_Case_Updates','aop_case_updates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3db076f3-f830-4723-bc38-592bf9359135','aos_contracts_documents','AOS_Contracts','aos_contracts','id','Documents','documents','id','aos_contracts_documents','aos_contracts_id','documents_id','many-to-many',\N,\N,0,0),
('3e112507-7bbf-71e5-6851-592bf910c072','aop_case_updates_created_by','Users','users','id','AOP_Case_Updates','aop_case_updates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3e7fa49b-39c7-0817-ef82-592bf93684b4','aos_quotes_aos_contracts','AOS_Quotes','aos_quotes','id','AOS_Contracts','aos_contracts','id','aos_quotes_os_contracts_c','aos_quotese81e_quotes_ida','aos_quotes4dc0ntracts_idb','many-to-many',\N,\N,0,0),
('3edf094f-6a90-d4c0-926d-592bf9fc2d12','aop_case_updates_assigned_user','Users','users','id','AOP_Case_Updates','aop_case_updates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3f1b0005-e46c-7a12-b551-592bf9077902','projects_modified_user','Users','users','id','Project','project','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3f2ad979-d8a9-e93c-df3e-592bf9de0185','aos_quotes_aos_invoices','AOS_Quotes','aos_quotes','id','AOS_Invoices','aos_invoices','id','aos_quotes_aos_invoices_c','aos_quotes77d9_quotes_ida','aos_quotes6b83nvoices_idb','many-to-many',\N,\N,0,0),
('3f6b06ad-04b9-4944-bfc2-592bf9519900','aok_knowledge_base_categories_modified_user','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3fa10ed0-a63d-2132-b4cb-592bf9816446','cases_aop_case_updates','Cases','cases','id','AOP_Case_Updates','aop_case_updates','case_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('3ffc1266-e749-62ae-7f76-592bf9e89bc0','contacts_modified_user','Users','users','id','Contacts','contacts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('400f99b3-1aa8-82f4-5c94-592bf938b7da','aos_quotes_project','AOS_Quotes','aos_quotes','id','Project','project','id','aos_quotes_project_c','aos_quotes1112_quotes_ida','aos_quotes7207project_idb','many-to-many',\N,\N,0,0),
('40c7c5b6-5971-e115-aaaf-592bf93e4bff','aow_processed_aow_actions','AOW_Processed','aow_processed','id','AOW_Actions','aow_actions','id','aow_processed_aow_actions','aow_processed_id','aow_action_id','many-to-many',\N,\N,0,0),
('40dc2ecb-5a5d-bcfe-6dec-592bf9fb1226','aop_case_updates_notes','AOP_Case_Updates','aop_case_updates','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','AOP_Case_Updates',0,0),
('41754401-fb8c-cad4-160b-592bf910f415','fp_event_locations_fp_events_1','FP_Event_Locations','fp_event_locations','id','FP_events','fp_events','id','fp_event_locations_fp_events_1_c','fp_event_locations_fp_events_1fp_event_locations_ida','fp_event_locations_fp_events_1fp_events_idb','many-to-many',\N,\N,0,0),
('421ae6a6-0cee-d3fe-826b-592bf9fa414b','fp_events_contacts','FP_events','fp_events','id','Contacts','contacts','id','fp_events_contacts_c','fp_events_contactsfp_events_ida','fp_events_contactscontacts_idb','many-to-many',\N,\N,0,0),
('42ccc018-af8a-2952-3e3e-592bf9ed3535','fp_events_fp_event_locations_1','FP_events','fp_events','id','FP_Event_Locations','fp_event_locations','id','fp_events_fp_event_locations_1_c','fp_events_fp_event_locations_1fp_events_ida','fp_events_fp_event_locations_1fp_event_locations_idb','many-to-many',\N,\N,0,0),
('438774f4-dd79-bf6e-ffa9-592bf9430c6e','fp_events_leads_1','FP_events','fp_events','id','Leads','leads','id','fp_events_leads_1_c','fp_events_leads_1fp_events_ida','fp_events_leads_1leads_idb','many-to-many',\N,\N,0,0),
('44d07588-5848-f9ee-133e-592bf911a4c1','aor_reports_modified_user','Users','users','id','AOR_Reports','aor_reports','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('45c729c7-7657-aebf-265f-592bf9d120c5','fp_events_prospects_1','FP_events','fp_events','id','Prospects','prospects','id','fp_events_prospects_1_c','fp_events_prospects_1fp_events_ida','fp_events_prospects_1prospects_idb','many-to-many',\N,\N,0,0),
('45f77170-cd21-1133-aee2-592bf92152b8','aor_reports_created_by','Users','users','id','AOR_Reports','aor_reports','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('473ce95a-884d-0b50-3d98-592bf9387c42','aor_reports_assigned_user','Users','users','id','AOR_Reports','aor_reports','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4742a812-1e9d-e02b-7adb-592bf98e6bde','jjwg_maps_jjwg_areas','jjwg_Maps','jjwg_maps','id','jjwg_Areas','jjwg_areas','id','jjwg_maps_jjwg_areas_c','jjwg_maps_5304wg_maps_ida','jjwg_maps_41f2g_areas_idb','many-to-many',\N,\N,0,0),
('481b286a-232f-fe6a-4b1e-592bf906a268','securitygroups_aor_reports','SecurityGroups','securitygroups','id','AOR_Reports','aor_reports','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOR_Reports',0,0),
('4840148e-e1ce-39ec-bbb0-592bf9fcb68e','jjwg_maps_jjwg_markers','jjwg_Maps','jjwg_maps','id','jjwg_Markers','jjwg_markers','id','jjwg_maps_jjwg_markers_c','jjwg_maps_b229wg_maps_ida','jjwg_maps_2e31markers_idb','many-to-many',\N,\N,0,0),
('48941c89-6b3a-80ee-aedc-592bf97676c7','contacts_created_by','Users','users','id','Contacts','contacts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('48e04f91-cf64-b9ab-8928-592bf9af5639','aor_reports_aor_fields','AOR_Reports','aor_reports','id','AOR_Fields','aor_fields','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('492ebe41-c8af-2632-8a84-592bf98200ae','project_contacts_1','Project','project','id','Contacts','contacts','id','project_contacts_1_c','project_contacts_1project_ida','project_contacts_1contacts_idb','many-to-many',\N,\N,0,0),
('49b3b52a-a1ca-0cd4-4975-592bf979a565','contacts_assigned_user','Users','users','id','Contacts','contacts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('49dcd89a-0fb9-4801-8294-592bf985442e','aor_reports_aor_conditions','AOR_Reports','aor_reports','id','AOR_Conditions','aor_conditions','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4a0580f8-83eb-1575-e31c-592bf9a24830','project_users_1','Project','project','id','Users','users','id','project_users_1_c','project_users_1project_ida','project_users_1users_idb','many-to-many',\N,\N,0,0),
('4abb0e29-c54d-2c35-5eb6-592bf9ea767c','aor_scheduled_reports_aor_reports','AOR_Reports','aor_reports','id','AOR_Scheduled_Reports','aor_scheduled_reports','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4aca9888-37ac-e536-1688-592bf9154933','securitygroups_acl_roles','SecurityGroups','securitygroups','id','ACLRoles','acl_roles','id','securitygroups_acl_roles','securitygroup_id','role_id','many-to-many',\N,\N,0,0),
('4ae0079c-aa4e-2f83-9a52-592bf95bacd1','projects_created_by','Users','users','id','Project','project','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4aec288c-61b2-1f05-9ed3-592bf9050dc9','securitygroups_contacts','SecurityGroups','securitygroups','id','Contacts','contacts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Contacts',0,0),
('4c160ef7-6d96-c291-e976-592bf9a6a1aa','contacts_email_addresses','Contacts','contacts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Contacts',0,0),
('4c68d5ab-1ff6-992d-f504-592bf96c6669','securitygroups_project_task','SecurityGroups','securitygroups','id','ProjectTask','project_task','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProjectTask',0,0),
('4d02f8e6-7083-b6a6-c9ee-592bf9dca1ec','contacts_email_addresses_primary','Contacts','contacts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('4d0a2c3a-f20f-47a5-324a-592bf927e73c','aor_fields_modified_user','Users','users','id','AOR_Fields','aor_fields','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4d3dab0b-32a2-b6ff-0abb-592bf9c80994','securitygroups_prospect_lists','SecurityGroups','securitygroups','id','ProspectLists','prospect_lists','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProspectLists',0,0),
('4ddf9c64-34c6-429a-7bac-592bf9b66c58','contact_direct_reports','Contacts','contacts','id','Contacts','contacts','reports_to_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4dead414-77e4-5479-f970-592bf927b764','aor_fields_created_by','Users','users','id','AOR_Fields','aor_fields','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4e13081f-435b-a748-49f6-592bf9d18847','aok_knowledge_base_categories_created_by','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4e229a85-c322-df6a-e077-592bf90e5e0a','securitygroups_users','SecurityGroups','securitygroups','id','Users','users','id','securitygroups_users','securitygroup_id','user_id','many-to-many',\N,\N,0,0),
('4ee85cd7-8a6c-2f5f-0fa1-592bf971100f','dp_founder_ul_accounts_1','dp_founder_ul','dp_founder_ul','id','Accounts','accounts','id','dp_founder_ul_accounts_1_c','dp_founder_ul_accounts_1dp_founder_ul_ida','dp_founder_ul_accounts_1accounts_idb','many-to-many',\N,\N,0,0),
('4f13d1d3-34c7-3eb3-363c-592bf9323168','contact_leads','Contacts','contacts','id','Leads','leads','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4fda097f-7514-b343-69c3-592bf968b50b','dp_realty_accounts','Accounts','accounts','id','dp_realty','dp_realty','id','dp_realty_accounts_c','dp_realty_accountsaccounts_ida','dp_realty_accountsdp_realty_idb','many-to-many',\N,\N,0,0),
('4feb3daf-9b08-9f7b-ac06-592bf95c031d','contact_notes','Contacts','contacts','id','Notes','notes','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('4fed1fd5-5c66-4067-dbc0-592bf998b08d','aor_charts_modified_user','Users','users','id','AOR_Charts','aor_charts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('509866db-c804-7833-f667-592bf9a8e91a','accounts_contacts_1','Accounts','accounts','id','Contacts','contacts','id','accounts_contacts_1_c','accounts_contacts_1accounts_ida','accounts_contacts_1contacts_idb','many-to-many',\N,\N,0,0),
('50aad46b-c5fd-da33-1021-592bf93e869b','contact_tasks','Contacts','contacts','id','Tasks','tasks','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('50bba6a9-7bde-762c-e9db-592bf9b36cee','aor_charts_created_by','Users','users','id','AOR_Charts','aor_charts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('517c92c0-4b7d-1d2b-688c-592bf99917e2','aor_charts_aor_reports','AOR_Reports','aor_reports','id','AOR_Charts','aor_charts','aor_report_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('51b5e5e7-47d9-a99c-ff54-592bf9beaf69','dp_bkrv_accounts','Accounts','accounts','id','dp_bkrv','dp_bkrv','id','dp_bkrv_accounts_c','dp_bkrv_accountsaccounts_ida','dp_bkrv_accountsdp_bkrv_idb','many-to-many',\N,\N,0,0),
('51bb054c-98a4-890d-37fa-592bf921fbad','contact_tasks_parent','Contacts','contacts','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Contacts',0,0),
('52a4d7da-bc5f-92a5-0b7b-592bf93b19ee','contact_notes_parent','Contacts','contacts','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Contacts',0,0),
('52c93eb2-9a8b-43b2-37ce-592bf9aee31c','dp_founder_fl_contacts_1','dp_founder_fl','dp_founder_fl','id','Contacts','contacts','id','dp_founder_fl_contacts_1_c','dp_founder_fl_contacts_1dp_founder_fl_ida','dp_founder_fl_contacts_1contacts_idb','many-to-many',\N,\N,0,0),
('5384cfd6-25c4-a0d2-8d80-592bf98a1add','contact_campaign_log','Contacts','contacts','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Contacts',0,0),
('53a596f3-5670-6fd3-a2ef-592bf9eaf18d','aor_conditions_modified_user','Users','users','id','AOR_Conditions','aor_conditions','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('548f4bb1-2f3e-98e3-69ef-592bf9f6574c','aor_conditions_created_by','Users','users','id','AOR_Conditions','aor_conditions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('54b2dcca-2d1d-028b-de7d-592bf92b50d5','contact_aos_quotes','Contacts','contacts','id','AOS_Quotes','aos_quotes','billing_contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('558c0a6e-7908-90b6-4900-592bf9c783d7','contact_aos_invoices','Contacts','contacts','id','AOS_Invoices','aos_invoices','billing_contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5687c232-de78-892e-ee05-592bf9079b8f','contact_aos_contracts','Contacts','contacts','id','AOS_Contracts','aos_contracts','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('56f07004-ce82-27d6-b746-592bf9498441','aor_scheduled_reports_modified_user','Users','users','id','AOR_Scheduled_Reports','aor_scheduled_reports','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('577a0a3a-e306-593f-8a4a-592bf9a9e653','contacts_aop_case_updates','Contacts','contacts','id','AOP_Case_Updates','aop_case_updates','contact_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('57fb9472-6f11-b365-f8f5-592bf94c6abe','aor_scheduled_reports_created_by','Users','users','id','AOR_Scheduled_Reports','aor_scheduled_reports','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5b2ac3d9-ed3a-3aea-d694-592bf9d98d3b','aos_contracts_modified_user','Users','users','id','AOS_Contracts','aos_contracts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5c257cd0-54d8-3554-5285-592bf93a1862','aos_contracts_created_by','Users','users','id','AOS_Contracts','aos_contracts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5cb6c602-c9c2-2a69-0993-592bf917145d','accounts_modified_user','Users','users','id','Accounts','accounts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5ce51914-05c3-2cf7-7f89-592bf9891c99','aos_contracts_assigned_user','Users','users','id','AOS_Contracts','aos_contracts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('5dd6e636-7859-a33f-3325-592bf92ef8ff','securitygroups_aos_contracts','SecurityGroups','securitygroups','id','AOS_Contracts','aos_contracts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Contracts',0,0),
('5e86a966-be08-e12a-4759-592bf96c368f','aos_contracts_tasks','AOS_Contracts','aos_contracts','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('5f3238b9-d015-91c6-6e90-592bf911d686','aos_contracts_notes','AOS_Contracts','aos_contracts','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('5fe02db2-7cf9-e8d4-b869-592bf9b95d7f','aos_contracts_meetings','AOS_Contracts','aos_contracts','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('60bb14e2-4112-426a-df72-592bf9979896','accounts_created_by','Users','users','id','Accounts','accounts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('60d00854-e11a-ca93-141f-592bf949f491','favorites_created_by','Users','users','id','Favorites','favorites','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('60e07a48-59a4-1e11-9fdb-592bf9ffee85','aos_contracts_calls','AOS_Contracts','aos_contracts','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','AOS_Contracts',0,0),
('61943bf5-fc7a-84f3-d953-592bf98e2126','aos_contracts_aos_products_quotes','AOS_Contracts','aos_contracts','id','AOS_Products_Quotes','aos_products_quotes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('624cedc5-b9a4-43da-913f-592bf93f9537','aos_contracts_aos_line_item_groups','AOS_Contracts','aos_contracts','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('626539f5-346f-ebf1-dbc9-592bf9ab3079','accounts_assigned_user','Users','users','id','Accounts','accounts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('633777ba-9ce5-029b-43a2-592bf90a88d5','securitygroups_accounts','SecurityGroups','securitygroups','id','Accounts','accounts','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Accounts',0,0),
('6485bbac-1537-3ecf-a973-592bf97adc00','accounts_email_addresses','Accounts','accounts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Accounts',0,0),
('65452f53-3982-fe4d-d02d-592bf9a20638','accounts_email_addresses_primary','Accounts','accounts','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('65a22b57-1115-1a97-eb7f-592bf94f8939','aos_invoices_modified_user','Users','users','id','AOS_Invoices','aos_invoices','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('665b614c-647f-663a-7083-592bf9cb72e3','member_accounts','Accounts','accounts','id','Accounts','accounts','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('675dddc6-00b7-b69c-80cb-592bf9e48624','account_cases','Accounts','accounts','id','Cases','cases','account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('67eb7fab-d270-f3c0-881f-592bf9be2b64','aos_invoices_created_by','Users','users','id','AOS_Invoices','aos_invoices','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('68281407-6540-d04a-81e9-592bf9a5a5f0','account_tasks','Accounts','accounts','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('68e9e898-bab2-5273-c5c1-592bf9c2551a','aos_invoices_assigned_user','Users','users','id','AOS_Invoices','aos_invoices','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('692774ac-65fc-3df8-6931-592bf9a4d103','account_notes','Accounts','accounts','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('697200bd-096e-940d-adeb-592bf99b5dab','aok_knowledge_base_categories_assigned_user','Users','users','id','AOK_Knowledge_Base_Categories','aok_knowledge_base_categories','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('69a72b61-d763-40e9-debd-592bf9c86cc2','securitygroups_aos_invoices','SecurityGroups','securitygroups','id','AOS_Invoices','aos_invoices','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Invoices',0,0),
('6a122392-0ce5-2bb1-2777-592bf958cb3f','account_meetings','Accounts','accounts','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('6a5a5715-fc38-8be6-c2e1-592bf93157ed','aos_invoices_aos_product_quotes','AOS_Invoices','aos_invoices','id','AOS_Products_Quotes','aos_products_quotes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6affec0b-5943-d348-5a20-592bf9a0471a','account_calls','Accounts','accounts','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('6b0f3678-6d41-f055-8da8-592bf9473627','aos_invoices_aos_line_item_groups','AOS_Invoices','aos_invoices','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6bccef27-15b2-01fe-948c-592bf938ca2a','account_emails','Accounts','accounts','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('6d2df038-08e9-644f-ba23-592bf911134b','account_leads','Accounts','accounts','id','Leads','leads','account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6d60fc36-d41e-a44d-f8a4-592bf9d34562','aos_pdf_templates_modified_user','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6e2cd4ec-59c4-d6a4-75a8-592bf93cc682','account_campaign_log','Accounts','accounts','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Accounts',0,0),
('6e39fd1f-c82f-40d4-a9f4-592bf9e56f36','aos_pdf_templates_created_by','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6ee746de-98fb-5083-e813-592bf90823e7','account_aos_quotes','Accounts','accounts','id','AOS_Quotes','aos_quotes','billing_account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6ef4571f-8c1e-0f35-5ddb-592bf910ed1a','aos_pdf_templates_assigned_user','Users','users','id','AOS_PDF_Templates','aos_pdf_templates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6fa22345-5c20-cea6-4bcc-592bf98fe7f9','account_aos_invoices','Accounts','accounts','id','AOS_Invoices','aos_invoices','billing_account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('6fb7d07e-7567-e05c-7853-592bf9570405','securitygroups_aos_pdf_templates','SecurityGroups','securitygroups','id','AOS_PDF_Templates','aos_pdf_templates','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_PDF_Templates',0,0),
('70840ffd-3c11-9870-b8b6-592bf90274f7','securitygroups_projecttask','SecurityGroups','securitygroups','id','ProjectTask','project_task','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','ProjectTask',0,0),
('70ad5411-1f35-2e65-78a1-592bf92d0a6e','account_aos_contracts','Accounts','accounts','id','AOS_Contracts','aos_contracts','contract_account_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('71be2408-6560-9feb-d092-592bf95f9dd2','aos_product_categories_modified_user','Users','users','id','AOS_Product_Categories','aos_product_categories','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('729a82e6-c502-61b3-9837-592bf924453d','aos_product_categories_created_by','Users','users','id','AOS_Product_Categories','aos_product_categories','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('73745ed9-caf2-916e-81dc-592bf9a08786','aos_product_categories_assigned_user','Users','users','id','AOS_Product_Categories','aos_product_categories','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('742360df-bc47-0cf7-4e4e-592bf9f061a9','securitygroups_aos_product_categories','SecurityGroups','securitygroups','id','AOS_Product_Categories','aos_product_categories','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Product_Categories',0,0),
('742c7ea6-7d79-0c57-d0f0-592bf91ab3fe','opportunities_modified_user','Users','users','id','Opportunities','opportunities','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('74d18fe6-c356-5050-cbeb-592bf9869637','sub_product_categories','AOS_Product_Categories','aos_product_categories','id','AOS_Product_Categories','aos_product_categories','parent_category_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('75a7bef8-eb52-8882-e5d6-592bf904a537','opportunities_created_by','Users','users','id','Opportunities','opportunities','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('76a14928-5018-6e1d-5c43-592bf91a12bd','opportunities_assigned_user','Users','users','id','Opportunities','opportunities','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('77661af7-971c-2786-209d-592bf9c02d10','aos_products_modified_user','Users','users','id','AOS_Products','aos_products','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('778679f7-7a24-67e8-2eab-592bf96c4d80','securitygroups_opportunities','SecurityGroups','securitygroups','id','Opportunities','opportunities','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Opportunities',0,0),
('78424a8a-b690-ddfa-de26-592bf9af8931','aos_products_created_by','Users','users','id','AOS_Products','aos_products','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('785700ae-1d1d-54f4-ece6-592bf9445595','opportunity_calls','Opportunities','opportunities','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('78f075e0-7917-888a-429b-592bf9519cf0','aos_products_assigned_user','Users','users','id','AOS_Products','aos_products','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('790940c5-d71a-95cd-75d9-592bf96d1752','opportunity_meetings','Opportunities','opportunities','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('799c7ef9-3217-4b89-f601-592bf9534b86','securitygroups_aos_products','SecurityGroups','securitygroups','id','AOS_Products','aos_products','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Products',0,0),
('79af5c90-3173-6909-5932-592bf968631c','opportunity_tasks','Opportunities','opportunities','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('7a5266bb-46f9-616e-6650-592bf9712b7a','product_categories','AOS_Product_Categories','aos_product_categories','id','AOS_Products','aos_products','aos_product_category_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7a62dd54-a5ca-9613-e6e6-592bf979cacb','opportunity_notes','Opportunities','opportunities','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('7c0f409d-5810-33d7-06ae-592bf9136832','opportunity_emails','Opportunities','opportunities','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('7cb580b8-529b-a682-2dfc-592bf91d01e2','aos_products_quotes_modified_user','Users','users','id','AOS_Products_Quotes','aos_products_quotes','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7d9c2970-caba-b1ef-aeb4-592bf9351dba','aos_products_quotes_created_by','Users','users','id','AOS_Products_Quotes','aos_products_quotes','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7e5bdcc8-f0a6-afbf-aefb-592bf9538d7e','aos_products_quotes_assigned_user','Users','users','id','AOS_Products_Quotes','aos_products_quotes','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7f09580d-260b-af4c-7b7e-592bf9cc1e92','aos_product_quotes_aos_products','AOS_Products','aos_products','id','AOS_Products_Quotes','aos_products_quotes','product_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('7f0a8fb4-f558-70a2-b715-592bf98b221d','opportunity_leads','Opportunities','opportunities','id','Leads','leads','opportunity_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8115089f-c733-b9e4-8725-592bf96ed1c9','opportunity_currencies','Opportunities','opportunities','currency_id','Currencies','currencies','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('81689b59-7fae-1dd6-7e50-592bf9177bbb','aos_line_item_groups_modified_user','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('81f5774c-93a5-2f4b-372d-592bf9901d30','opportunities_campaign','Campaigns','campaigns','id','Opportunities','opportunities','campaign_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('824def3f-3c87-6920-1583-592bf9b062a6','aos_line_item_groups_created_by','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('82b82347-290d-4dea-89df-592bf963a44f','opportunity_aos_quotes','Opportunities','opportunities','id','AOS_Quotes','aos_quotes','opportunity_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('837af527-856c-3a55-d1cc-592bf95e397e','opportunity_aos_contracts','Opportunities','opportunities','id','AOS_Contracts','aos_contracts','opportunity_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('83d74cc9-9e6b-98af-9a05-592bf91de5a6','aos_line_item_groups_assigned_user','Users','users','id','AOS_Line_Item_Groups','aos_line_item_groups','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('84a108ab-fb76-e804-f31f-592bf91117c4','groups_aos_product_quotes','AOS_Line_Item_Groups','aos_line_item_groups','id','AOS_Products_Quotes','aos_products_quotes','group_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('85d6bf54-6827-8bd2-6d62-592bf99bac64','securitygroups_emailtemplates','SecurityGroups','securitygroups','id','EmailTemplates','email_templates','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','EmailTemplates',0,0),
('86910b33-b8f4-2cb3-d12c-592bf9ee442b','project_tasks_notes','ProjectTask','project_task','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('870b0e9b-e223-695d-a1c2-592bf938f695','emailtemplates_assigned_user','Users','users','id','EmailTemplates','email_templates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('88a2ef88-8fdc-9669-ee6c-592bf9bd4d0f','aos_quotes_modified_user','Users','users','id','AOS_Quotes','aos_quotes','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8993d2eb-a8a2-ff55-3718-592bf9d52b58','notes_assigned_user','Users','users','id','Notes','notes','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('89a46348-993a-5b23-c517-592bf95f1da1','aos_quotes_created_by','Users','users','id','AOS_Quotes','aos_quotes','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8a681b9b-ea80-8282-13ff-592bf9cf944c','aos_quotes_assigned_user','Users','users','id','AOS_Quotes','aos_quotes','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8a7eb1ce-2a2e-8137-2fae-592bf9f3b9e9','securitygroups_notes','SecurityGroups','securitygroups','id','Notes','notes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Notes',0,0),
('8b3576f6-b9df-96a4-69e6-592bf9d748ae','securitygroups_aos_quotes','SecurityGroups','securitygroups','id','AOS_Quotes','aos_quotes','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOS_Quotes',0,0),
('8b36c8b7-a4b3-42af-afbb-592bf98a2483','notes_modified_user','Users','users','id','Notes','notes','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8bdeb869-4949-6074-c18e-592bf906b897','aos_quotes_aos_product_quotes','AOS_Quotes','aos_quotes','id','AOS_Products_Quotes','aos_products_quotes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8bf84370-e034-ad71-e388-592bf9cee4cd','notes_created_by','Users','users','id','Notes','notes','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8c925772-9bb8-3e76-7376-592bf9395dd4','aos_quotes_aos_line_item_groups','AOS_Quotes','aos_quotes','id','AOS_Line_Item_Groups','aos_line_item_groups','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8e8a3dc5-f307-454e-a651-592bf9f9b374','aow_actions_modified_user','Users','users','id','AOW_Actions','aow_actions','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8f3ff1f1-f6b5-f575-c94c-592bf9f97c44','calls_modified_user','Users','users','id','Calls','calls','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('8f7bdfee-0b18-d77f-e011-592bf90ffe5f','aow_actions_created_by','Users','users','id','AOW_Actions','aow_actions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('906a4d44-fe70-131e-4fb3-592bf94787ae','calls_created_by','Users','users','id','Calls','calls','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('911b9f8b-eba9-75dd-ac25-592bf955c475','calls_assigned_user','Users','users','id','Calls','calls','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('91b37036-1382-c6ab-95e8-592bf909c9c9','securitygroups_calls','SecurityGroups','securitygroups','id','Calls','calls','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Calls',0,0),
('9258183d-8178-d7b6-1569-592bf9bf380c','calls_notes','Calls','calls','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Calls',0,0),
('92f2ec4f-d34b-2ea7-dca3-592bf9312185','aow_workflow_modified_user','Users','users','id','AOW_WorkFlow','aow_workflow','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('92f60f29-2dbc-190e-4ddb-592bf9b1674f','calls_reschedule','Calls','calls','id','Calls_Reschedule','calls_reschedule','call_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('93440302-16d6-9678-b8fb-592bf9b85258','aok_knowledgebase_modified_user','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('941e5d7b-80a3-e3ce-b57d-592bf920868d','aow_workflow_created_by','Users','users','id','AOW_WorkFlow','aow_workflow','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('94902349-205c-f601-bd40-592bf9779165','securitygroups_emails','SecurityGroups','securitygroups','id','Emails','emails','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Emails',0,0),
('94d6a809-7428-d018-c3a0-592bf96b162f','aow_workflow_assigned_user','Users','users','id','AOW_WorkFlow','aow_workflow','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9569974d-23f8-7668-55a9-592bf90fd7a0','emails_assigned_user','Users','users','id','Emails','emails','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('958305a2-aaed-c5bd-1ca8-592bf9951dc1','securitygroups_aow_workflow','SecurityGroups','securitygroups','id','AOW_WorkFlow','aow_workflow','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOW_WorkFlow',0,0),
('961dd954-46e2-cfef-85ef-592bf9b6fe0a','emails_modified_user','Users','users','id','Emails','emails','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('962d4586-5175-400f-fc72-592bf99b2a38','aow_workflow_aow_conditions','AOW_WorkFlow','aow_workflow','id','AOW_Conditions','aow_conditions','aow_workflow_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('96cd2478-e076-d538-c3c3-592bf9c4d12e','aow_workflow_aow_actions','AOW_WorkFlow','aow_workflow','id','AOW_Actions','aow_actions','aow_workflow_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('96db42b0-d505-d864-415b-592bf9e2adfe','emails_created_by','Users','users','id','Emails','emails','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9771d6b1-3d23-a56b-871b-592bf945566f','aow_workflow_aow_processed','AOW_WorkFlow','aow_workflow','id','AOW_Processed','aow_processed','aow_workflow_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('97afaae2-8d09-a63d-c93c-592bf9aaf02a','emails_notes_rel','Emails','emails','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9877bcc7-3953-e3ea-1543-592bf97348bf','emails_contacts_rel','Emails','emails','id','Contacts','contacts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Contacts',0,0),
('9944dcea-d339-d4ee-507f-592bf93611c2','emails_accounts_rel','Emails','emails','id','Accounts','accounts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Accounts',0,0),
('997257a9-7f74-9186-dde2-592bf9e5d53a','aow_processed_modified_user','Users','users','id','AOW_Processed','aow_processed','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('99f24b3d-efde-37b4-4e4d-592bf9e13e23','emails_leads_rel','Emails','emails','id','Leads','leads','id','emails_beans','email_id','bean_id','many-to-many','bean_module','Leads',0,0),
('9a88c462-cca4-8854-b879-592bf909a421','aow_processed_created_by','Users','users','id','AOW_Processed','aow_processed','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9a9e5b42-387e-db8d-d81b-592bf9385df6','emails_aos_contracts_rel','Emails','emails','id','AOS_Contracts','aos_contracts','id','emails_beans','email_id','bean_id','many-to-many','bean_module','AOS_Contracts',0,0),
('9b702504-5dc7-d96f-4f34-592bf97d26f9','emails_meetings_rel','Emails','emails','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9c690489-5a33-8ab2-3a4c-592bf98ccd50','project_tasks_tasks','ProjectTask','project_task','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('9c864938-d77e-fdbb-1e7a-592bf9649fb6','aow_conditions_modified_user','Users','users','id','AOW_Conditions','aow_conditions','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9d8bc93b-aa75-28f3-5780-592bf976eb1b','aow_conditions_created_by','Users','users','id','AOW_Conditions','aow_conditions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('9ed4c5df-487d-b8a0-4a78-592bf92995ba','meetings_modified_user','Users','users','id','Meetings','meetings','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a042c1aa-c2c5-8817-a565-592bf9c7a912','meetings_created_by','Users','users','id','Meetings','meetings','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a10bf5c3-5740-df16-a831-592bf972533d','meetings_assigned_user','Users','users','id','Meetings','meetings','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a1b8c0ac-d784-f6a4-88a7-592bf9981cfb','securitygroups_meetings','SecurityGroups','securitygroups','id','Meetings','meetings','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Meetings',0,0),
('a26aab02-deb9-6af2-56dd-592bf96c1b93','meetings_notes','Meetings','meetings','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Meetings',0,0),
('a27f0757-268b-4e4b-00cf-592bf9cc183b','jjwg_maps_modified_user','Users','users','id','jjwg_Maps','jjwg_maps','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a37de9a1-8cca-2800-69c3-592bf997b045','jjwg_maps_created_by','Users','users','id','jjwg_Maps','jjwg_maps','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a43e2942-eaff-2937-4f92-592bf92a7361','jjwg_maps_assigned_user','Users','users','id','jjwg_Maps','jjwg_maps','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a4f3ee2f-7964-b3a6-ceb2-592bf92ddb59','securitygroups_jjwg_maps','SecurityGroups','securitygroups','id','jjwg_Maps','jjwg_maps','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Maps',0,0),
('a5581788-6cc0-5523-2c19-592bf9acd319','tasks_modified_user','Users','users','id','Tasks','tasks','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a5a38d50-7070-135f-1f2e-592bf950e082','jjwg_Maps_accounts','jjwg_Maps','jjwg_Maps','parent_id','Accounts','accounts','id',\N,\N,\N,'one-to-many','parent_type','Accounts',0,0),
('a6490b1c-fc1f-7e57-1df2-592bf93d3da9','jjwg_Maps_contacts','jjwg_Maps','jjwg_Maps','parent_id','Contacts','contacts','id',\N,\N,\N,'one-to-many','parent_type','Contacts',0,0),
('a6eb276d-11fd-ae75-c911-592bf90e4b25','jjwg_Maps_leads','jjwg_Maps','jjwg_Maps','parent_id','Leads','leads','id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('a79dc9f6-951c-edc9-96b7-592bf97c2f5f','jjwg_Maps_opportunities','jjwg_Maps','jjwg_Maps','parent_id','Opportunities','opportunities','id',\N,\N,\N,'one-to-many','parent_type','Opportunities',0,0),
('a84ca413-8821-76fc-951b-592bf91c0908','jjwg_Maps_cases','jjwg_Maps','jjwg_Maps','parent_id','Cases','cases','id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('a8fa0505-912f-3ddd-74fd-592bf9fe4605','jjwg_Maps_projects','jjwg_Maps','jjwg_Maps','parent_id','Project','project','id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('a8fb7b0a-3780-a4d3-85e9-592bf9bb9ee2','tasks_created_by','Users','users','id','Tasks','tasks','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('a9a3a2fe-90db-8c71-6c61-592bf910f80a','jjwg_Maps_meetings','jjwg_Maps','jjwg_Maps','parent_id','Meetings','meetings','id',\N,\N,\N,'one-to-many','parent_type','Meetings',0,0),
('a9f5223a-b8e0-32f9-7ead-592bf9a29ec0','tasks_assigned_user','Users','users','id','Tasks','tasks','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('aa48d3a3-1554-6804-bb58-592bf91505be','jjwg_Maps_prospects','jjwg_Maps','jjwg_Maps','parent_id','Prospects','prospects','id',\N,\N,\N,'one-to-many','parent_type','Prospects',0,0),
('aae43d1d-c736-b769-9e09-592bf90cf0aa','securitygroups_tasks','SecurityGroups','securitygroups','id','Tasks','tasks','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Tasks',0,0),
('ac1bfc61-6a10-f246-6667-592bf9a37aa0','tasks_notes','Tasks','tasks','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('adfd891b-b034-8722-c291-592bf9b1f440','jjwg_markers_modified_user','Users','users','id','jjwg_Markers','jjwg_markers','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('af10f902-7e00-0839-3824-592bf94794bb','jjwg_markers_created_by','Users','users','id','jjwg_Markers','jjwg_markers','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('afe04a32-8291-165c-e2bb-592bf9a67ee1','jjwg_markers_assigned_user','Users','users','id','jjwg_Markers','jjwg_markers','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b0ae01ff-1955-7b94-1325-592bf99af84b','securitygroups_jjwg_markers','SecurityGroups','securitygroups','id','jjwg_Markers','jjwg_markers','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Markers',0,0),
('b2cb03d7-12d6-3f9f-bc80-592bf974545c','project_tasks_meetings','ProjectTask','project_task','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('b3301e3d-5776-870f-e4ba-592bf94b71c8','alerts_modified_user','Users','users','id','Alerts','alerts','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b47a9314-7c76-a0ba-15c8-592bf9c00219','alerts_created_by','Users','users','id','Alerts','alerts','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b511ddf1-bac1-be76-3785-592bf995a49c','jjwg_areas_modified_user','Users','users','id','jjwg_Areas','jjwg_areas','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b5870999-5fbf-bf97-5c26-592bf9aa05fd','alerts_assigned_user','Users','users','id','Alerts','alerts','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b6230aef-5148-2f6e-f128-592bf9ced660','aok_knowledgebase_created_by','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b67784f0-53b4-590c-cc18-592bf9bc677b','jjwg_areas_created_by','Users','users','id','jjwg_Areas','jjwg_areas','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b746ae98-efff-fcd8-4ac7-592bf96da4fe','jjwg_areas_assigned_user','Users','users','id','jjwg_Areas','jjwg_areas','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('b83bf43a-8e13-b413-9236-592bf9e91af6','securitygroups_jjwg_areas','SecurityGroups','securitygroups','id','jjwg_Areas','jjwg_areas','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','jjwg_Areas',0,0),
('bbba61a6-69d8-6f5a-706c-592bf9e71b07','documents_modified_user','Users','users','id','Documents','documents','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bc984593-3693-ba81-27bf-592bf93df522','jjwg_address_cache_modified_user','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bdb4f3d2-72ac-ecfc-4c61-592bf96851e8','jjwg_address_cache_created_by','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bdbc27f3-6946-9e2a-127b-592bf9f30df4','documents_created_by','Users','users','id','Documents','documents','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('be925865-5c97-2c21-56d8-592bf978fe85','jjwg_address_cache_assigned_user','Users','users','id','jjwg_Address_Cache','jjwg_address_cache','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bed4d5fa-f960-9262-dbb7-592bf9a96ed5','documents_assigned_user','Users','users','id','Documents','documents','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('bfba8dc1-79e5-2f67-f5a6-592bf90b81bb','securitygroups_documents','SecurityGroups','securitygroups','id','Documents','documents','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Documents',0,0),
('c0870f72-2b64-2a38-e727-592bf927def9','document_revisions','Documents','documents','id','DocumentRevisions','document_revisions','document_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c0bdade6-7f45-030c-6ebf-592bf9f490cc','leads_modified_user','Users','users','id','Leads','leads','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c0f8e67b-7a3f-a168-aa9c-592bf99951a7','calls_reschedule_modified_user','Users','users','id','Calls_Reschedule','calls_reschedule','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c1e09fb9-5562-bf18-0aa8-592bf9debc2e','calls_reschedule_created_by','Users','users','id','Calls_Reschedule','calls_reschedule','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c26c9c4e-b702-f38e-5d05-592bf93dd2d4','revisions_created_by','Users','users','id','DocumentRevisions','document_revisions','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c2d32705-22d6-0537-8da9-592bf973e090','calls_reschedule_assigned_user','Users','users','id','Calls_Reschedule','calls_reschedule','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c39d546d-bb56-abf8-3cb3-592bf9c783ed','leads_created_by','Users','users','id','Leads','leads','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c47b0ac8-f00d-6863-2c18-592bf9cd1706','leads_assigned_user','Users','users','id','Leads','leads','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c52d0ae2-7559-8a63-f84d-592bf9829a42','project_tasks_calls','ProjectTask','project_task','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('c53e4eda-1241-bef3-b2c8-592bf90fa568','securitygroups_leads','SecurityGroups','securitygroups','id','Leads','leads','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Leads',0,0),
('c57d6695-73bd-f019-a32f-592bf91d19d8','securitygroups_modified_user','Users','users','id','SecurityGroups','securitygroups','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c7249b13-22ac-0076-3644-592bf91a0e0b','securitygroups_created_by','Users','users','id','SecurityGroups','securitygroups','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c7720a70-4ccd-5e88-f9d0-592bf9536fa7','leads_email_addresses','Leads','leads','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Leads',0,0),
('c8145f1d-b932-dd0b-c2b9-592bf957004c','securitygroups_assigned_user','Users','users','id','SecurityGroups','securitygroups','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c81a0d6e-5598-59fd-d4e0-592bf917393c','aok_knowledgebase_assigned_user','Users','users','id','AOK_KnowledgeBase','aok_knowledgebase','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c85a33fc-9e54-7e55-439b-592bf98e9f9b','leads_email_addresses_primary','Leads','leads','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('c8c60251-2e83-353c-653f-592bf961d3e5','inbound_email_created_by','Users','users','id','InboundEmail','inbound_email','created_by',\N,\N,\N,'one-to-one',\N,\N,0,0),
('c920711d-8826-c05f-941a-592bf95c6211','lead_direct_reports','Leads','leads','id','Leads','leads','reports_to_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('c9d49f68-8d31-b2e3-9211-592bf9e17f5e','lead_tasks','Leads','leads','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('c9ffd0e4-1573-82fc-827e-592bf93379d2','outbound_email_modified_user','Users','users','id','OutboundEmailAccounts','outbound_email','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ca39b2db-9220-d659-1fe3-592bf9bd3adc','inbound_email_modified_user_id','Users','users','id','InboundEmail','inbound_email','modified_user_id',\N,\N,\N,'one-to-one',\N,\N,0,0),
('ca96e22d-bbda-de66-b015-592bf9a1ca67','lead_notes','Leads','leads','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('cb02004d-ac1b-815d-b844-592bf93e9ab0','outbound_email_created_by','Users','users','id','OutboundEmailAccounts','outbound_email','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cb6fc6fe-c2e9-023c-6ca3-592bf99b8d13','lead_meetings','Leads','leads','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('cbe4019a-e209-3252-3752-592bf9876e9d','outbound_email_assigned_user','Users','users','id','OutboundEmailAccounts','outbound_email','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cc39f77d-9133-3318-e66b-592bf9d2b272','lead_calls','Leads','leads','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('ccc2dbab-4920-25f8-55bc-592bf9ac437f','saved_search_assigned_user','Users','users','id','SavedSearch','saved_search','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cd0172a7-c0a1-cf5d-9405-592bf99f661f','lead_emails','Leads','leads','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Leads',0,0),
('cdca39e6-0d60-a7b1-6de3-592bf9576763','lead_campaign_log','Leads','leads','id','CampaignLog','campaign_log','target_id',\N,\N,\N,'one-to-many','target_type','Leads',0,0),
('ce1c7abd-0478-1363-2bbc-592bf9d098de','templatesectionline_modified_user','Users','users','id','TemplateSectionLine','templatesectionline','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('cf16a968-0c3f-52c6-0439-592bf97e3e61','templatesectionline_created_by','Users','users','id','TemplateSectionLine','templatesectionline','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d1410b1b-ec76-fff9-a681-592bf95c0bec','spots_modified_user','Users','users','id','Spots','spots','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d173d9bd-bfe6-faab-d292-592bf9f235fa','sro_svid_sro_modified_user','Users','users','id','sro_svid_sro','sro_svid_sro','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d17dc920-66eb-2b62-7c11-592bf9cd2104','cases_modified_user','Users','users','id','Cases','cases','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d23d8d71-de17-77a7-9c32-592bf90c5767','spots_created_by','Users','users','id','Spots','spots','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d25fad41-6398-ff9e-76a1-592bf9777730','sro_svid_sro_created_by','Users','users','id','sro_svid_sro','sro_svid_sro','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d2df0ed3-4baf-f577-ebbb-592bf95c5754','cases_created_by','Users','users','id','Cases','cases','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d2f00f03-78dc-c7a9-ff4a-592bf916a628','project_tasks_emails','ProjectTask','project_task','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','ProjectTask',0,0),
('d3145b12-9d90-c87c-bde7-592bf990109a','spots_assigned_user','Users','users','id','Spots','spots','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d33c8fe5-0344-bae5-3410-592bf96d8356','sro_svid_sro_assigned_user','Users','users','id','sro_svid_sro','sro_svid_sro','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d3f5bfbb-b86c-0fa7-982a-592bf9ff02d3','securitygroups_spots','SecurityGroups','securitygroups','id','Spots','spots','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Spots',0,0),
('d3f7f0b2-3ba5-b6c3-e26a-592bf90448e9','cases_assigned_user','Users','users','id','Cases','cases','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d43baab0-0481-a479-550b-592bf961cfc0','securitygroups_sro_svid_sro','SecurityGroups','securitygroups','id','sro_svid_sro','sro_svid_sro','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','sro_svid_sro',0,0),
('d4fa3f19-1c59-4cda-11df-592bf9d64e80','securitygroups_cases','SecurityGroups','securitygroups','id','Cases','cases','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Cases',0,0),
('d5520c19-ee96-df45-81f3-592bf95b75b2','securitygroups_aok_knowledgebase','SecurityGroups','securitygroups','id','AOK_KnowledgeBase','aok_knowledgebase','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','AOK_KnowledgeBase',0,0),
('d5c47c3a-6f62-d320-a1fd-592bf92ba91c','case_calls','Cases','cases','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('d5f492b4-937f-9393-4c92-592bf9e53664','aobh_businesshours_modified_user','Users','users','id','AOBH_BusinessHours','aobh_businesshours','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d68ae357-c774-0f34-c43c-592bf9b91ffc','case_tasks','Cases','cases','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('d6d29584-6965-1c9e-0d28-592bf989fe84','dp_bkrv_modified_user','Users','users','id','dp_bkrv','dp_bkrv','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d704f9c6-a26f-97e0-693b-592bf970df90','aobh_businesshours_created_by','Users','users','id','AOBH_BusinessHours','aobh_businesshours','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d74b8068-11ae-40c7-06e0-592bf915324a','case_notes','Cases','cases','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('d7ea5781-8171-5671-efa8-592bf9ed4fc5','dp_bkrv_created_by','Users','users','id','dp_bkrv','dp_bkrv','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d7fe82a3-9313-b9b1-84bf-592bf9542062','case_meetings','Cases','cases','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('d8a9e50c-2a21-4c9e-6604-592bf9676974','case_emails','Cases','cases','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Cases',0,0),
('d8ddee6b-8d8e-6777-70e8-592bf980741a','dp_bkrv_assigned_user','Users','users','id','dp_bkrv','dp_bkrv','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d9256259-0615-2766-295b-592bf9ea62d3','sugarfeed_modified_user','Users','users','id','SugarFeed','sugarfeed','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d97b3672-b1ea-2d1e-143a-592bf94c38ba','cases_created_contact','Contacts','contacts','id','Cases','cases','contact_created_by_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('d9aa3c05-ccd2-ccba-b30a-592bf92ad36d','securitygroups_dp_bkrv','SecurityGroups','securitygroups','id','dp_bkrv','dp_bkrv','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_bkrv',0,0),
('da1ba0cb-b05e-bb97-2767-592bf99646d3','sugarfeed_created_by','Users','users','id','SugarFeed','sugarfeed','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dad66ee7-9f0e-832b-5c58-592bf9b87677','sugarfeed_assigned_user','Users','users','id','SugarFeed','sugarfeed','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dbfb88b8-f54c-3e3f-e69b-592bf9f3bb82','dp_founder_ul_modified_user','Users','users','id','dp_founder_ul','dp_founder_ul','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dc71e6d3-0a48-d6ee-a387-592bf9a809e1','bugs_modified_user','Users','users','id','Bugs','bugs','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dcf2a5d5-7fdb-0227-ae6c-592bf9cfc249','dp_founder_ul_created_by','Users','users','id','dp_founder_ul','dp_founder_ul','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('dd8fb7e6-ab57-1c39-85c8-592bf948d23c','bugs_created_by','Users','users','id','Bugs','bugs','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ddb96220-75a2-af01-a615-592bf9ac46f1','dp_founder_ul_assigned_user','Users','users','id','dp_founder_ul','dp_founder_ul','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('de4a9dc9-19eb-b6fa-ced2-592bf98de347','bugs_assigned_user','Users','users','id','Bugs','bugs','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('de940638-35b0-1582-9e1f-592bf9588d33','securitygroups_dp_founder_ul','SecurityGroups','securitygroups','id','dp_founder_ul','dp_founder_ul','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_founder_ul',0,0),
('df8a7440-f2b7-40c5-949f-592bf99e7c24','eapm_modified_user','Users','users','id','EAPM','eapm','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e017365c-2bba-32db-a467-592bf9b778b6','securitygroups_bugs','SecurityGroups','securitygroups','id','Bugs','bugs','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Bugs',0,0),
('e079cb00-7178-4e3d-d9a4-592bf9ef5195','eapm_created_by','Users','users','id','EAPM','eapm','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e0980e6f-1d8e-9a27-456f-592bf9afe14b','project_tasks_assigned_user','Users','users','id','ProjectTask','project_task','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e0df7506-2185-7f50-8f76-592bf988d37c','bug_tasks','Bugs','bugs','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('e1120d8f-0305-dcb0-6d96-592bf9c6b865','dp_founder_fl_modified_user','Users','users','id','dp_founder_fl','dp_founder_fl','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e13e7131-6edd-8ce2-2ba9-592bf9b19971','eapm_assigned_user','Users','users','id','EAPM','eapm','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e1998cd2-0d6b-93a9-583e-592bf951d2a4','bug_meetings','Bugs','bugs','id','Meetings','meetings','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('e1f3fe13-aede-3e36-1cbe-592bf941eb1c','dp_founder_fl_created_by','Users','users','id','dp_founder_fl','dp_founder_fl','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e24f0164-c1c6-0e34-f740-592bf9acc253','bug_calls','Bugs','bugs','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('e2c49e8f-b768-dc08-02b6-592bf946f5bb','dp_founder_fl_assigned_user','Users','users','id','dp_founder_fl','dp_founder_fl','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e31ea614-0ffd-c3e0-dd2a-592bf9307313','bug_emails','Bugs','bugs','id','Emails','emails','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('e35f37e6-0446-c203-32a4-592bf98bbb85','oauthkeys_modified_user','Users','users','id','OAuthKeys','oauth_consumer','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e39f3c0b-438f-3909-bdd2-592bf9db7e48','securitygroups_dp_founder_fl','SecurityGroups','securitygroups','id','dp_founder_fl','dp_founder_fl','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_founder_fl',0,0),
('e3ce8f0e-7ac9-c3e6-daee-592bf906df9f','bug_notes','Bugs','bugs','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Bugs',0,0),
('e444fe4f-b9b0-1858-6c53-592bf9851a24','oauthkeys_created_by','Users','users','id','OAuthKeys','oauth_consumer','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e48346bf-f360-3f1d-3ad4-592bf9a5866c','bugs_release','Releases','releases','id','Bugs','bugs','found_in_release',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e50385b5-e607-198f-9f10-592bf97966f8','oauthkeys_assigned_user','Users','users','id','OAuthKeys','oauth_consumer','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e58ca0d9-9115-79d6-84bb-592bf9cabbee','bugs_fixed_in_release','Releases','releases','id','Bugs','bugs','fixed_in_release',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e5d48087-43e3-5884-5ec2-592bf9109a6b','dp_realty_modified_user','Users','users','id','dp_realty','dp_realty','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e64e2a0b-eb08-cd52-e721-592bf96b3a00','consumer_tokens','OAuthKeys','oauth_consumer','id','OAuthTokens','oauth_tokens','consumer',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e6e18767-d950-d4e6-2a2f-592bf9266bf9','user_direct_reports','Users','users','id','Users','users','reports_to_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e7122570-482c-9008-9c67-592bf9924285','oauthtokens_assigned_user','Users','users','id','OAuthTokens','oauth_tokens','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e7b3f16b-6316-c9fe-3001-592bf9bb8aac','users_email_addresses','Users','users','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','bean_module','Users',0,0),
('e8031e51-6a3c-3d5b-c6b7-592bf9537222','dp_realty_created_by','Users','users','id','dp_realty','dp_realty','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e82009e1-1769-3bcc-49f4-592bf913ee78','projects_calls','Project','project','id','Calls','calls','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('e87caa8c-f2a8-56de-e110-592bf94650aa','users_email_addresses_primary','Users','users','id','EmailAddresses','email_addresses','id','email_addr_bean_rel','bean_id','email_address_id','many-to-many','primary_address','1',0,0),
('e8fac1ae-9bf7-62aa-9a4a-592bf92d6062','dp_realty_assigned_user','Users','users','id','dp_realty','dp_realty','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('e96563c7-a40d-cfaa-15bd-592bf96d567a','am_projecttemplates_modified_user','Users','users','id','AM_ProjectTemplates','am_projecttemplates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ea266f76-bb32-c8e3-5085-592bf9a43049','campaignlog_contact','CampaignLog','campaign_log','related_id','Contacts','contacts','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ea6dc5f3-4f07-3b30-4388-592bf91fd087','securitygroups_dp_realty','SecurityGroups','securitygroups','id','dp_realty','dp_realty','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_realty',0,0),
('eafc3398-708f-265d-7309-592bf9ad1b4f','campaignlog_lead','CampaignLog','campaign_log','related_id','Leads','leads','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ebc3b50c-e2c7-f060-a157-592bf9a9999c','campaignlog_created_opportunities','CampaignLog','campaign_log','related_id','Opportunities','opportunities','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ebe82ef0-ba8f-235d-b52a-592bf9aa61ed','am_projecttemplates_created_by','Users','users','id','AM_ProjectTemplates','am_projecttemplates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ec74b30a-3f03-75d6-0941-592bf963ad52','campaignlog_targeted_users','CampaignLog','campaign_log','target_id','Users','users','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ecc3c313-b264-af62-aa19-592bf955de96','am_projecttemplates_assigned_user','Users','users','id','AM_ProjectTemplates','am_projecttemplates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ece7bb42-91cc-3a75-21ee-592bf91b1fbf','dp_license_modified_user','Users','users','id','dp_license','dp_license','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ed6ca8c2-07fc-553d-f206-592bf93d0901','campaignlog_sent_emails','CampaignLog','campaign_log','related_id','Emails','emails','id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ee2836b5-1fe1-5086-3a51-592bf968a7ea','dp_license_created_by','Users','users','id','dp_license','dp_license','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ef0ead9e-9d62-7546-ed52-592bf9cfd963','dp_license_assigned_user','Users','users','id','dp_license','dp_license','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('ef406413-db2e-0246-9893-592bf95a23ce','am_tasktemplates_modified_user','Users','users','id','AM_TaskTemplates','am_tasktemplates','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f00c88b2-82c0-97fc-3264-592bf96dfbd8','securitygroups_dp_license','SecurityGroups','securitygroups','id','dp_license','dp_license','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','dp_license',0,0),
('f0301fbd-7ab0-9d0c-9ad3-592bf9b9a7cb','am_tasktemplates_created_by','Users','users','id','AM_TaskTemplates','am_tasktemplates','created_by',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f0fdad52-9660-4f97-53f3-592bf999f09c','am_tasktemplates_assigned_user','Users','users','id','AM_TaskTemplates','am_tasktemplates','assigned_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f1104b10-f0fd-ab10-b2b5-592bf9724525','securitygroups_project','SecurityGroups','securitygroups','id','Project','project','id','securitygroups_records','securitygroup_id','record_id','many-to-many','module','Project',0,0),
('f2190160-8a40-78e6-0ace-592bf92d3261','project_tasks_modified_user','Users','users','id','ProjectTask','project_task','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f264c742-a971-239d-afa9-592bf9f7067f','favorites_modified_user','Users','users','id','Favorites','favorites','modified_user_id',\N,\N,\N,'one-to-many',\N,\N,0,0),
('f2b6ee14-9647-7f3c-f301-592bf9192471','projects_notes','Project','project','id','Notes','notes','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0),
('f387cc7b-9847-ca12-9cf5-592bf9a22c69','projects_tasks','Project','project','id','Tasks','tasks','parent_id',\N,\N,\N,'one-to-many','parent_type','Project',0,0)	;
#	TC`releases`utf8_general_ci	;
CREATE TABLE `releases` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `list_order` int(4) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_releases` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`reminders`utf8_general_ci	;
CREATE TABLE `reminders` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `popup` tinyint(1) DEFAULT NULL,
  `email` tinyint(1) DEFAULT NULL,
  `email_sent` tinyint(1) DEFAULT NULL,
  `timer_popup` varchar(32) DEFAULT NULL,
  `timer_email` varchar(32) DEFAULT NULL,
  `related_event_module` varchar(32) DEFAULT NULL,
  `related_event_module_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_name` (`name`),
  KEY `idx_reminder_deleted` (`deleted`),
  KEY `idx_reminder_related_event_module` (`related_event_module`),
  KEY `idx_reminder_related_event_module_id` (`related_event_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`reminders_invitees`utf8_general_ci	;
CREATE TABLE `reminders_invitees` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `reminder_id` char(36) NOT NULL,
  `related_invitee_module` varchar(32) DEFAULT NULL,
  `related_invitee_module_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_invitee_name` (`name`),
  KEY `idx_reminder_invitee_assigned_user_id` (`assigned_user_id`),
  KEY `idx_reminder_invitee_reminder_id` (`reminder_id`),
  KEY `idx_reminder_invitee_related_invitee_module` (`related_invitee_module`),
  KEY `idx_reminder_invitee_related_invitee_module_id` (`related_invitee_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`roles`utf8_general_ci	;
CREATE TABLE `roles` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` text,
  `modules` text,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_role_id_del` (`id`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`roles_modules`utf8_general_ci	;
CREATE TABLE `roles_modules` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `module_id` varchar(36) DEFAULT NULL,
  `allow` tinyint(1) DEFAULT '0',
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`roles_users`utf8_general_ci	;
CREATE TABLE `roles_users` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ru_role_id` (`role_id`),
  KEY `idx_ru_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`saved_search`utf8_general_ci	;
CREATE TABLE `saved_search` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `search_module` varchar(150) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `contents` text,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `idx_desc` (`name`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`schedulers`utf8_general_ci	;
CREATE TABLE `schedulers` (
  `id` varchar(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `date_time_start` datetime DEFAULT NULL,
  `date_time_end` datetime DEFAULT NULL,
  `job_interval` varchar(100) DEFAULT NULL,
  `time_from` time DEFAULT NULL,
  `time_to` time DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `catch_up` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_schedule` (`date_time_start`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`schedulers`utf8_general_ci	;
INSERT INTO `schedulers` VALUES 
('9ef2e732-8331-b0ce-2e5d-592564fb2f50',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Process Workflow Tasks','function::processAOW_Workflow','2015-01-01 07:45:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',1),
('a120b680-1757-229f-bcef-592564348ef3',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Report Generation Scheduled Tasks','function::aorRunScheduledReports','2015-01-01 12:15:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',1),
('a2ef5d99-d760-be9e-24e0-5925649c8f60',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Prune Tracker Tables','function::trimTracker','2015-01-01 16:15:01',\N,'0::2::1::*::*',\N,\N,\N,'Active',1),
('a48fc895-c74d-ca4e-9b94-592564195048',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Check Inbound Mailboxes','function::pollMonitoredInboxesAOP','2015-01-01 11:30:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',0),
('a606571d-ba31-c37f-a269-59256486afdd',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Nightly Process Bounced Campaign Emails','function::pollMonitoredInboxesForBouncedCampaignEmails','2015-01-01 06:00:01',\N,'0::2-6::*::*::*',\N,\N,\N,'Active',1),
('a77671b5-8be3-33be-ae32-5925640cbfa5',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Nightly Mass Email Campaigns','function::runMassEmailCampaign','2015-01-01 09:15:01',\N,'0::2-6::*::*::*',\N,\N,\N,'Active',1),
('a94f32f9-38c3-87a5-658f-592564b763cc',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Prune Database on 1st of Month','function::pruneDatabase','2015-01-01 08:00:01',\N,'0::4::1::*::*',\N,\N,\N,'Inactive',0),
('ab26f650-02f9-743d-1709-5925642e7797',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Perform Lucene Index','function::aodIndexUnindexed','2015-01-01 18:15:01',\N,'0::0::*::*::*',\N,\N,\N,'Active',0),
('ace7bd31-a898-1077-f590-5925644d5619',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Optimise AOD Index','function::aodOptimiseIndex','2015-01-01 09:15:01',\N,'0::*/3::*::*::*',\N,\N,\N,'Active',0),
('ae7475bd-d44d-9cab-de89-5925646c927b',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Run Email Reminder Notifications','function::sendEmailReminders','2015-01-01 08:15:01',\N,'*::*::*::*::*',\N,\N,\N,'Active',0),
('b033f8dd-c87b-0589-a0ff-5925649ee29b',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Clean Jobs Queue','function::cleanJobQueue','2015-01-01 13:30:01',\N,'0::5::*::*::*',\N,\N,\N,'Active',0),
('b1b3df87-0c25-6d61-59ba-592564f86a90',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Removal of documents from filesystem','function::removeDocumentsFromFS','2015-01-01 14:00:01',\N,'0::3::1::*::*',\N,\N,\N,'Active',0),
('b306a670-ffa8-f0b8-14f5-5925647b1c99',0,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','1','Prune SuiteCRM Feed Tables','function::trimSugarFeeds','2015-01-01 11:30:01',\N,'0::2::1::*::*',\N,\N,\N,'Active',1)	;
#	TC`securitygroups`utf8_general_ci	;
CREATE TABLE `securitygroups` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `noninheritable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_acl_roles`utf8_general_ci	;
CREATE TABLE `securitygroups_acl_roles` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `role_id` char(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_audit`utf8_general_ci	;
CREATE TABLE `securitygroups_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_securitygroups_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_default`utf8_general_ci	;
CREATE TABLE `securitygroups_default` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_records`utf8_general_ci	;
CREATE TABLE `securitygroups_records` (
  `id` char(36) NOT NULL,
  `securitygroup_id` char(36) DEFAULT NULL,
  `record_id` char(36) DEFAULT NULL,
  `module` char(36) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_securitygroups_records_mod` (`module`,`deleted`,`record_id`,`securitygroup_id`),
  KEY `idx_securitygroups_records_del` (`deleted`,`record_id`,`module`,`securitygroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`securitygroups_users`utf8_general_ci	;
CREATE TABLE `securitygroups_users` (
  `id` varchar(36) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `securitygroup_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `primary_group` tinyint(1) DEFAULT NULL,
  `noninheritable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `securitygroups_users_idxa` (`securitygroup_id`),
  KEY `securitygroups_users_idxb` (`user_id`),
  KEY `securitygroups_users_idxc` (`user_id`,`deleted`,`securitygroup_id`,`id`),
  KEY `securitygroups_users_idxd` (`user_id`,`deleted`,`securitygroup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`spots`utf8_general_ci	;
CREATE TABLE `spots` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `config` longtext,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sro_svid_sro`utf8_general_ci	;
CREATE TABLE `sro_svid_sro` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sro_svid_sro_audit`utf8_general_ci	;
CREATE TABLE `sro_svid_sro_audit` (
  `id` char(36) NOT NULL,
  `parent_id` char(36) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` varchar(36) DEFAULT NULL,
  `field_name` varchar(100) DEFAULT NULL,
  `data_type` varchar(100) DEFAULT NULL,
  `before_value_string` varchar(255) DEFAULT NULL,
  `after_value_string` varchar(255) DEFAULT NULL,
  `before_value_text` text,
  `after_value_text` text,
  PRIMARY KEY (`id`),
  KEY `idx_sro_svid_sro_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sro_svid_sro_cstm`utf8_general_ci	;
CREATE TABLE `sro_svid_sro_cstm` (
  `id_c` char(36) NOT NULL,
  `num_sro_c` varchar(80) DEFAULT NULL,
  `date_sro_c` date DEFAULT NULL,
  `bywhom_sro_c` varchar(150) DEFAULT NULL,
  `srok_work_sro_c` date DEFAULT NULL,
  `account_id_c` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_c`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sugarfeed`utf8_general_ci	;
CREATE TABLE `sugarfeed` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `related_module` varchar(100) DEFAULT NULL,
  `related_id` char(36) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `link_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sgrfeed_date` (`date_entered`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`sugarfeed`utf8_general_ci	;
INSERT INTO `sugarfeed` VALUES 
('a2044fac-31d7-0bb7-013c-592bd2d1a783','<b>{this.CREATED_BY}</b> {SugarFeed.CREATED_CONTACT} [Contacts:9f4c2908-47c8-e20c-5f36-592bd28fd104:Игорь Трофимычев]','2017-05-29 07:49:28','2017-05-29 07:49:28','1','1',\N,0,'1','Contacts','9f4c2908-47c8-e20c-5f36-592bd28fd104',\N,\N),
('d2d0dc84-47e6-7269-dc9e-592be3c50488','<b>{this.CREATED_BY}</b> {SugarFeed.CREATED_CONTACT} [Contacts:c8548377-e295-926c-28ff-592be34c26d7:Юрий Марянин]','2017-05-29 09:00:55','2017-05-29 09:00:55','1','1',\N,0,'1','Contacts','c8548377-e295-926c-28ff-592be34c26d7',\N,\N),
('f17c0131-270e-7a85-15c6-5927e51a6912','<b>{this.CREATED_BY}</b> {SugarFeed.CREATED_CONTACT} [Contacts:e41e39af-5bdc-0b83-c659-5927e5a9adf7:Семён Антонов]','2017-05-26 08:23:20','2017-05-26 08:23:20','1','1',\N,0,'1','Contacts','e41e39af-5bdc-0b83-c659-5927e5a9adf7',\N,\N)	;
#	TC`tasks`utf8_general_ci	;
CREATE TABLE `tasks` (
  `id` char(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `assigned_user_id` char(36) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Not Started',
  `date_due_flag` tinyint(1) DEFAULT '0',
  `date_due` datetime DEFAULT NULL,
  `date_start_flag` tinyint(1) DEFAULT '0',
  `date_start` datetime DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `contact_id` char(36) DEFAULT NULL,
  `priority` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tsk_name` (`name`),
  KEY `idx_task_con_del` (`contact_id`,`deleted`),
  KEY `idx_task_par_del` (`parent_id`,`parent_type`,`deleted`),
  KEY `idx_task_assigned` (`assigned_user_id`),
  KEY `idx_task_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`templatesectionline`utf8_general_ci	;
CREATE TABLE `templatesectionline` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  `thumbnail` varchar(255) DEFAULT NULL,
  `grp` varchar(255) DEFAULT NULL,
  `ord` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tracker`utf8_general_ci	;
CREATE TABLE `tracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monitor_id` char(36) NOT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `module_name` varchar(255) DEFAULT NULL,
  `item_id` varchar(36) DEFAULT NULL,
  `item_summary` varchar(255) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `session_id` varchar(36) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tracker_iid` (`item_id`),
  KEY `idx_tracker_userid_vis_id` (`user_id`,`visible`,`id`),
  KEY `idx_tracker_userid_itemid_vis` (`user_id`,`item_id`,`visible`),
  KEY `idx_tracker_monitor_id` (`monitor_id`),
  KEY `idx_tracker_date_modified` (`date_modified`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8	;
#	TD`tracker`utf8_general_ci	;
INSERT INTO `tracker` VALUES 
(26,'d9cce47e-7f9e-88d1-db5d-59272c0293fe','1','dp_bkrv','cc7ac549-b341-f38a-0bdc-5926d3163ea2','Российский капитал','2017-05-25 19:13:28','detailview','2sf5r7pv4flgeorgcs8dih1h17',1,0),
(47,'8864fff3-b56a-722b-c7be-5927340cd92e','1','dp_realty','55092ca4-45ce-f10f-c85d-59272dbd7b35','443068, г. Самара, ул. Ново-Садовая, д. 106, оф. 613','2017-05-25 19:45:02','editview','2sf5r7pv4flgeorgcs8dih1h17',1,0),
(130,'4d8c6b39-7d78-d6fb-739a-592ba5b886e5','1','dp_founder_fl','aa75ec99-cd50-76a4-2f02-592ba18917bd','632107606114','2017-05-29 04:35:57','editview','u3bk3arjd0v0slbn0ak59m4003',1,0),
(148,'eb384431-a246-d02e-e58c-592bd2eee83f','1','Contacts','9f4c2908-47c8-e20c-5f36-592bd28fd104','Игорь Трофимычев','2017-05-29 07:49:28','detailview','3cb0du9d7mrm2isl2ibmto2081',1,0),
(175,'64e6d1b4-af81-c41d-1515-592be3659381','1','Contacts','c8548377-e295-926c-28ff-592be34c26d7','Юрий Марянин','2017-05-29 09:00:56','detailview','q7n87dtmg94c37eeujhvbl16o1',1,0),
(187,'7dd0c8a5-9ed4-c6a1-872d-592bfbde161c','1','Contacts','e41e39af-5bdc-0b83-c659-5927e5a9adf7','Семён Антонов','2017-05-29 10:45:56','detailview','q7n87dtmg94c37eeujhvbl16o1',1,0),
(216,'476db8a6-abc4-3616-28b8-592c0a96c1b9','1','Accounts','b9f49b4f-21dc-4a20-5646-592571b11c40','Общество с ограниченной ответственностью «Солнечная долина»','2017-05-29 11:47:54','editview','q7n87dtmg94c37eeujhvbl16o1',1,0),
(234,'39bbbc82-24ef-b733-31f6-592c1384df65','1','Accounts','f1c17d43-b29f-16ef-5774-5927e6b4501a','Общество с ограниченной ответственностью «Эффективные технологии»','2017-05-29 12:27:51','detailview','b75dak95gtn230f0j101s9dni0',1,0),
(236,'aa6cc7d7-afe1-2200-2fa3-592c145e045d','1','AOS_PDF_Templates','72f147d5-888a-1986-5d4f-592c0436e1a4','2136 АНКЕТА ПРИНЦИПАЛА без открытия счета (с 15.09.15)','2017-05-29 12:29:05','editview','b75dak95gtn230f0j101s9dni0',1,0),
(238,'77b59490-7da2-bd95-e9a2-592eab022a44','1','Accounts','2a8faeef-e265-daa3-6127-592bdec3ef7b','Общество с ограниченной ответственностью «Аста»','2017-05-31 11:40:33','editview','1neru5v10p9valgfpgsnem9ls4',1,0)	;
#	TC`upgrade_history`utf8_general_ci	;
CREATE TABLE `upgrade_history` (
  `id` char(36) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `md5sum` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `version` varchar(64) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `id_name` varchar(255) DEFAULT NULL,
  `manifest` longtext,
  `date_entered` datetime DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `upgrade_history_md5_uk` (`md5sum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`upgrade_history`utf8_general_ci	;
INSERT INTO `upgrade_history` VALUES 
('323753ed-04ad-de2b-0a21-5926cf321f6c','upload/upgrades/module/project_lp2017_05_25_153515.zip','6e652259e49d8e0ee2a2d506e3d89d6e','module','installed','1495715715','project_lp','Дополнительные параметры','project_lp','YTozOntzOjg6Im1hbmlmZXN0IjthOjEzOntpOjA7YToxOntzOjI1OiJhY2NlcHRhYmxlX3N1Z2FyX3ZlcnNpb25zIjthOjE6e2k6MDtzOjY6IjYuNS4yNCI7fX1pOjE7YToxOntzOjI0OiJhY2NlcHRhYmxlX3N1Z2FyX2ZsYXZvcnMiO2E6Mzp7aTowO3M6MjoiQ0UiO2k6MTtzOjM6IlBSTyI7aToyO3M6MzoiRU5UIjt9fXM6NjoicmVhZG1lIjtzOjA6IiI7czozOiJrZXkiO3M6MjoiZHAiO3M6NjoiYXV0aG9yIjtzOjQ6ImlhbXkiO3M6MTE6ImRlc2NyaXB0aW9uIjtzOjQ3OiLQlNC+0L/QvtC70L3QuNGC0LXQu9GM0L3Ri9C1INC/0LDRgNCw0LzQtdGC0YDRiyI7czo0OiJpY29uIjtzOjA6IiI7czoxNjoiaXNfdW5pbnN0YWxsYWJsZSI7YjoxO3M6NDoibmFtZSI7czoxMDoicHJvamVjdF9scCI7czoxNDoicHVibGlzaGVkX2RhdGUiO3M6MTk6IjIwMTctMDUtMjUgMTI6MzU6MTUiO3M6NDoidHlwZSI7czo2OiJtb2R1bGUiO3M6NzoidmVyc2lvbiI7aToxNDk1NzE1NzE1O3M6MTM6InJlbW92ZV90YWJsZXMiO3M6NjoicHJvbXB0Ijt9czoxMToiaW5zdGFsbGRlZnMiO2E6Mjp7czoyOiJpZCI7czoxMDoicHJvamVjdF9scCI7czo0OiJjb3B5IjthOjE6e2k6MDthOjI6e3M6NDoiZnJvbSI7czoxMzoiPGJhc2VwYXRoPi9scCI7czoyOiJ0byI7czozMjoiY3VzdG9tL21vZHVsZWJ1aWxkZXIvcGFja2FnZXMvbHAiO319fXM6MTY6InVwZ3JhZGVfbWFuaWZlc3QiO3M6MDoiIjt9','2017-05-25 12:36:33',1),
('60b11b2a-aca4-c019-6603-592566248774','upload/upgrades/langpack/ru.zip','8be6d98cef9222ffa18dfcf37aa23ebd','langpack','installed','7.8.3.6','Russian (Russia)','Перевод: www.crowdin.com/project/suitecrmtranslations','ru_RU','YTozOntzOjg6Im1hbmlmZXN0IjthOjk6e3M6NDoibmFtZSI7czoxNjoiUnVzc2lhbiAoUnVzc2lhKSI7czoxMToiZGVzY3JpcHRpb24iO3M6NjA6ItCf0LXRgNC10LLQvtC0OiB3d3cuY3Jvd2Rpbi5jb20vcHJvamVjdC9zdWl0ZWNybXRyYW5zbGF0aW9ucyI7czo0OiJ0eXBlIjtzOjg6ImxhbmdwYWNrIjtzOjE2OiJpc191bmluc3RhbGxhYmxlIjtzOjM6IlllcyI7czoyNToiYWNjZXB0YWJsZV9zdWdhcl92ZXJzaW9ucyI7YTowOnt9czoyNDoiYWNjZXB0YWJsZV9zdWdhcl9mbGF2b3JzIjthOjE6e2k6MDtzOjI6IkNFIjt9czo2OiJhdXRob3IiO3M6MTg6IlN1aXRlQ1JNIENvbW11bml0eSI7czo3OiJ2ZXJzaW9uIjtzOjc6IjcuOC4zLjYiO3M6MTQ6InB1Ymxpc2hlZF9kYXRlIjtzOjEwOiIyMDE3LTA1LTA4Ijt9czoxMToiaW5zdGFsbGRlZnMiO2E6Mzp7czoyOiJpZCI7czo1OiJydV9SVSI7czo5OiJpbWFnZV9kaXIiO3M6MTc6IjxiYXNlcGF0aD4vaW1hZ2VzIjtzOjQ6ImNvcHkiO2E6Mzp7aTowO2E6Mjp7czo0OiJmcm9tIjtzOjE4OiI8YmFzZXBhdGg+L2luY2x1ZGUiO3M6MjoidG8iO3M6NzoiaW5jbHVkZSI7fWk6MTthOjI6e3M6NDoiZnJvbSI7czoxODoiPGJhc2VwYXRoPi9tb2R1bGVzIjtzOjI6InRvIjtzOjc6Im1vZHVsZXMiO31pOjI7YToyOntzOjQ6ImZyb20iO3M6MTg6IjxiYXNlcGF0aD4vaW5zdGFsbCI7czoyOiJ0byI7czo3OiJpbnN0YWxsIjt9fX1zOjE2OiJ1cGdyYWRlX21hbmlmZXN0IjtzOjA6IiI7fQ==','2017-05-24 10:55:35',1),
('67cb0767-7802-6378-0fed-5926d29a86d7','upload/upgrades/module/lp2017_05_29_065759.zip','1b2988aac36703959220c97125abeb57','module','installed','1496030279','lp','Дополнительные параметры','lp','YTozOntzOjg6Im1hbmlmZXN0IjthOjEzOntpOjA7YToxOntzOjI1OiJhY2NlcHRhYmxlX3N1Z2FyX3ZlcnNpb25zIjthOjE6e2k6MDtzOjA6IiI7fX1pOjE7YToxOntzOjI0OiJhY2NlcHRhYmxlX3N1Z2FyX2ZsYXZvcnMiO2E6Mzp7aTowO3M6MjoiQ0UiO2k6MTtzOjM6IlBSTyI7aToyO3M6MzoiRU5UIjt9fXM6NjoicmVhZG1lIjtzOjA6IiI7czozOiJrZXkiO3M6MjoiZHAiO3M6NjoiYXV0aG9yIjtzOjQ6ImlhbXkiO3M6MTE6ImRlc2NyaXB0aW9uIjtzOjQ3OiLQlNC+0L/QvtC70L3QuNGC0LXQu9GM0L3Ri9C1INC/0LDRgNCw0LzQtdGC0YDRiyI7czo0OiJpY29uIjtzOjA6IiI7czoxNjoiaXNfdW5pbnN0YWxsYWJsZSI7YjoxO3M6NDoibmFtZSI7czoyOiJscCI7czoxNDoicHVibGlzaGVkX2RhdGUiO3M6MTk6IjIwMTctMDUtMjkgMDM6NTc6NTkiO3M6NDoidHlwZSI7czo2OiJtb2R1bGUiO3M6NzoidmVyc2lvbiI7aToxNDk2MDMwMjc5O3M6MTM6InJlbW92ZV90YWJsZXMiO3M6NjoicHJvbXB0Ijt9czoxMToiaW5zdGFsbGRlZnMiO2E6OTp7czoyOiJpZCI7czoyOiJscCI7czo1OiJiZWFucyI7YTo1OntpOjA7YTo0OntzOjY6Im1vZHVsZSI7czo3OiJkcF9ia3J2IjtzOjU6ImNsYXNzIjtzOjc6ImRwX2JrcnYiO3M6NDoicGF0aCI7czoyNzoibW9kdWxlcy9kcF9ia3J2L2RwX2JrcnYucGhwIjtzOjM6InRhYiI7YjoxO31pOjE7YTo0OntzOjY6Im1vZHVsZSI7czoxMzoiZHBfZm91bmRlcl91bCI7czo1OiJjbGFzcyI7czoxMzoiZHBfZm91bmRlcl91bCI7czo0OiJwYXRoIjtzOjM5OiJtb2R1bGVzL2RwX2ZvdW5kZXJfdWwvZHBfZm91bmRlcl91bC5waHAiO3M6MzoidGFiIjtiOjE7fWk6MjthOjQ6e3M6NjoibW9kdWxlIjtzOjEzOiJkcF9mb3VuZGVyX2ZsIjtzOjU6ImNsYXNzIjtzOjEzOiJkcF9mb3VuZGVyX2ZsIjtzOjQ6InBhdGgiO3M6Mzk6Im1vZHVsZXMvZHBfZm91bmRlcl9mbC9kcF9mb3VuZGVyX2ZsLnBocCI7czozOiJ0YWIiO2I6MTt9aTozO2E6NDp7czo2OiJtb2R1bGUiO3M6OToiZHBfcmVhbHR5IjtzOjU6ImNsYXNzIjtzOjk6ImRwX3JlYWx0eSI7czo0OiJwYXRoIjtzOjMxOiJtb2R1bGVzL2RwX3JlYWx0eS9kcF9yZWFsdHkucGhwIjtzOjM6InRhYiI7YjoxO31pOjQ7YTo0OntzOjY6Im1vZHVsZSI7czoxMDoiZHBfbGljZW5zZSI7czo1OiJjbGFzcyI7czoxMDoiZHBfbGljZW5zZSI7czo0OiJwYXRoIjtzOjMzOiJtb2R1bGVzL2RwX2xpY2Vuc2UvZHBfbGljZW5zZS5waHAiO3M6MzoidGFiIjtiOjE7fX1zOjEwOiJsYXlvdXRkZWZzIjthOjI6e2k6MDthOjI6e3M6NDoiZnJvbSI7czo3ODoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy9sYXlvdXRkZWZzL2RwX2JrcnZfYWNjb3VudHNfQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7fWk6MTthOjI6e3M6NDoiZnJvbSI7czo4MDoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy9sYXlvdXRkZWZzL2RwX3JlYWx0eV9hY2NvdW50c19BY2NvdW50cy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjg6IkFjY291bnRzIjt9fXM6MTM6InJlbGF0aW9uc2hpcHMiO2E6Mjp7aTowO2E6MTp7czo5OiJtZXRhX2RhdGEiO3M6ODA6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvcmVsYXRpb25zaGlwcy9kcF9ia3J2X2FjY291bnRzTWV0YURhdGEucGhwIjt9aToxO2E6MTp7czo5OiJtZXRhX2RhdGEiO3M6ODI6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvcmVsYXRpb25zaGlwcy9kcF9yZWFsdHlfYWNjb3VudHNNZXRhRGF0YS5waHAiO319czo5OiJpbWFnZV9kaXIiO3M6MTY6IjxiYXNlcGF0aD4vaWNvbnMiO3M6NDoiY29weSI7YTo1OntpOjA7YToyOntzOjQ6ImZyb20iO3M6Mzk6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL21vZHVsZXMvZHBfYmtydiI7czoyOiJ0byI7czoxNToibW9kdWxlcy9kcF9ia3J2Ijt9aToxO2E6Mjp7czo0OiJmcm9tIjtzOjQ1OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9tb2R1bGVzL2RwX2ZvdW5kZXJfdWwiO3M6MjoidG8iO3M6MjE6Im1vZHVsZXMvZHBfZm91bmRlcl91bCI7fWk6MjthOjI6e3M6NDoiZnJvbSI7czo0NToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbW9kdWxlcy9kcF9mb3VuZGVyX2ZsIjtzOjI6InRvIjtzOjIxOiJtb2R1bGVzL2RwX2ZvdW5kZXJfZmwiO31pOjM7YToyOntzOjQ6ImZyb20iO3M6NDE6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL21vZHVsZXMvZHBfcmVhbHR5IjtzOjI6InRvIjtzOjE3OiJtb2R1bGVzL2RwX3JlYWx0eSI7fWk6NDthOjI6e3M6NDoiZnJvbSI7czo0MjoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbW9kdWxlcy9kcF9saWNlbnNlIjtzOjI6InRvIjtzOjE4OiJtb2R1bGVzL2RwX2xpY2Vuc2UiO319czo4OiJsYW5ndWFnZSI7YToxMDp7aTowO2E6Mzp7czo0OiJmcm9tIjtzOjU4OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL2RwX2JrcnYucGhwIjtzOjk6InRvX21vZHVsZSI7czo3OiJkcF9ia3J2IjtzOjg6Imxhbmd1YWdlIjtzOjU6ImVuX3VzIjt9aToxO2E6Mzp7czo0OiJmcm9tIjtzOjU4OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL2RwX2JrcnYucGhwIjtzOjk6InRvX21vZHVsZSI7czo3OiJkcF9ia3J2IjtzOjg6Imxhbmd1YWdlIjtzOjU6InJ1X1JVIjt9aToyO2E6Mzp7czo0OiJmcm9tIjtzOjU5OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL0FjY291bnRzLnBocCI7czo5OiJ0b19tb2R1bGUiO3M6ODoiQWNjb3VudHMiO3M6ODoibGFuZ3VhZ2UiO3M6NToiZW5fdXMiO31pOjM7YTozOntzOjQ6ImZyb20iO3M6NTk6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvbGFuZ3VhZ2UvQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fWk6NDthOjM6e3M6NDoiZnJvbSI7czo2MDoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy9sYW5ndWFnZS9kcF9yZWFsdHkucGhwIjtzOjk6InRvX21vZHVsZSI7czo5OiJkcF9yZWFsdHkiO3M6ODoibGFuZ3VhZ2UiO3M6NToiZW5fdXMiO31pOjU7YTozOntzOjQ6ImZyb20iO3M6NjA6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvbGFuZ3VhZ2UvZHBfcmVhbHR5LnBocCI7czo5OiJ0b19tb2R1bGUiO3M6OToiZHBfcmVhbHR5IjtzOjg6Imxhbmd1YWdlIjtzOjU6InJ1X1JVIjt9aTo2O2E6Mzp7czo0OiJmcm9tIjtzOjU5OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL2xhbmd1YWdlL0FjY291bnRzLnBocCI7czo5OiJ0b19tb2R1bGUiO3M6ODoiQWNjb3VudHMiO3M6ODoibGFuZ3VhZ2UiO3M6NToiZW5fdXMiO31pOjc7YTozOntzOjQ6ImZyb20iO3M6NTk6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvbGFuZ3VhZ2UvQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fWk6ODthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vZW5fdXMubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJlbl91cyI7fWk6OTthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vcnVfUlUubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fX1zOjc6InZhcmRlZnMiO2E6NDp7aTowO2E6Mjp7czo0OiJmcm9tIjtzOjc0OiI8YmFzZXBhdGg+L1N1Z2FyTW9kdWxlcy9yZWxhdGlvbnNoaXBzL3ZhcmRlZnMvZHBfYmtydl9hY2NvdW50c19kcF9ia3J2LnBocCI7czo5OiJ0b19tb2R1bGUiO3M6NzoiZHBfYmtydiI7fWk6MTthOjI6e3M6NDoiZnJvbSI7czo3NToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy92YXJkZWZzL2RwX2JrcnZfYWNjb3VudHNfQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7fWk6MjthOjI6e3M6NDoiZnJvbSI7czo3ODoiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvcmVsYXRpb25zaGlwcy92YXJkZWZzL2RwX3JlYWx0eV9hY2NvdW50c19kcF9yZWFsdHkucGhwIjtzOjk6InRvX21vZHVsZSI7czo5OiJkcF9yZWFsdHkiO31pOjM7YToyOntzOjQ6ImZyb20iO3M6Nzc6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL3JlbGF0aW9uc2hpcHMvdmFyZGVmcy9kcF9yZWFsdHlfYWNjb3VudHNfQWNjb3VudHMucGhwIjtzOjk6InRvX21vZHVsZSI7czo4OiJBY2NvdW50cyI7fX1zOjEyOiJsYXlvdXRmaWVsZHMiO2E6Mjp7aTowO2E6MTp7czoxNzoiYWRkaXRpb25hbF9maWVsZHMiO2E6MDp7fX1pOjE7YToxOntzOjE3OiJhZGRpdGlvbmFsX2ZpZWxkcyI7YTowOnt9fX19czoxNjoidXBncmFkZV9tYW5pZmVzdCI7czowOiIiO30=','2017-05-25 12:46:45',1),
('d3eb6ab5-2acd-b923-651c-592b08293fdc','upload/upgrades/module/sro2017_05_28_202219.zip','662ed9e49383d17e08ae7c69998251a9','module','installed','1495992139','sro','','sro','YTozOntzOjg6Im1hbmlmZXN0IjthOjEzOntpOjA7YToxOntzOjI1OiJhY2NlcHRhYmxlX3N1Z2FyX3ZlcnNpb25zIjthOjE6e2k6MDtzOjA6IiI7fX1pOjE7YToxOntzOjI0OiJhY2NlcHRhYmxlX3N1Z2FyX2ZsYXZvcnMiO2E6Mzp7aTowO3M6MjoiQ0UiO2k6MTtzOjM6IlBSTyI7aToyO3M6MzoiRU5UIjt9fXM6NjoicmVhZG1lIjtzOjA6IiI7czozOiJrZXkiO3M6Mzoic3JvIjtzOjY6ImF1dGhvciI7czowOiIiO3M6MTE6ImRlc2NyaXB0aW9uIjtzOjA6IiI7czo0OiJpY29uIjtzOjA6IiI7czoxNjoiaXNfdW5pbnN0YWxsYWJsZSI7YjoxO3M6NDoibmFtZSI7czozOiJzcm8iO3M6MTQ6InB1Ymxpc2hlZF9kYXRlIjtzOjE5OiIyMDE3LTA1LTI4IDE3OjIyOjE5IjtzOjQ6InR5cGUiO3M6NjoibW9kdWxlIjtzOjc6InZlcnNpb24iO2k6MTQ5NTk5MjEzOTtzOjEzOiJyZW1vdmVfdGFibGVzIjtzOjY6InByb21wdCI7fXM6MTE6Imluc3RhbGxkZWZzIjthOjc6e3M6MjoiaWQiO3M6Mzoic3JvIjtzOjU6ImJlYW5zIjthOjE6e2k6MDthOjQ6e3M6NjoibW9kdWxlIjtzOjEyOiJzcm9fc3ZpZF9zcm8iO3M6NToiY2xhc3MiO3M6MTI6InNyb19zdmlkX3NybyI7czo0OiJwYXRoIjtzOjM3OiJtb2R1bGVzL3Nyb19zdmlkX3Nyby9zcm9fc3ZpZF9zcm8ucGhwIjtzOjM6InRhYiI7YjoxO319czoxMDoibGF5b3V0ZGVmcyI7YTowOnt9czoxMzoicmVsYXRpb25zaGlwcyI7YTowOnt9czo5OiJpbWFnZV9kaXIiO3M6MTY6IjxiYXNlcGF0aD4vaWNvbnMiO3M6NDoiY29weSI7YToxOntpOjA7YToyOntzOjQ6ImZyb20iO3M6NDQ6IjxiYXNlcGF0aD4vU3VnYXJNb2R1bGVzL21vZHVsZXMvc3JvX3N2aWRfc3JvIjtzOjI6InRvIjtzOjIwOiJtb2R1bGVzL3Nyb19zdmlkX3NybyI7fX1zOjg6Imxhbmd1YWdlIjthOjI6e2k6MDthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vZW5fdXMubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJlbl91cyI7fWk6MTthOjM6e3M6NDoiZnJvbSI7czo1OToiPGJhc2VwYXRoPi9TdWdhck1vZHVsZXMvbGFuZ3VhZ2UvYXBwbGljYXRpb24vcnVfUlUubGFuZy5waHAiO3M6OToidG9fbW9kdWxlIjtzOjExOiJhcHBsaWNhdGlvbiI7czo4OiJsYW5ndWFnZSI7czo1OiJydV9SVSI7fX19czoxNjoidXBncmFkZV9tYW5pZmVzdCI7czowOiIiO30=','2017-05-28 17:26:32',1)	;
#	TC`user_preferences`utf8_general_ci	;
CREATE TABLE `user_preferences` (
  `id` char(36) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `contents` longtext,
  PRIMARY KEY (`id`),
  KEY `idx_userprefnamecat` (`assigned_user_id`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`user_preferences`utf8_general_ci	;
INSERT INTO `user_preferences` VALUES 
('14906690-13e2-b525-a51d-59272d6decb3','dp_realty2_DP_REALTY',0,'2017-05-25 19:15:37','2017-05-25 19:15:37','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('27b10dc0-6fbe-4225-2009-5926d49d7ee5','Prospects2_PROSPECT',0,'2017-05-25 12:56:54','2017-05-25 12:56:54','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('30e0011c-a1f1-744f-081f-59282451af06','dp_license2_DP_LICENSE',0,'2017-05-26 12:52:02','2017-05-26 12:52:02','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('3a860cbc-57dc-302a-d9d3-59256e040e17','Project2_PROJECT',0,'2017-05-24 11:28:38','2017-05-24 11:28:38','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('3e12fe37-dff6-6e50-bc30-592568798c55','Contacts2_CONTACT',0,'2017-05-24 11:02:44','2017-05-24 11:02:44','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('450f3f0d-e413-d1a1-dbfa-59256d454f66','Employees2_EMPLOYEE',0,'2017-05-24 11:24:34','2017-05-24 11:24:34','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('48c468f4-b879-452f-90e8-592bf87275eb','AOS_PDF_Templates2_AOS_PDF_TEMPLATES',0,'2017-05-29 10:31:55','2017-05-29 10:31:55','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('499af557-58e4-bc64-e614-59256e6c09fe','Campaigns2_CAMPAIGN',0,'2017-05-24 11:28:10','2017-05-24 11:28:10','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('4a520bb1-c210-4065-cd73-592ba000f033','dp_founder_fl2_DP_FOUNDER_FL',0,'2017-05-29 04:14:57','2017-05-29 04:14:57','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('59487d1e-21ee-04e2-56a8-5925657dc335','Home',0,'2017-05-24 10:52:17','2017-05-28 17:31:38','1','YToyOntzOjg6ImRhc2hsZXRzIjthOjY6e3M6MzY6IjE4YTliNmMwLTk5NTYtNGVkMy05N2NlLTU5MjU2NTI3ZjA0YyI7YTo0OntzOjk6ImNsYXNzTmFtZSI7czoxNjoiU3VnYXJGZWVkRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6OToiU3VnYXJGZWVkIjtzOjExOiJmb3JjZUNvbHVtbiI7aToxO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo2NDoibW9kdWxlcy9TdWdhckZlZWQvRGFzaGxldHMvU3VnYXJGZWVkRGFzaGxldC9TdWdhckZlZWREYXNobGV0LnBocCI7fXM6MzY6IjE5MjJjYzEyLWEwNmUtNjYyNy00MGQ1LTU5MjU2NTYxNTQ4ZSI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoxNDoiTXlDYWxsc0Rhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjU6IkNhbGxzIjtzOjExOiJmb3JjZUNvbHVtbiI7aTowO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo1NjoibW9kdWxlcy9DYWxscy9EYXNobGV0cy9NeUNhbGxzRGFzaGxldC9NeUNhbGxzRGFzaGxldC5waHAiO3M6Nzoib3B0aW9ucyI7YTowOnt9fXM6MzY6IjE5YWRiZTJiLTg0ZmUtM2RlNS1mNzU1LTU5MjU2NWQ0ZDhmNCI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoxNzoiTXlNZWV0aW5nc0Rhc2hsZXQiO3M6NjoibW9kdWxlIjtzOjg6Ik1lZXRpbmdzIjtzOjExOiJmb3JjZUNvbHVtbiI7aTowO3M6MTI6ImZpbGVMb2NhdGlvbiI7czo2NToibW9kdWxlcy9NZWV0aW5ncy9EYXNobGV0cy9NeU1lZXRpbmdzRGFzaGxldC9NeU1lZXRpbmdzRGFzaGxldC5waHAiO3M6Nzoib3B0aW9ucyI7YTowOnt9fXM6MzY6IjE5ZjdlN2Q2LWZiNDItZGI2NS1iOTllLTU5MjU2NTRjZTcxNCI7YTo1OntzOjk6ImNsYXNzTmFtZSI7czoyMjoiTXlPcHBvcnR1bml0aWVzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6MTM6Ik9wcG9ydHVuaXRpZXMiO3M6MTE6ImZvcmNlQ29sdW1uIjtpOjA7czoxMjoiZmlsZUxvY2F0aW9uIjtzOjgwOiJtb2R1bGVzL09wcG9ydHVuaXRpZXMvRGFzaGxldHMvTXlPcHBvcnR1bml0aWVzRGFzaGxldC9NeU9wcG9ydHVuaXRpZXNEYXNobGV0LnBocCI7czo3OiJvcHRpb25zIjthOjA6e319czozNjoiMWE1ZjhkM2UtMjA2NC05NTkzLTdlNTItNTkyNTY1MWY3N2I1IjthOjU6e3M6OToiY2xhc3NOYW1lIjtzOjE3OiJNeUFjY291bnRzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6ODoiQWNjb3VudHMiO3M6MTE6ImZvcmNlQ29sdW1uIjtpOjA7czoxMjoiZmlsZUxvY2F0aW9uIjtzOjY1OiJtb2R1bGVzL0FjY291bnRzL0Rhc2hsZXRzL015QWNjb3VudHNEYXNobGV0L015QWNjb3VudHNEYXNobGV0LnBocCI7czo3OiJvcHRpb25zIjthOjA6e319czozNjoiMWFjY2IwYjctYzgyMS01NDZiLWY2ZTUtNTkyNTY1ZGM0YTI0IjthOjU6e3M6OToiY2xhc3NOYW1lIjtzOjE0OiJNeUxlYWRzRGFzaGxldCI7czo2OiJtb2R1bGUiO3M6NToiTGVhZHMiO3M6MTE6ImZvcmNlQ29sdW1uIjtpOjA7czoxMjoiZmlsZUxvY2F0aW9uIjtzOjU2OiJtb2R1bGVzL0xlYWRzL0Rhc2hsZXRzL015TGVhZHNEYXNobGV0L015TGVhZHNEYXNobGV0LnBocCI7czo3OiJvcHRpb25zIjthOjA6e319fXM6NToicGFnZXMiO2E6MTp7aTowO2E6Mzp7czo3OiJjb2x1bW5zIjthOjI6e2k6MDthOjI6e3M6NToid2lkdGgiO3M6MzoiNjAlIjtzOjg6ImRhc2hsZXRzIjthOjU6e2k6MDtzOjM2OiIxYTVmOGQzZS0yMDY0LTk1OTMtN2U1Mi01OTI1NjUxZjc3YjUiO2k6MTtzOjM2OiIxOTIyY2MxMi1hMDZlLTY2MjctNDBkNS01OTI1NjU2MTU0OGUiO2k6MjtzOjM2OiIxOWFkYmUyYi04NGZlLTNkZTUtZjc1NS01OTI1NjVkNGQ4ZjQiO2k6MztzOjM2OiIxOWY3ZTdkNi1mYjQyLWRiNjUtYjk5ZS01OTI1NjU0Y2U3MTQiO2k6NDtzOjM2OiIxYWNjYjBiNy1jODIxLTU0NmItZjZlNS01OTI1NjVkYzRhMjQiO319aToxO2E6Mjp7czo1OiJ3aWR0aCI7czozOiI0MCUiO3M6ODoiZGFzaGxldHMiO2E6MTp7aTowO3M6MzY6IjE4YTliNmMwLTk5NTYtNGVkMy05N2NlLTU5MjU2NTI3ZjA0YyI7fX19czoxMDoibnVtQ29sdW1ucyI7czoxOiIzIjtzOjE0OiJwYWdlVGl0bGVMYWJlbCI7czoyMDoiTEJMX0hPTUVfUEFHRV8xX05BTUUiO319fQ=='),
('5a384144-4d46-c2f4-1f47-592ba989011f','dp_founder_ul2_DP_FOUNDER_UL',0,'2017-05-29 04:52:42','2017-05-29 04:52:42','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('5b917778-bd89-90a5-be3b-5926d401874e','FP_Event_Locations2_FP_EVENT_LOCATIONS',0,'2017-05-25 12:57:40','2017-05-25 12:57:40','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('5d41d5f1-21c5-a576-372d-592565ade681','Home2_CALL',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6009eec0-f7eb-18e1-5a56-592565bb469a','Home2_MEETING',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6295b8a3-4af7-8ccb-e8a3-592565c5ecb4','Home2_OPPORTUNITY',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('65300a0a-e81c-49f5-0259-59256ee16f85','AOW_WorkFlow2_AOW_WORKFLOW',0,'2017-05-24 11:28:59','2017-05-24 11:28:59','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('65cc5abf-0361-9dd8-eed1-592565d2c010','Home2_ACCOUNT',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6831b2ff-a382-cdf9-df7a-5925655f906c','Home2_LEAD',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('6a97551f-9d31-1c94-73b0-5925658141c4','Home2_SUGARFEED',0,'2017-05-24 10:52:17','2017-05-24 10:52:17','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('775ed48c-4659-e55d-9beb-59256767ae98','Accounts2_ACCOUNT',0,'2017-05-24 11:00:14','2017-05-24 11:00:14','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('9c608ae9-c86f-6682-09d8-592564d88a8f','global',0,'2017-05-24 10:47:24','2017-05-29 10:31:55','1','YTo0ODp7czoyMDoiY2FsZW5kYXJfcHVibGlzaF9rZXkiO3M6MzY6IjljMmNmYzg0LWRlNDktOThmOS04ZGQ2LTU5MjU2NDJlMTk4OSI7czo4OiJ0aW1lem9uZSI7czoxMzoiRXVyb3BlL01vc2NvdyI7czoxMjoibWFpbG1lcmdlX29uIjtzOjI6Im9uIjtzOjE2OiJzd2FwX2xhc3Rfdmlld2VkIjtzOjA6IiI7czoxNDoic3dhcF9zaG9ydGN1dHMiO3M6MDoiIjtzOjE5OiJuYXZpZ2F0aW9uX3BhcmFkaWdtIjtzOjI6ImdtIjtzOjEzOiJzdWJwYW5lbF90YWJzIjtzOjA6IiI7czoxMDoidXNlcl90aGVtZSI7czo2OiJTdWl0ZVIiO3M6MTQ6Im1vZHVsZV9mYXZpY29uIjtzOjA6IiI7czo5OiJoaWRlX3RhYnMiO2E6MDp7fXM6MTE6InJlbW92ZV90YWJzIjthOjA6e31zOjc6Im5vX29wcHMiO3M6Mzoib2ZmIjtzOjEzOiJyZW1pbmRlcl90aW1lIjtpOjE4MDA7czoxOToiZW1haWxfcmVtaW5kZXJfdGltZSI7aTozNjAwO3M6MTY6InJlbWluZGVyX2NoZWNrZWQiO3M6MToiMSI7czoyMjoiZW1haWxfcmVtaW5kZXJfY2hlY2tlZCI7TjtzOjI6InV0IjtzOjE6IjEiO3M6NToiZGF0ZWYiO3M6NToibS9kL1kiO3M6MTU6Im1haWxfc210cHNlcnZlciI7czowOiIiO3M6MTM6Im1haWxfc210cHBvcnQiO3M6MjoiMjUiO3M6MTM6Im1haWxfc210cHVzZXIiO3M6MDoiIjtzOjEzOiJtYWlsX3NtdHBwYXNzIjtzOjA6IiI7czoyNjoiZGVmYXVsdF9sb2NhbGVfbmFtZV9mb3JtYXQiO3M6NToicyBmIGwiO3M6MTY6ImV4cG9ydF9kZWxpbWl0ZXIiO3M6MToiLCI7czoyMjoiZGVmYXVsdF9leHBvcnRfY2hhcnNldCI7czo1OiJVVEYtOCI7czoxNDoidXNlX3JlYWxfbmFtZXMiO3M6Mjoib24iO3M6MTc6Im1haWxfc210cGF1dGhfcmVxIjtzOjE6IjEiO3M6MTI6Im1haWxfc210cHNzbCI7aToxO3M6MTc6ImVtYWlsX3Nob3dfY291bnRzIjtpOjA7czoyMToiZGVmYXVsdF9lbWFpbF9jaGFyc2V0IjtzOjU6IlVURi04IjtzOjE5OiJ0aGVtZV9jdXJyZW50X2dyb3VwIjtzOjY6ItCS0YHQtSI7czo5OiJBY2NvdW50c1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxNToiYWR2YW5jZWRfc2VhcmNoIjt9czo5OiJDb250YWN0c1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxNToiYWR2YW5jZWRfc2VhcmNoIjt9czoxMDoiRW1wbG95ZWVzUSI7YTo0OntzOjY6Im1vZHVsZSI7czo5OiJFbXBsb3llZXMiO3M6NjoiYWN0aW9uIjtzOjU6ImluZGV4IjtzOjU6InF1ZXJ5IjtzOjQ6InRydWUiO3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6MTA6IkNhbXBhaWduc1EiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czo4OiJQcm9qZWN0USI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjEzOiJBT1dfV29ya0Zsb3dRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6NjoiVGFza3NRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6ODoiZHBfYmtydlEiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMDoiUHJvc3BlY3RzUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjE5OiJGUF9FdmVudF9Mb2NhdGlvbnNRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6MTA6ImRwX3JlYWx0eVEiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMToiZHBfbGljZW5zZVEiO2E6MTp7czoxMzoic2VhcmNoRm9ybVRhYiI7czoxMjoiYmFzaWNfc2VhcmNoIjt9czoxMzoic3JvX3N2aWRfc3JvUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjE0OiJkcF9mb3VuZGVyX2ZsUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO31zOjE0OiJkcF9mb3VuZGVyX3VsUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjE1OiJhZHZhbmNlZF9zZWFyY2giO31zOjEwOiJEb2N1bWVudHNRIjthOjE6e3M6MTM6InNlYXJjaEZvcm1UYWIiO3M6MTI6ImJhc2ljX3NlYXJjaCI7fXM6MTg6IkFPU19QREZfVGVtcGxhdGVzUSI7YToxOntzOjEzOiJzZWFyY2hGb3JtVGFiIjtzOjEyOiJiYXNpY19zZWFyY2giO319'),
('ac86ac33-4eed-706f-2ef2-592be385f438','Documents2_DOCUMENT',0,'2017-05-29 09:00:22','2017-05-29 09:00:22','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('b205e08a-ff6b-4093-e437-592564bca40d','ETag',0,'2017-05-24 10:47:24','2017-05-29 03:58:19','1','YToxOntzOjEyOiJtYWluTWVudUVUYWciO2k6MTU7fQ=='),
('b39dab77-91f1-94ec-bac4-592b0a25f993','sro_svid_sro2_SRO_SVID_SRO',0,'2017-05-28 17:37:49','2017-05-28 17:37:49','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('dc22c045-21f4-83c7-e553-5926d2945207','dp_bkrv2_DP_BKRV',0,'2017-05-25 12:47:04','2017-05-25 12:47:04','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ=='),
('dd379fae-d419-840b-d1c7-592567f5da71','Home2_LEAD_1accb0b7-c821-546b-f6e5-592565dc4a24',0,'2017-05-24 10:57:12','2017-05-24 10:57:12','1','YToxOntzOjEzOiJsaXN0dmlld09yZGVyIjthOjI6e3M6Nzoib3JkZXJCeSI7czoxMjoiZGF0ZV9lbnRlcmVkIjtzOjk6InNvcnRPcmRlciI7czo0OiJERVNDIjt9fQ==')	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  `user_hash` varchar(255) DEFAULT NULL,
  `system_generated_password` tinyint(1) DEFAULT NULL,
  `pwd_last_changed` datetime DEFAULT NULL,
  `authenticate_id` varchar(100) DEFAULT NULL,
  `sugar_login` tinyint(1) DEFAULT '1',
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `external_auth_only` tinyint(1) DEFAULT '0',
  `receive_notifications` tinyint(1) DEFAULT '1',
  `description` text,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `modified_user_id` char(36) DEFAULT NULL,
  `created_by` char(36) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `phone_home` varchar(50) DEFAULT NULL,
  `phone_mobile` varchar(50) DEFAULT NULL,
  `phone_work` varchar(50) DEFAULT NULL,
  `phone_other` varchar(50) DEFAULT NULL,
  `phone_fax` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `address_street` varchar(150) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_state` varchar(100) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `address_postalcode` varchar(20) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `portal_only` tinyint(1) DEFAULT '0',
  `show_on_employees` tinyint(1) DEFAULT '1',
  `employee_status` varchar(100) DEFAULT NULL,
  `messenger_id` varchar(100) DEFAULT NULL,
  `messenger_type` varchar(100) DEFAULT NULL,
  `reports_to_id` char(36) DEFAULT NULL,
  `is_group` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_name` (`user_name`,`is_group`,`status`,`last_name`,`first_name`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
('1','admin','$1$Wbv7KmQO$UUr8Z6wWsFI29T64hcOiL1',0,\N,\N,1,\N,'Administrator',1,0,1,\N,'2017-05-24 10:47:24','2017-05-24 10:47:24','1','','Administrator',\N,\N,\N,\N,\N,\N,\N,'Active',\N,\N,\N,\N,\N,0,0,1,'Active',\N,\N,'',0)	;
#	TC`users_feeds`utf8_general_ci	;
CREATE TABLE `users_feeds` (
  `user_id` varchar(36) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  KEY `idx_ud_user_id` (`user_id`,`feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`users_last_import`utf8_general_ci	;
CREATE TABLE `users_last_import` (
  `id` char(36) NOT NULL,
  `assigned_user_id` char(36) DEFAULT NULL,
  `import_module` varchar(36) DEFAULT NULL,
  `bean_type` varchar(36) DEFAULT NULL,
  `bean_id` char(36) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`users_password_link`utf8_general_ci	;
CREATE TABLE `users_password_link` (
  `id` char(36) NOT NULL,
  `username` varchar(36) DEFAULT NULL,
  `date_generated` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`users_signatures`utf8_general_ci	;
CREATE TABLE `users_signatures` (
  `id` char(36) NOT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `signature` text,
  `signature_html` text,
  PRIMARY KEY (`id`),
  KEY `idx_usersig_uid` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`vcals`utf8_general_ci	;
CREATE TABLE `vcals` (
  `id` char(36) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `idx_vcal` (`type`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
